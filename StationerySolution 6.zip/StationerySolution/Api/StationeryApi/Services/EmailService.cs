using System.Net;
using System.Net.Mail;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Models;
namespace StationeryApi.Services;

public class EmailService(AppDbContext db, IConfiguration cfg, ILogger<EmailService> log)
{
    public bool SmtpConfigured => !string.IsNullOrWhiteSpace(cfg["Smtp:Host"]);

    /// <summary>Store the mail in EmailLog and try to send it now. Failures are retried by EmailRetryWorker.</summary>
    public async Task QueueAsync(int? requestId, string to, string subject, string body, byte[]? pdf = null, string? pdfName = null)
    {
        var m = new EmailLog { RequestId = requestId, ToEmail = to, Subject = subject, Body = body, AttachPo = pdf != null };
        db.EmailLogs.Add(m);
        await db.SaveChangesAsync();
        if (SmtpConfigured) await SendAsync(m, pdf, pdfName);
    }

    public async Task SendAsync(EmailLog m, byte[]? pdf, string? pdfName)
    {
        m.LastAttemptAt = DateTime.UtcNow;
        try
        {
            using var c = new SmtpClient(cfg["Smtp:Host"], cfg.GetValue("Smtp:Port", 587)) { EnableSsl = true, Credentials = new NetworkCredential(cfg["Smtp:User"], cfg["Smtp:Password"]) };
            using var msg = new MailMessage(cfg["Smtp:From"]!, m.ToEmail, m.Subject, m.Body ?? "");
            if (pdf != null) msg.Attachments.Add(new Attachment(new MemoryStream(pdf), pdfName ?? "PO.pdf", "application/pdf"));
            await c.SendMailAsync(msg);
            m.Status = "Sent"; m.SentAt = DateTime.UtcNow; m.ErrorMessage = null;
        }
        catch (Exception ex)
        {
            m.Status = "Failed"; m.ErrorMessage = ex.Message; m.RetryCount++;
            log.LogError(ex, "Mail failed to {To}", m.ToEmail);
        }
        await db.SaveChangesAsync();
    }

    /// <summary>Re-send one logged mail (regenerates the PO PDF when it had one).</summary>
    public async Task RetryOneAsync(EmailLog m, PdfService pdf)
    {
        byte[]? bytes = null; string? name = null;
        if (m.AttachPo && m.RequestId != null)
        {
            bytes = await pdf.BuildVendorPoAsync(m.RequestId.Value);
            name = (await db.RequestHeaders.Where(r => r.RequestId == m.RequestId).Select(r => r.PONumber).FirstOrDefaultAsync() ?? "PO") + ".pdf";
        }
        await SendAsync(m, bytes, name);
    }

    /// <summary>Called by the background worker: retry Pending / Failed mails with back-off (max 5 tries).</summary>
    public async Task RetryDueAsync(PdfService pdf)
    {
        if (!SmtpConfigured) return;
        var now = DateTime.UtcNow;
        var due = await db.EmailLogs.Where(x => (x.Status == "Pending" || x.Status == "Failed") && x.RetryCount < 5)
            .OrderBy(x => x.EmailLogId).Take(50).ToListAsync();
        foreach (var m in due)
        {
            if (m.LastAttemptAt != null && m.LastAttemptAt > now.AddMinutes(-5 * (m.RetryCount + 1))) continue;
            await RetryOneAsync(m, pdf);
        }
    }
}
