using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using StationeryApi.Data;
using StationeryApi.Models;
namespace StationeryApi.Services;

/// <summary>Issues the application JWT. Roles: Requestor (everyone), Approver (derived from hierarchy), HRAD, Admin.</summary>
public class TokenService(IConfiguration cfg, AppDbContext db)
{
    public async Task<string[]> RolesAsync(Employee e)
    {
        var r = new HashSet<string> { "Requestor" };
        if (e.Role is "HRAD" or "Admin") r.Add(e.Role);
        var approver = e.Role is "ReportingManager" or "DeptHead" or "DivHead"
            || await db.Employees.AnyAsync(x => x.ReportingManagerId == e.EmployeeId && x.IsActive)
            || await db.Departments.AnyAsync(d => d.DepartmentHeadId == e.EmployeeId)
            || await db.Divisions.AnyAsync(d => d.DivisionHeadId == e.EmployeeId)
            || await db.Delegations.AnyAsync(d => d.ToEmployeeId == e.EmployeeId && d.IsActive && d.EndDate >= DateTime.Today);
        if (approver) r.Add("Approver");
        return r.ToArray();
    }

    public async Task<(string Token, DateTime Expires, string[] Roles)> IssueAsync(Employee e)
    {
        var roles = await RolesAsync(e);
        var jwt = cfg.GetSection("Jwt");
        var expires = DateTime.UtcNow.AddMinutes(jwt.GetValue("ExpiryMinutes", 480));
        var claims = new List<Claim>
        {
            new("sub", e.EmployeeId.ToString()), new("email", e.Email.ToLowerInvariant()), new("name", e.FullName),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };
        claims.AddRange(roles.Select(x => new Claim("role", x)));
        var creds = new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt["Key"]!)), SecurityAlgorithms.HmacSha256);
        var token = new JwtSecurityToken(jwt["Issuer"], jwt["Audience"], claims, DateTime.UtcNow, expires, creds);
        return (new JwtSecurityTokenHandler().WriteToken(token), expires, roles);
    }
}
