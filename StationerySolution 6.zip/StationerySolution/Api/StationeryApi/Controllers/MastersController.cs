using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Models;
using StationeryApi.Services;
namespace StationeryApi.Controllers;

/// <summary>Full CRUD for masters: items, categories, vendors, divisions, departments, employees.
/// Read: any signed-in user. Create / Update / Delete: Admin only. Delete is a hard delete and is rejected
/// when the record is referenced (deactivate with IsActive instead).</summary>
[Authorize, ApiController, Route("api/masters")]
public class MastersController(AppDbContext db, CurrentUser user) : ControllerBase
{
    private static readonly JsonSerializerOptions J = new(JsonSerializerDefaults.Web);
    private static IQueryable<T> Q<T>(DbSet<T> s, bool? a) where T : class, IActive =>
        a == null ? s.AsNoTracking() : s.AsNoTracking().Where(x => x.IsActive == a);

    // ---------- READ ----------
    [HttpGet("{entity}")]
    public async Task<IActionResult> List(string entity, bool? active) => entity switch
    {
        "items" => Ok(await Q(db.Items, active).OrderBy(x => x.ItemName).ToListAsync()),
        "categories" => Ok(await Q(db.Categories, active).OrderBy(x => x.CategoryName).ToListAsync()),
        "vendors" => Ok(await Q(db.Vendors, active).OrderBy(x => x.VendorName).ToListAsync()),
        "divisions" => Ok(await Q(db.Divisions, active).OrderBy(x => x.DivisionName).ToListAsync()),
        "departments" => Ok(await Q(db.Departments, active).OrderBy(x => x.DepartmentName).ToListAsync()),
        "employees" => Ok(await Q(db.Employees, active).OrderBy(x => x.FullName)
            .Select(e => new { e.EmployeeId, e.EmployeeCode, e.FullName, e.Email, e.DepartmentId, e.DivisionId, e.ReportingManagerId, e.Role, e.IsActive }).ToListAsync()),
        _ => NotFound()
    };

    [HttpGet("{entity}/{id:int}")]
    public async Task<IActionResult> GetOne(string entity, int id)
    {
        object? o = entity switch
        {
            "items" => await db.Items.AsNoTracking().FirstOrDefaultAsync(x => x.ItemId == id),
            "categories" => await db.Categories.AsNoTracking().FirstOrDefaultAsync(x => x.CategoryId == id),
            "vendors" => await db.Vendors.AsNoTracking().FirstOrDefaultAsync(x => x.VendorId == id),
            "divisions" => await db.Divisions.AsNoTracking().FirstOrDefaultAsync(x => x.DivisionId == id),
            "departments" => await db.Departments.AsNoTracking().FirstOrDefaultAsync(x => x.DepartmentId == id),
            "employees" => await db.Employees.AsNoTracking().Where(x => x.EmployeeId == id)
                .Select(e => new { e.EmployeeId, e.EmployeeCode, e.FullName, e.Email, e.DepartmentId, e.DivisionId, e.ReportingManagerId, e.Role, e.IsActive }).FirstOrDefaultAsync(),
            _ => null
        };
        return o == null ? NotFound() : Ok(o);
    }

    // ---------- CREATE ----------
    [HttpPost("{entity}"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> Create(string entity, [FromBody] JsonElement body) => entity switch
    {
        "items" => await Add(db.Items, body, "ItemId"),
        "categories" => await Add(db.Categories, body, "CategoryId"),
        "vendors" => await Add(db.Vendors, body, "VendorId"),
        "divisions" => await Add(db.Divisions, body, "DivisionId"),
        "departments" => await Add(db.Departments, body, "DepartmentId"),
        "employees" => await Add(db.Employees, body, "EmployeeId"),
        _ => NotFound()
    };

    // ---------- UPDATE ----------
    [HttpPut("{entity}/{id:int}"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> Update(string entity, int id, [FromBody] JsonElement body) => entity switch
    {
        "items" => await Upd(db.Items, id, body, "ItemId"),
        "categories" => await Upd(db.Categories, id, body, "CategoryId"),
        "vendors" => await Upd(db.Vendors, id, body, "VendorId"),
        "divisions" => await Upd(db.Divisions, id, body, "DivisionId"),
        "departments" => await Upd(db.Departments, id, body, "DepartmentId"),
        "employees" => await Upd(db.Employees, id, body, "EmployeeId"),
        _ => NotFound()
    };

    // ---------- DELETE ----------
    [HttpDelete("{entity}/{id:int}"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(string entity, int id)
    {
        if (entity == "employees" && id == (await user.GetAsync()).EmployeeId) throw new InvalidOperationException("You cannot delete your own account");
        return entity switch
        {
            "items" => await Del(db.Items, id),
            "categories" => await Del(db.Categories, id),
            "vendors" => await Del(db.Vendors, id),
            "divisions" => await Del(db.Divisions, id),
            "departments" => await Del(db.Departments, id),
            "employees" => await Del(db.Employees, id),
            _ => NotFound()
        };
    }

    private static string Key<T>(T e, string key) => typeof(T).GetProperty(key)!.GetValue(e)!.ToString()!;

    private async Task<IActionResult> Add<T>(DbSet<T> set, JsonElement b, string key) where T : class
    {
        var e = b.Deserialize<T>(J)!;
        typeof(T).GetProperty(key)!.SetValue(e, 0);
        set.Add(e);
        await db.SaveChangesAsync();
        db.Audit(typeof(T).Name, Key(e, key), "Create", null, JsonSerializer.Serialize(e, J), user.Email);
        await db.SaveChangesAsync();
        return Ok(e);
    }

    private async Task<IActionResult> Upd<T>(DbSet<T> set, int id, JsonElement b, string key) where T : class
    {
        var cur = await set.FindAsync(id);
        if (cur == null) return NotFound();
        var old = JsonSerializer.Serialize(cur, J);
        var inc = b.Deserialize<T>(J)!;
        typeof(T).GetProperty(key)!.SetValue(inc, id);
        db.Entry(cur).CurrentValues.SetValues(inc);
        db.Audit(typeof(T).Name, id.ToString(), "Update", old, JsonSerializer.Serialize(cur, J), user.Email);
        await db.SaveChangesAsync();
        return Ok(cur);
    }

    private async Task<IActionResult> Del<T>(DbSet<T> set, int id) where T : class
    {
        var cur = await set.FindAsync(id);
        if (cur == null) return NotFound();
        var old = JsonSerializer.Serialize(cur, J);
        set.Remove(cur);
        db.Audit(typeof(T).Name, id.ToString(), "Delete", old, null, user.Email);
        await db.SaveChangesAsync();             // FK violation -> friendly 400 from ExceptionMiddleware
        return NoContent();
    }
}
