using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Services;
namespace StationeryApi.Controllers;

[Authorize, ApiController, Route("api/reports")]
public class ReportsController(AppDbContext db, CurrentUser user) : ControllerBase
{
    [HttpGet("export")]
    public async Task<IActionResult> Export(DateTime? from, DateTime? to, int? deptId)
    {
        var me = await user.GetAsync();
        var rows = await ReportQuery.Scope(db, me, from, to, deptId).AsNoTracking().OrderBy(x => x.RequestDate)
            .Select(x => new { x.RequestNo, x.RequestDate, Requestor = x.Requestor.FullName, Dept = x.Department!.DepartmentName, x.Status, x.TotalAmount }).ToListAsync();
        using var wb = new XLWorkbook();
        var ws = wb.AddWorksheet("Requests");
        string[] heads = { "Request No", "Date", "Requestor", "Department", "Status", "Total" };
        for (int c = 0; c < heads.Length; c++) { ws.Cell(1, c + 1).Value = heads[c]; ws.Cell(1, c + 1).Style.Font.Bold = true; }
        int r = 2;
        foreach (var x in rows)
        {
            ws.Cell(r, 1).Value = x.RequestNo; ws.Cell(r, 2).Value = x.RequestDate; ws.Cell(r, 3).Value = x.Requestor;
            ws.Cell(r, 4).Value = x.Dept; ws.Cell(r, 5).Value = x.Status; ws.Cell(r, 6).Value = x.TotalAmount; r++;
        }
        ws.Cell(r, 5).Value = "Total"; ws.Cell(r, 6).FormulaA1 = $"SUM(F2:F{r - 1})"; ws.Row(r).Style.Font.Bold = true;
        ws.Columns().AdjustToContents();
        using var ms = new MemoryStream();
        wb.SaveAs(ms);
        return File(ms.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "stationery-report.xlsx");
    }
}
