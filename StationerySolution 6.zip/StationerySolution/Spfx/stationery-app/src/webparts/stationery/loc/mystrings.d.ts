declare interface IStationeryWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ApiBaseUrlFieldLabel: string;
  ApiResourceFieldLabel: string;
}
declare module 'StationeryWebPartStrings' {
  const strings: IStationeryWebPartStrings;
  export = strings;
}
