import * as React from 'react';
import { useState } from 'react';
import { DefaultButton, TextField } from '@fluentui/react';
import { ApiService } from '../services/ApiService';
import { RequestDetail } from '../models';
import { card, h2, mut } from './ui';

interface Props { api: ApiService; r: RequestDetail; onChanged: (msg: string) => void; onError: (msg: string) => void; }

/** Requestor (or Admin) can withdraw a request until it has been ordered. */
const CancelCard: React.FC<Props> = ({ api, r, onChanged, onError }) => {
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  if (['Draft', 'InReview', 'AmendRequired', 'HRApproval'].indexOf(r.status) < 0) return null;

  const cancel = async (): Promise<void> => {
    if (!reason.trim()) { onError('Enter a reason to cancel this request'); return; }
    if (!window.confirm('Cancel request ' + r.requestNo + '? This cannot be undone.')) return;
    setBusy(true);
    try { await api.post('requests/' + r.requestId + '/cancel', { action: 'Cancel', comments: reason }); onChanged('Request cancelled'); }
    catch (e) { onError((e as Error).message); }
    setBusy(false);
  };
  return (
    <div style={card}>
      <h2 style={h2}>Cancel request</h2>
      <div style={{ ...mut, marginBottom: 8 }}>Withdraw this request. It stays in history as Cancelled.</div>
      <TextField placeholder="Reason (required)" value={reason} onChange={(_, v) => setReason(v || '')} />
      <DefaultButton text="Cancel this request" disabled={busy} styles={{ root: { marginTop: 10, color: '#dc2626' } }} onClick={cancel} />
    </div>);
};
export default CancelCard;
