import * as React from 'react';
import { STATUS } from './ui';

const StatusChip: React.FC<{ status: string }> = ({ status }) => {
  const s = STATUS[status] || [status, '#6b7280'];
  return <span style={{ background: s[1], color: '#fff', borderRadius: 20, padding: '2px 10px', fontSize: 12, whiteSpace: 'nowrap' }}>{s[0]}</span>;
};
export default StatusChip;
