import * as React from 'react';
import { useEffect, useState } from 'react';
import { DefaultButton, Dropdown, MessageBar, MessageBarType, Pivot, PivotItem, PrimaryButton, SearchBox, Spinner } from '@fluentui/react';
import { ApiService } from '../services/ApiService';
import { ListRow, Me, RouteName } from '../models';
import { card, row, h1, th, td, fmt, fmtDate, STATUS, STAGE } from './ui';
import StatusChip from './StatusChip';
import Pager from './Pager';

interface Props { api: ApiService; me: Me; go: (n: RouteName, id?: number) => void; }

const RequestList: React.FC<Props> = ({ api, me, go }) => {
  const [view, setView] = useState('pending');
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [from, setFrom] = useState(''); const [to, setTo] = useState('');
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(20);
  const [dept, setDept] = useState(0);
  const [depts, setDepts] = useState<any[]>([]);
  const [tick, setTick] = useState(0);
  const priv = me.roles.indexOf('HRAD') > -1 || me.roles.indexOf('Admin') > -1;
  const [data, setData] = useState<{ total: number; rows: ListRow[] }>({ total: 0, rows: [] });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string>();

  const load = (): void => {
    setBusy(true);
    let q = 'view=' + view + '&page=' + page + '&pageSize=' + size;
    if (dept) q += '&deptId=' + dept;
    if (status) q += '&status=' + status;
    if (search) q += '&search=' + encodeURIComponent(search);
    if (from) q += '&from=' + from;
    if (to) q += '&to=' + to;
    api.get<{ total: number; rows: ListRow[] }>('requests?' + q).then(setData).catch((e: Error) => setErr(e.message)).then(() => setBusy(false));
  };
  useEffect(() => { if (priv) api.get<any[]>('masters/departments?active=true').then(setDepts).catch(() => undefined); }, []);
  useEffect(load, [view, status, page, size, dept, tick]);
  const clear = (): void => { setSearch(''); setStatus(''); setFrom(''); setTo(''); setDept(0); setPage(1); setTick(tick + 1); };

  const submitRow = (id: number): void => {
    setErr(undefined);
    api.post('requests/' + id + '/submit').then(load).catch((e: Error) => setErr(e.message));
  };

  const statusOpts = [{ key: '', text: 'All statuses' }].concat(Object.keys(STATUS).map(k => ({ key: k, text: STATUS[k][0] })));
  return (<>
    <div style={{ ...row(), justifyContent: 'space-between' }}>
      <h1 style={h1}>Requests</h1>
      <PrimaryButton text="+ New request" onClick={() => go('new')} />
    </div>
    <div style={card}>
      <Pivot selectedKey={view} onLinkClick={i => { setView(i!.props.itemKey!); setPage(1); }}>
        <PivotItem headerText="Pending for me" itemKey="pending" />
        <PivotItem headerText="My requests" itemKey="mine" />
        <PivotItem headerText={me.roles.indexOf('HRAD') > -1 || me.roles.indexOf('Admin') > -1 ? 'All requests' : 'Related to me'} itemKey="all" />
      </Pivot>
      <div style={{ ...row(8), margin: '14px 0' }}>
        <SearchBox placeholder="Search request no / requestor" styles={{ root: { width: 260 } }} value={search}
          onChange={(_, v) => setSearch(v || '')} onSearch={() => { setPage(1); load(); }} onClear={() => setSearch('')} />
        <Dropdown selectedKey={status} options={statusOpts} styles={{ root: { width: 170 } }} onChange={(_, o) => { setStatus(String(o!.key)); setPage(1); }} />
        <input type="date" value={from} onChange={e => setFrom(e.target.value)} aria-label="From" />
        <input type="date" value={to} onChange={e => setTo(e.target.value)} aria-label="To" />
        {priv && <Dropdown selectedKey={dept} styles={{ root: { width: 190 } }} options={[{ key: 0, text: 'All departments' }].concat(depts.map(d => ({ key: d.departmentId, text: d.departmentName })))}
          onChange={(_, o) => { setDept(Number(o!.key)); setPage(1); }} />}
        <DefaultButton text="Apply" onClick={() => { setPage(1); load(); }} />
        <DefaultButton text="Clear filters" onClick={clear} />
      </div>
      {err && <MessageBar messageBarType={MessageBarType.error} onDismiss={() => setErr(undefined)}>{err}</MessageBar>}
      {busy ? <Spinner /> : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead><tr>{['Request no', 'Date', 'Requestor', 'Department', 'Amount', 'Status', 'With', ''].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
            <tbody>
              {data.rows.length === 0 && <tr><td style={td} colSpan={8}>Nothing here.</td></tr>}
              {data.rows.map(r => (
                <tr key={r.requestId} onClick={() => go('detail', r.requestId)} style={{ cursor: 'pointer' }}>
                  <td style={td}><b>{r.requestNo}</b></td><td style={td}>{fmtDate(r.requestDate)}</td><td style={td}>{r.requestorName}</td>
                  <td style={td}>{r.departmentName}</td><td style={td}>{fmt(r.totalAmount)}</td>
                  <td style={td}><StatusChip status={r.status} /></td>
                  <td style={td}>{r.currentApproverName || (r.currentStage ? STAGE[r.currentStage] : '-')}</td>
                  <td style={td} onClick={e => e.stopPropagation()}>
                    {r.requestorId === me.employeeId && (r.status === 'Draft' || r.status === 'AmendRequired') && (
                      <div style={row(6)}>
                        <DefaultButton text="Edit" onClick={() => go('edit', r.requestId)} />
                        <PrimaryButton text={r.status === 'Draft' ? 'Submit' : 'Resubmit'} onClick={() => submitRow(r.requestId)} />
                      </div>)}
                  </td>
                </tr>))}
            </tbody>
          </table>
        </div>)}
      <Pager page={page} total={data.total} pageSize={size} onPage={setPage} onSize={n => { setSize(n); setPage(1); }} />
    </div>
  </>);
};
export default RequestList;
