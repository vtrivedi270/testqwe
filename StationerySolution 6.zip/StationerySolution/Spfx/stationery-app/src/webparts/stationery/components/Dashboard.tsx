import * as React from 'react';
import { useEffect, useState } from 'react';
import { DefaultButton, Dropdown, Spinner } from '@fluentui/react';
import { ApiService } from '../services/ApiService';
import { Me, RouteName } from '../models';
import { card, row, h1, h2, mut, fmt, C, th, td } from './ui';

interface Props { api: ApiService; me: Me; go: (n: RouteName, id?: number) => void; }

const Kpi = (p: { t: string; v: string | number; color: string }) => (
  <div style={{ ...card, flex: 1, minWidth: 170, position: 'relative', overflow: 'hidden' }}>
    <div style={{ position: 'absolute', right: -14, top: -14, width: 70, height: 70, borderRadius: '50%', background: p.color, opacity: 0.18 }} />
    <div style={mut}>{p.t}</div><div style={{ fontSize: 28, fontWeight: 700 }}>{p.v}</div>
  </div>);

const HBars = (p: { data: any[]; label: string; value: string }) => {
  const max = Math.max(1, ...p.data.map(d => d[p.value]));
  return (<div>{p.data.map((d, i) => (
    <div key={i} style={{ ...row(10), flexWrap: 'nowrap', marginBottom: 10 }}>
      <span style={{ width: 120, fontSize: 13, color: C.mut, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d[p.label]}</span>
      <div style={{ flex: 1, background: '#eef2ff', borderRadius: 6 }}><div style={{ height: 12, borderRadius: 6, width: (d[p.value] / max * 100) + '%', background: 'linear-gradient(90deg,#4338ca,#a855f7)' }} /></div>
      <b style={{ fontSize: 13, minWidth: 70, textAlign: 'right' }}>{fmt(d[p.value])}</b>
    </div>))}</div>);
};

const Dashboard: React.FC<Props> = ({ api, me, go }) => {
  const year = new Date().getFullYear();
  const [from, setFrom] = useState(year + '-01-01');
  const [to, setTo] = useState(new Date().toISOString().slice(0, 10));
  const [deptId, setDeptId] = useState<number>(0);
  const [depts, setDepts] = useState<any[]>([]);
  const [d, setD] = useState<any>();
  const [busy, setBusy] = useState(true);

  const qs = (): string => 'from=' + from + '&to=' + to + (deptId ? '&deptId=' + deptId : '');
  const load = async (): Promise<void> => {
    setBusy(true);
    const q = qs();
    const r = await Promise.all([api.get<any>('dashboard/summary?' + q), api.get<any[]>('dashboard/monthly?' + q),
      api.get<any[]>('dashboard/by-department?' + q), api.get<any[]>('dashboard/by-item?' + q), api.get<any[]>('dashboard/store')]);
    setD({ sum: r[0], monthly: r[1], dept: r[2], item: r[3], store: r[4] });
    setBusy(false);
  };
  useEffect(() => { api.get<any[]>('masters/departments?active=true').then(setDepts); load(); }, []);

  const maxM = d ? Math.max(1, ...d.monthly.map((m: any) => m.totalCost)) : 1;
  return (<>
    <div style={{ ...row(), justifyContent: 'space-between' }}>
      <h1 style={h1}>Dashboard</h1>
      <div style={row(8)}>
        <input type="date" value={from} onChange={e => setFrom(e.target.value)} aria-label="From" />
        <input type="date" value={to} onChange={e => setTo(e.target.value)} aria-label="To" />
        {me.roles.indexOf('HRAD') > -1 || me.roles.indexOf('Admin') > -1
          ? <Dropdown placeholder="All departments" selectedKey={deptId || undefined} styles={{ root: { width: 190 } }}
              options={[{ key: 0, text: 'All departments' }].concat(depts.map(x => ({ key: x.departmentId, text: x.departmentName })))}
              onChange={(_, o) => setDeptId(Number(o!.key))} /> : null}
        <DefaultButton text="Apply" onClick={load} />
        <DefaultButton text="Export Excel" iconProps={{ iconName: 'ExcelDocument' }} onClick={() => api.download('reports/export?' + qs(), 'stationery-report.xlsx')} />
      </div>
    </div>
    {busy || !d ? <Spinner label="Loading..." /> : <>
      <div style={row(14)}>
        <Kpi t="Total requests" v={d.sum.totalRequests} color="#6366f1" />
        <Kpi t="Waiting for me" v={d.sum.pending} color="#f59e0b" />
        <Kpi t="Total cost" v={fmt(d.sum.totalCost)} color="#10b981" />
        <Kpi t="Low-stock items" v={d.sum.lowStock} color="#ef4444" />
      </div>
      <div style={{ ...row(14), alignItems: 'stretch' }}>
        <div style={{ ...card, flex: 1, minWidth: 300 }}><h2 style={h2}>Monthly cost</h2>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 14, height: 170 }}>
            {d.monthly.length === 0 ? <span style={mut}>No data</span> : d.monthly.map((m: any) => (
              <div key={m.month} style={{ flex: 1, textAlign: 'center' }}>
                <div style={{ fontSize: 11, fontWeight: 600 }}>{fmt(m.totalCost)}</div>
                <div style={{ height: Math.max(4, m.totalCost / maxM * 120), borderRadius: '6px 6px 0 0', background: 'linear-gradient(180deg,#a855f7,#4338ca)' }} />
                <div style={mut}>{m.month}</div>
              </div>))}
          </div></div>
        <div style={{ ...card, flex: 1, minWidth: 300 }}><h2 style={h2}>Cost by department</h2><HBars data={d.dept} label="departmentName" value="totalCost" /></div>
      </div>
      <div style={{ ...row(14), alignItems: 'stretch' }}>
        <div style={{ ...card, flex: 1, minWidth: 300 }}><h2 style={h2}>Top items by cost</h2><HBars data={d.item} label="itemName" value="totalCost" /></div>
        <div style={{ ...card, flex: 1, minWidth: 300 }}><h2 style={h2}>Store availability</h2>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}><thead><tr><th style={th}>Item</th><th style={th}>In stock</th><th style={th} /></tr></thead>
            <tbody>{d.store.map((s: any) => (<tr key={s.itemId}><td style={td}>{s.itemName}</td><td style={td}>{s.stockQty} {s.unit}</td>
              <td style={td}><span style={{ background: s.isLow ? '#dc2626' : '#15803d', color: '#fff', borderRadius: 12, padding: '2px 8px', fontSize: 12 }}>{s.isLow ? 'Low' : 'OK'}</span></td></tr>))}</tbody></table>
        </div>
      </div>
    </>}
  </>);
};
export default Dashboard;
