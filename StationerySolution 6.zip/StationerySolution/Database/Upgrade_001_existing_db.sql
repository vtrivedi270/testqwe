/* Run ONLY on a database created with the first version of StationeryDB.sql.
   Adds: Cancelled status, new history actions, RequestItem.OrderedQty, StockTransaction.Note. */
USE StationeryDB;
GO
IF COL_LENGTH('RequestItem','OrderedQty') IS NULL
  ALTER TABLE RequestItem ADD OrderedQty DECIMAL(18,2) NOT NULL CONSTRAINT DF_RI_Ordered DEFAULT 0;
IF COL_LENGTH('StockTransaction','Note') IS NULL
  ALTER TABLE StockTransaction ADD Note NVARCHAR(300) NULL;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_Stock_Item')
  CREATE INDEX IX_Stock_Item ON StockTransaction(ItemId, TxnDate DESC);
GO
/* Replace the unnamed CHECK constraints */
DECLARE @n sysname, @sql nvarchar(max);
SELECT @n = name FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID('RequestHeader') AND definition LIKE '%PartialClosed%';
IF @n IS NOT NULL EXEC('ALTER TABLE RequestHeader DROP CONSTRAINT ' + @n);
ALTER TABLE RequestHeader ADD CONSTRAINT CK_Req_Status CHECK (Status IN
 ('Draft','InReview','AmendRequired','Rejected','HRApproval','Ordered','Delivered','Closed','PartialClosed','Cancelled'));
SET @n = NULL;
SELECT @n = name FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID('ApprovalHistory') AND definition LIKE '%VendorSent%';
IF @n IS NOT NULL EXEC('ALTER TABLE ApprovalHistory DROP CONSTRAINT ' + @n);
ALTER TABLE ApprovalHistory ADD CONSTRAINT CK_Hist_Action CHECK (Action IN
 ('Submit','Approve','Reject','Amend','Resubmit','VendorSent','Delivered','Handover','Close','PartialClose','Query',
  'Cancel','Reorder','HradEdit','CloseShort','ResendPO'));
/* existing vendor orders: treat approved-minus-store as ordered */
UPDATE RequestItem SET OrderedQty = ISNULL(ApprovedQty, Quantity) - IssuedFromStockQty WHERE OrderedQty = 0;
GO
