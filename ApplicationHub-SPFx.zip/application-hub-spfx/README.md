# Application Hub: SharePoint web part (SPFx 1.19)

One web part, **ApplicationHub**, with tabs for requestors (new request, my requests, approvals, approved by me, delegation) and, for Admin users, admin studio, master data, and users.

## Requirements
- Node.js 18.17.1 or later, 18.20.x recommended (`.nvmrc`). Node 18.8.2 is too old for SPFx 1.19.
- A SharePoint Online tenant with an app catalog, and permission to deploy solutions.
- The Application Hub API running over HTTPS (see the API README).

## First-time setup
    npm install
    npx gulp trust-dev-cert

## Local testing
1. Set the API address and a development token in the web part properties (`apiBaseUrl`, `devToken`).
2. `npm run serve`, then open the workbench from your tenant (`config/serve.json` sets the page).

## Package for SharePoint
    npm run bundle
    npm run package-solution

Upload `sharepoint/solution/application-hub.sppkg` to the tenant app catalog (the path is set in `config/package-solution.json`), trust it, and add the web part to a page.

## Before production (required)
- **Sign-in:** The API accepts only its own tokens. Register the API in Azure AD, request a token for it in `ApplicationHubWebPart.ts` (`this.context.aadTokenProviderFactory`), and update the API to accept Azure AD tokens. Until then the web part works only with `devToken`.
- **CORS:** Set `Cors:Origin` on the API to your tenant origin. The API accepts one origin.
- **Remove `devToken`:** Page properties can be read by anyone who can edit the page. Remove the property from the manifest and the property pane.
- **IDs:** The web part ID and solution ID were generated for this project. Keep them stable once deployed.

## Project layout
- `config/`: build settings (`config.json`, `package-solution.json`, `serve.json`, `write-manifests.json`, `copy-assets.json`)
- `src/webparts/applicationHub/`: web part, manifest, localized strings
- `src/webparts/applicationHub/components/`: screens (AdminStudio, MastersPanel, UsersPanel, NewRequest, RequestList, RequestDetail, Delegation, FormRenderer, FieldBuilder, Shell)
- `src/webparts/applicationHub/services/`: API client (`hubApi.ts`) and master definitions (`masterDefs.ts`)

## Note on generated files
These files follow the SPFx 1.19 template but were written by hand, because the Yeoman generator could not run in the build environment. If `npm install` reports a version conflict, run `yo @microsoft/sharepoint` in an empty folder once and align this project's dependency versions with its output.
