# Application Hub: SPFx admin studio

This folder holds the source for the admin studio web part. The SPFx project skeleton is created by the Microsoft generator, then these files are copied in.

## Requirements
- Node.js 18.17.1 or later (SPFx 1.19 does not support 18.8.2). Use 18.20.x or 20.x LTS.
- SharePoint Online tenant with an app catalog
- Global tools: `npm i -g yo @microsoft/generator-sharepoint`

## Steps
1. Create the project:
   `yo @microsoft/sharepoint` → solution name `application-hub`, web part, React, web part name `ApplicationHub`.
2. Replace the generated `src/webparts/applicationHub` folder with this folder's `src/webparts/applicationHub`.
3. In `config/config.json`, keep the `ApplicationHubWebPart` entry. The `id` must match the generated web part id.
4. `npm install`, then `gulp serve` for local testing against the SharePoint workbench.
5. `gulp bundle --ship` and `gulp package-solution --ship`, then upload `sharepoint/solution/application-hub.sppkg` to the app catalog.

## Before production (required)
- **Authentication:** The API currently accepts only its own tokens. Register the API in Azure AD, have `hubApi.ts` request a token for that API (`this.context.aadTokenProviderFactory`), and update the API to validate Azure AD tokens. Without this, the web part only works with the development token.
- **CORS:** Set `Cors:Origin` on the API to your SharePoint tenant origin. The API currently allows one origin.
- **Remove the development token property** from `ApplicationHubWebPart.ts` once Azure AD is in place. A token stored in page properties can be read by anyone who can edit the page.
- **Admin-only:** The API enforces the Admin role. The web part still shows the screen to anyone who adds it, so limit who can edit the page.

## Files
- `services/hubApi.ts`: API calls with bearer tokens
- `components/AdminStudio.tsx`: create application, edit and save workflow, publish
- `ApplicationHubWebPart.ts`: web part entry and property pane
