# Application Hub (Phase 1: API + Database + Auth + React shell)

## Prerequisites
- .NET 8 SDK
- SQL Server 2019+ (or SQL Server Express / LocalDB)
- Node.js 18 (18.20.x recommended; 18.8.2 works but has known security fixes in later 18.x releases)

## 1. Database
Run `database/01_schema.sql` in SSMS or sqlcmd. It creates database `ApplicationHub` and all tables.

## 2. Secrets (never commit these)
Set these as environment variables or with `dotnet user-secrets` (in `backend/ApplicationHub.Api`):

    ConnectionStrings__Hub = Server=localhost;Database=ApplicationHub;Trusted_Connection=True;TrustServerCertificate=True;
    Jwt__Key               = <random string, 32+ characters>
    Seed__AdminEmail       = admin@yourcompany.com
    Seed__AdminPassword    = <12+ characters, used once to create the first admin>

## 3. API
    cd backend/ApplicationHub.Api
    dotnet run

Swagger is disabled in this phase. The API listens on https://localhost:7001 (see launchSettings).

## 4. Frontend (Vite dev server)
    cd frontend
    npm install
    npm run dev

Open http://localhost:5173. Vite proxies /api to the API.

## Security controls in this phase
- Passwords hashed with BCrypt (work factor 12)
- Account lockout after 5 failed logins (15 minutes)
- Generic login error messages (no user enumeration)
- Login rate limiting (5 attempts per minute per client)
- JWT access tokens: HMAC-SHA256, 15-minute lifetime, issuer and audience validated
- Refresh tokens: random 512-bit values, stored only as SHA-256 hashes, rotated on every use, httpOnly + Secure + SameSite=Strict cookie
- Secure by default: every endpoint requires authentication unless marked [AllowAnonymous]
- Role-based authorization (Admin, Requestor, approver roles)
- Parameterized SQL only (no string concatenation of user input)
- Input validation with data annotations and JSON validation
- Request body size and field length limits
- Security headers (nosniff, frame deny, no-referrer, CSP for API responses)
- Exception handler returns a generic error, never stack traces
- Audit log table for sensitive actions
- Access token kept in memory in the browser (not localStorage)

## Not yet included (next phases)
- Workflow engine (approve, amend, delegate, pull back, cancel, parallel steps)
- Approvals, delegations, email log APIs
- SPFx web parts (SharePoint Framework needs a tenant and the Yeoman generator; will be added as a separate project)
- Automated tests and CI pipeline
- Production HTTPS certificate and deployment settings

## Phase 2: workflow engine (added)
Run `database/02_workflow.sql` after `01_schema.sql`.

Endpoints (all require sign-in):
- `POST /api/requests` create (`submit: true` starts the workflow, `false` saves a draft)
- `GET  /api/requests/mine`, `GET /api/requests/inbox`, `GET /api/requests/approved`, `GET /api/requests/{id}`
- `POST /api/requests/{id}/approve | reject | amend | delegate | resubmit | pullback | cancel`
- `GET/POST/DELETE /api/delegations` (time-bound delegation of all your approvals)
- `GET /api/emails` (admins see all; others see mail addressed to them)
- `PUT /api/applications/{id}/workflow` (admin; sequential and parallel steps, role or group approvers, any/all rule)

Rules implemented: sequential and parallel steps, single-role and group approvers, any-one or all-must-approve, ask for amendment, resubmit (starts a new cycle), pull back (only before any action), cancel, delegation of a single step, and time-bound delegation of everything. Every state change runs in one transaction with the request row locked. Notifications are written to an outbox table in the same transaction and sent by a background worker.

Not yet built: the React screens for the workflow, the SPFx web parts, the mail provider integration (marked in `EmailWorker.cs`), and automated tests.

## Phase 3 (added)
- React screens: My approvals, New request (renders the application's form), My requests, Approved by me, Request detail (approve, ask to amend, reject, delegate a step, resubmit, pull back, cancel), Delegation, Emails.
- Mail: SMTP through MailKit, STARTTLS. Set `Smtp__Host`, `Smtp__User`, `Smtp__From`, and the password in the environment variable `SMTP_PASSWORD`. With no host set, mail is only logged.
- Users directory endpoint for pickers: `GET /api/users/directory` (names and roles, no emails).
- Unit tests for the workflow rules: `cd backend/ApplicationHub.Tests && dotnet test`.

Form definitions use this shape: `{ "fields": [ { "id": "f1", "label": "Leave type", "type": "dropdown", "required": true, "options": "Casual, Sick" } ] }`. Supported in the React screens: text, number, date, textarea, checkbox, dropdown. Lookups, dependent dropdowns, tables, line items and attachments display their stored values read-only until the master-data endpoints are added.

Convention: endpoints that return a plain table row keep column names as-is (`Id`, `Status`); endpoints that return objects shape their own property names.

## Phase 5 (added)
- Database: run `database/03_masters_users.sql` after 02. It creates the master tables (countries, states, cities, divisions, departments, employees, assets, vendors, stationery items) with starter data.
- Master data API: `GET /api/masters/{key}` (any signed-in user; active records only), `POST /api/masters/{key}`, `PUT /api/masters/{key}/{id}`, `DELETE /api/masters/{key}/{id}` (deactivates). Writes are admin only. Keys: countries, states, cities, divisions, departments, employees, assets, vendors, items.
- User administration (admin only): `GET/POST /api/admin/users`, `PUT /api/admin/users/{id}` (name, role, active), `POST /api/admin/users/{id}/reset-password`. Role changes, deactivation and password resets end the user's sessions.

Not yet included: master-data and user screens in React and SPFx, rich form controls in the builder (dependent, parent-child, table, line items, attachments), attachment storage, email templates, server-side reports and PDF, and the set-based inbox query.

## Phase 6 (step 1: master data and user screens)
- React: Master data and Users screens (admin studio menu).
- SPFx: the web part now opens a Shell with two tabs, Admin studio and Master data.
- Not yet in SPFx: user administration (next step for SPFx).

## Phase 7 (steps 1 to 3 complete)
- Step 1 (user screen in SPFx): third tab "Users" in the web part.
- Step 2 (form builder controls, React and SPFx): lookup, dependent dropdown, parent-child list, table (grid), line items, attachment. The request form renders them, and the server stores the values in the request payload.
- Step 3 (attachments): run `database/04_attachments.sql`. `POST /api/attachments` (multipart, one file, 10 MB, PDF/PNG/JPG/XLSX/DOCX, content checked against file signature). `GET /api/attachments/{id}` downloads for the uploader, admin, or someone involved in the request. Files are linked to the request when it is created or resubmitted.

Still open: server-side validation of submitted values against the form definition (the server stores the payload as sent), malware scanning of uploads, the requester screens in SPFx.

## Phase 8
- Server-side form validation: every create, save and resubmit is checked against the application's form definition. Required fields, types, options, lookups (must exist and be active), dependent and parent-child links, table rows, and attachment ownership are all checked. Line-item prices come from the stationery master, not from the client. Unknown fields are dropped. Errors come back as `fieldErrors` (field label and message).
- Database: no new script (the validator uses the existing tables).
- SPFx requestor screens: New request (form with all control types, save draft or submit), My requests, My approvals (approve, ask to amend, reject, delegate a step, resubmit, pull back, cancel), Approved by me, Delegation. Admin tabs appear only for the Admin role.

Still open: malware scanning of uploads, the SPFx sign-in (Azure AD), and automated tests for the validator.
