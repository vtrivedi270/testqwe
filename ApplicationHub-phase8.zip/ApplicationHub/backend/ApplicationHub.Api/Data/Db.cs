using Microsoft.Data.SqlClient;

namespace ApplicationHub.Api.Data;

/// Parameterized data access. Every value goes through a parameter, never string concatenation.
public sealed class Db(IConfiguration cfg)
{
    private readonly string _cs = cfg.GetConnectionString("Hub")
        ?? throw new InvalidOperationException("ConnectionStrings:Hub is not set.");

    public async Task<List<Dictionary<string, object?>>> QueryAsync(string sql, params (string Name, object? Value)[] ps)
    {
        await using var conn = new SqlConnection(_cs);
        await conn.OpenAsync();
        return await Tx.QueryOn(conn, null, sql, ps);
    }

    public async Task<int> ExecAsync(string sql, params (string Name, object? Value)[] ps)
    {
        await using var conn = new SqlConnection(_cs);
        await conn.OpenAsync();
        return await Tx.ExecOn(conn, null, sql, ps);
    }

    public async Task<int> ScalarIntAsync(string sql, params (string Name, object? Value)[] ps)
    {
        await using var conn = new SqlConnection(_cs);
        await conn.OpenAsync();
        await using var cmd = Tx.Build(conn, null, sql, ps);
        return Convert.ToInt32(await cmd.ExecuteScalarAsync());
    }

    /// Runs work in one transaction. Any exception rolls everything back.
    public async Task<T> InTransactionAsync<T>(Func<Tx, Task<T>> work)
    {
        await using var conn = new SqlConnection(_cs);
        await conn.OpenAsync();
        await using var trx = (SqlTransaction)await conn.BeginTransactionAsync();
        try
        {
            var result = await work(new Tx(conn, trx));
            await trx.CommitAsync();
            return result;
        }
        catch
        {
            await trx.RollbackAsync();
            throw;
        }
    }
}

public sealed class Tx(SqlConnection conn, SqlTransaction trx)
{
    public Task<List<Dictionary<string, object?>>> QueryAsync(string sql, params (string Name, object? Value)[] ps) =>
        QueryOn(conn, trx, sql, ps);

    public Task<int> ExecAsync(string sql, params (string Name, object? Value)[] ps) =>
        ExecOn(conn, trx, sql, ps);

    public async Task<int> ScalarIntAsync(string sql, params (string Name, object? Value)[] ps)
    {
        await using var cmd = Build(conn, trx, sql, ps);
        return Convert.ToInt32(await cmd.ExecuteScalarAsync());
    }

    internal static SqlCommand Build(SqlConnection c, SqlTransaction? t, string sql, (string Name, object? Value)[] ps)
    {
        var cmd = new SqlCommand(sql, c, t);
        foreach (var (n, v) in ps) cmd.Parameters.AddWithValue("@" + n, v ?? DBNull.Value);
        return cmd;
    }

    internal static async Task<List<Dictionary<string, object?>>> QueryOn(SqlConnection c, SqlTransaction? t, string sql, (string Name, object? Value)[] ps)
    {
        await using var cmd = Build(c, t, sql, ps);
        await using var r = await cmd.ExecuteReaderAsync();
        var list = new List<Dictionary<string, object?>>();
        while (await r.ReadAsync())
        {
            var row = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < r.FieldCount; i++) row[r.GetName(i)] = r.IsDBNull(i) ? null : r.GetValue(i);
            list.Add(row);
        }
        return list;
    }

    internal static async Task<int> ExecOn(SqlConnection c, SqlTransaction? t, string sql, (string Name, object? Value)[] ps)
    {
        await using var cmd = Build(c, t, sql, ps);
        return await cmd.ExecuteNonQueryAsync();
    }
}
