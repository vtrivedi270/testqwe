# Application Hub (aligned with StationerySolution)

```
Api/ApplicationHubApi/            .NET 8 Web API (same settings and startup style as StationeryApi)
Api/ApplicationHubApi.Tests/      xUnit tests for the workflow rules
Database/                         SQL Server scripts 01 to 04 (run in order)
Spfx/application-hub/             SPFx 1.18.2 web part (same toolchain as stationery-app)
Web/application-hub-react/        React client for the API (optional, not part of the stationery project)
Docs/02-Alignment-with-Stationery.md   differences and open decisions
```

## 1. Database
Run `Database/01_schema.sql`, `02_workflow.sql`, `03_masters_users.sql`, `04_attachments.sql` in SSMS, in that order. The database name is `ApplicationHubDB`.

## 2. API
```
cd Api/ApplicationHubApi
dotnet user-secrets set "Jwt:Key" "<32+ character random secret>"
dotnet user-secrets set "Seed:AdminEmail" "admin@yourcompany.com"
dotnet user-secrets set "Seed:AdminPassword" "<12+ characters>"
dotnet restore
dotnet run                 # https://localhost:7100 , Swagger: /swagger
```

## 3. SPFx web part (Node 18.17.1 to 18.19.x)
```
cd Spfx/application-hub
npm install
npx gulp trust-dev-cert
npm run serve
```
Package: `npm run bundle` then `npm run package-solution`.

## 4. React client (optional)
```
cd Web/application-hub-react
npm install
npm run dev                # http://localhost:5173, proxies /api to https://localhost:7100
```

See `Docs/02-Alignment-with-Stationery.md` for the remaining differences that need a decision.
