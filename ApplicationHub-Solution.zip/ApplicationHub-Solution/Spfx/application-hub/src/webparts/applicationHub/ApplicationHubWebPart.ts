import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IPropertyPaneConfiguration, PropertyPaneTextField } from '@microsoft/sp-property-pane';
import Shell from './components/Shell';
import { HubApi } from './services/hubApi';

export interface IApplicationHubWebPartProps {
  apiBaseUrl: string;
  /** Development only. Remove before production; production uses Azure AD tokens. */
  devToken: string;
}

export default class ApplicationHubWebPart extends BaseClientSideWebPart<IApplicationHubWebPartProps> {
  public render(): void {
    const getToken = async (): Promise<string> => {
      if (this.properties.devToken) return this.properties.devToken;
      // Production: request a token for the Application Hub API registration with Azure AD (see spfx/README.md).
      throw new Error('No token configured. Add a development token in the web part properties.');
    };
    const api = new HubApi(this.properties.apiBaseUrl || '', getToken);
    ReactDom.render(React.createElement(Shell, { api }), this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [{
        header: { description: 'Application Hub' },
        groups: [{
          groupName: 'Connection',
          groupFields: [
            PropertyPaneTextField('apiBaseUrl', { label: 'API base URL (https)' }),
            PropertyPaneTextField('devToken', { label: 'Development token (remove before production)' })
          ]
        }]
      }]
    };
  }
}
