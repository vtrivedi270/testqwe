import * as React from 'react';
import { HubApi, Stage, FormField, AppRow, UserRow } from '../services/hubApi';
import FieldBuilder, { validateFields } from './FieldBuilder';

const ROLES = ['Requestor', 'Reporting Manager', 'Department Head', 'Division Head', 'HR', 'Admin'];
const FIELD_TYPES = ['text', 'number', 'date', 'textarea', 'checkbox', 'dropdown'];

export interface AdminStudioProps { api: HubApi; }

const newStage = (n: number): Stage => ({ name: `Stage ${n}`, mode: 'Seq', kind: 'Role', role: 'Reporting Manager', rule: 'Any', actionType: 'Approve', members: [] });
const newField = (): FormField => ({ id: 'f' + Math.random().toString(36).slice(2, 8), label: '', type: 'text', required: false, options: '' });

const AdminStudio: React.FC<AdminStudioProps> = ({ api }) => {
  const [apps, setApps] = React.useState<AppRow[]>([]);
  const [users, setUsers] = React.useState<UserRow[]>([]);
  const [msg, setMsg] = React.useState('');
  const [busy, setBusy] = React.useState(false);
  const [name, setName] = React.useState('');
  const [desc, setDesc] = React.useState('');
  const [fields, setFields] = React.useState<FormField[]>([]);
  const [selId, setSelId] = React.useState<number | null>(null);
  const [selName, setSelName] = React.useState('');
  const [stages, setStages] = React.useState<Stage[]>([]);

  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    try { await fn(); } catch (e) { setMsg((e as Error).message); } finally { setBusy(false); }
  };

  const loadApps = () => run(async () => setApps(await api.listApps()));

  React.useEffect(() => {
    loadApps();
    api.users().then(setUsers).catch(() => setMsg('Could not load users.'));
  }, []);

  const openApp = (id: number, nm: string) => run(async () => {
    setMsg('');
    setSelId(id); setSelName(nm);
    setStages(await api.workflow(id));
  });

  const createApp = () => run(async () => {
    setMsg('');
    if (!name.trim()) throw new Error('Enter an application name.');
    if (fields.some((f) => !f.label.trim())) throw new Error('Every form field needs a label.');
    const fieldProblem = validateFields(fields);
    if (fieldProblem) throw new Error(fieldProblem);
    const id = await api.createApp(name.trim(), desc.trim() || null, fields.map((f) => ({ ...f, label: f.label.trim() })));
    setName(''); setDesc(''); setFields([]);
    await loadApps();
    await openApp(id, name.trim());
    setMsg('Application created. Now set its workflow, then publish it.');
  });

  const saveWorkflow = () => run(async () => {
    setMsg('');
    if (stages.length === 0) throw new Error('Add at least one stage.');
    for (const s of stages) {
      if (!s.name.trim()) throw new Error('Every stage needs a name.');
      if (s.kind === 'Group' && s.members.length === 0) throw new Error(`Group stage "${s.name}" needs at least one member.`);
    }
    await api.saveWorkflow(selId as number, stages);
    setMsg('Workflow saved.');
    await loadApps();
  });

  const publish = (id: number) => run(async () => {
    setMsg('');
    const saved = await api.workflow(id);
    if (saved.length === 0) throw new Error('Save a workflow with at least one stage before publishing.');
    if (!window.confirm('Publish this application? Requesters will be able to submit it.')) return;
    await api.publish(id);
    setMsg('Application published.');
    await loadApps();
  });

  const patchStage = (i: number, p: Partial<Stage>) => setStages(stages.map((s, j) => (j === i ? { ...s, ...p } : s)));

  return (
    <div>
      <h2>Admin studio</h2>
      {msg && <div className="notice">{msg}</div>}
      {busy && <div className="log">Working…</div>}

      <div className="card">
        <h3>Applications</h3>
        <table>
          <thead><tr><th>#</th><th>Name</th><th>Status</th><th>Stages</th><th /></tr></thead>
          <tbody>
            {apps.length === 0 && <tr><td colSpan={5} className="empty">No applications yet.</td></tr>}
            {apps.map((a) => (
              <tr key={a.Id}>
                <td>{a.Id}</td><td>{a.Name}</td><td>{a.Status}</td><td>{a.StageCount}</td>
                <td>
                  <button className="sec" onClick={() => openApp(a.Id, a.Name)}>Workflow</button>
                  {a.Status !== 'Published' && <button className="ok" onClick={() => publish(a.Id)}>Publish</button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selId !== null && (
        <div className="card">
          <h3>Workflow: {selName} <span className="log">#{selId}</span></h3>
          {stages.map((s, i) => (
            <div className="field" key={i}>
              <div className="row">
                <label className="stack" style={{ flex: 1 }}>Name<input value={s.name} onChange={(e) => patchStage(i, { name: e.target.value })} /></label>
                <label className="stack">Mode
                  <select value={s.mode} onChange={(e) => patchStage(i, { mode: e.target.value as Stage['mode'] })}>
                    <option value="Seq">Sequential</option><option value="Par">Parallel with previous</option>
                  </select>
                </label>
                <label className="stack">Approver
                  <select value={s.kind} onChange={(e) => patchStage(i, { kind: e.target.value as Stage['kind'] })}>
                    <option value="Role">Single role</option><option value="Group">Group of people</option>
                  </select>
                </label>
                <label className="stack">Action
                  <select value={s.actionType} onChange={(e) => patchStage(i, { actionType: e.target.value as Stage['actionType'] })}>
                    <option value="Approve">Approve</option><option value="Process">Process &amp; close</option>
                  </select>
                </label>
              </div>
              {s.kind === 'Role' ? (
                <div className="row">
                  <label className="stack">Role
                    <select value={s.role || ''} onChange={(e) => patchStage(i, { role: e.target.value })}>
                      {ROLES.map((r) => <option key={r}>{r}</option>)}
                    </select>
                  </label>
                </div>
              ) : (
                <div className="row">
                  <label className="stack">Rule
                    <select value={s.rule} onChange={(e) => patchStage(i, { rule: e.target.value as Stage['rule'] })}>
                      <option value="Any">Any one approves</option><option value="All">All must approve</option>
                    </select>
                  </label>
                  <div className="members">
                    {users.map((u) => (
                      <label key={u.Id} className="check">
                        <input type="checkbox" checked={s.members.includes(u.Id)}
                          onChange={(e) => patchStage(i, { members: e.target.checked ? [...s.members, u.Id] : s.members.filter((x) => x !== u.Id) })} />
                        {u.Name}
                      </label>
                    ))}
                  </div>
                </div>
              )}
              <div className="row">
                <button className="sec" disabled={i === 0} onClick={() => { const c = [...stages]; [c[i - 1], c[i]] = [c[i], c[i - 1]]; setStages(c); }}>↑</button>
                <button className="sec" disabled={i === stages.length - 1} onClick={() => { const c = [...stages]; [c[i + 1], c[i]] = [c[i], c[i + 1]]; setStages(c); }}>↓</button>
                <button className="bad" onClick={() => setStages(stages.filter((_, j) => j !== i))}>Remove</button>
              </div>
            </div>
          ))}
          <div className="row">
            <button className="sec" onClick={() => setStages([...stages, newStage(stages.length + 1)])}>+ Add stage</button>
            <button disabled={busy} onClick={saveWorkflow}>Save workflow</button>
          </div>
          <p className="log">Locked once the application has requests.</p>
        </div>
      )}

      <div className="card">
        <h3>New application</h3>
        <div className="row">
          <label className="stack" style={{ flex: 1 }}>Name<input value={name} maxLength={200} onChange={(e) => setName(e.target.value)} /></label>
          <label className="stack" style={{ flex: 2 }}>Description<input value={desc} maxLength={1000} onChange={(e) => setDesc(e.target.value)} /></label>
        </div>
        <h4>Form fields</h4>
        <FieldBuilder fields={fields} setFields={setFields} />
        <div className="row">
          <button className="sec" onClick={() => setFields([...fields, newField()])}>+ Add field</button>
          <button disabled={busy} onClick={createApp}>Create application</button>
        </div>
      </div>
    </div>
  );
};

export default AdminStudio;
