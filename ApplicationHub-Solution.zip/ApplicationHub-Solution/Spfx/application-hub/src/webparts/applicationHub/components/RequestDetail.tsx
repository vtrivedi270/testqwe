import * as React from 'react';
import { HubApi, Detail, UserRow, FieldErrorRow, ApiError } from '../services/hubApi';
import { FormRenderer } from './FormRenderer';

export interface RequestDetailProps { api: HubApi; id: number; onBack: () => void; }

export const RequestDetail: React.FC<RequestDetailProps> = ({ api, id, onBack }) => {
  const [d, setD] = React.useState<Detail | null>(null);
  const [dir, setDir] = React.useState<UserRow[]>([]);
  const [note, setNote] = React.useState('');
  const [stageId, setStageId] = React.useState('');
  const [toUser, setToUser] = React.useState('');
  const [editValues, setEditValues] = React.useState<Record<string, any>>({});
  const [errors, setErrors] = React.useState<FieldErrorRow[]>([]);
  const [msg, setMsg] = React.useState('');

  const load = React.useCallback(async (): Promise<void> => {
    try {
      const x = await api.detail(id);
      setD(x);
      setEditValues(x.values || {});
    } catch (e) { setMsg((e as Error).message); }
  }, [api, id]);

  React.useEffect(() => {
    load();
    api.users().then(setDir).catch(() => undefined);
  }, [load, api]);

  const act = async (action: string, body: unknown, done: string): Promise<void> => {
    setMsg(''); setErrors([]);
    try {
      await api.action(id, action, body);
      setMsg(done); setNote('');
      await load();
    } catch (e) {
      const err = e as ApiError;
      setErrors(err.fieldErrors || []);
      setMsg(err.message);
    }
  };

  const withReason = (action: string, done: string): void => {
    if (!note.trim()) { setMsg('Please write a reason first.'); return; }
    act(action, { comment: note.trim() }, done);
  };

  if (!d) return <div><button className="sec" onClick={onBack}>← Back</button><div className="card">{msg || 'Loading…'}</div></div>;

  return (
    <div>
      <button className="sec" onClick={onBack}>← Back</button>
      <div className="card">
        <h2>{d.application} · #{d.id}</h2>
        <p className="log">Requested by {d.requester} · <b>{d.status}</b> · cycle {d.cycle}</p>
        {d.amendNote && <div className="notice">Amendment requested: {d.amendNote}</div>}
        {d.canEdit ? (
          <>
            <FormRenderer api={api} form={d.form} values={editValues} editable errors={errors} onChange={setEditValues} />
            <button onClick={() => act('resubmit', { payloadJson: JSON.stringify(editValues), attachmentIds: d.form.fields.filter((f) => f.type === 'attach').flatMap((f) => (editValues[f.id] || []).map((x: any) => x.id)) }, 'Resubmitted.')}>Resubmit</button>
          </>
        ) : (
          <FormRenderer api={api} form={d.form} values={d.values} editable={false} />
        )}
      </div>

      <div className="card">
        <h3>Approval flow</h3>
        <ol className="flow">
          {d.steps.map((s) => (
            <li key={s.index}>
              {s.stages.map((st) => (
                <span key={st.id} className="chip">
                  {st.name}{st.kind === 'Group' ? ` (${st.rule === 'All' ? 'all' : 'any'} of ${st.members.filter(Boolean).length})` : ''}
                </span>
              ))}
            </li>
          ))}
        </ol>
        <h4>Activity</h4>
        {d.approvals.length === 0 && <div className="log">No actions yet.</div>}
        {d.approvals.map((a, i) => (
          <div key={i} className="log">
            {String(a.ActedAt).slice(0, 16)} · {a.Actor}{a.ActedFor ? ` for ${a.ActedFor}` : ''} · {a.Action}{a.Comment ? ` — ${a.Comment}` : ''}
          </div>
        ))}
      </div>

      {d.actions.length > 0 && (
        <div className="card">
          <h3>Your action</h3>
          <textarea rows={2} maxLength={1000} placeholder="Comment (required to reject or ask to amend)" value={note} onChange={(e) => setNote(e.target.value)} />
          <div className="row">
            <button className="ok" onClick={() => act('approve', { comment: note.trim() || null }, 'Approved.')}>Approve</button>
            <button className="amb" onClick={() => withReason('amend', 'Sent back for amendment.')}>Ask to amend</button>
            <button className="bad" onClick={() => withReason('reject', 'Rejected.')}>Reject</button>
          </div>
          <h4>Delegate this step</h4>
          <div className="row">
            <select value={stageId} onChange={(e) => setStageId(e.target.value)}>
              <option value="">Choose step</option>
              {d.actions.map((a) => <option key={a.stageId} value={a.stageId}>{a.stage}</option>)}
            </select>
            <select value={toUser} onChange={(e) => setToUser(e.target.value)}>
              <option value="">Delegate to</option>
              {dir.map((u) => <option key={u.Id} value={u.Id}>{u.Name} · {u.Role}</option>)}
            </select>
            <button className="sec" disabled={!stageId || !toUser} onClick={() => act('delegate', { stageId: Number(stageId), toUserId: Number(toUser) }, 'Step delegated.')}>Delegate</button>
          </div>
        </div>
      )}

      <div className="card row">
        {d.canPullBack && <button className="sec" onClick={() => act('pullback', undefined, 'Pulled back to draft.')}>Pull back</button>}
        {(d.status === 'In progress' || d.status === 'Amend requested' || d.status === 'Draft') && (
          <button className="bad" onClick={() => window.confirm('Cancel this request? This cannot be undone.') && act('cancel', undefined, 'Request cancelled.')}>Cancel request</button>
        )}
      </div>
      {msg && <div className="notice">{msg}</div>}
    </div>
  );
};
