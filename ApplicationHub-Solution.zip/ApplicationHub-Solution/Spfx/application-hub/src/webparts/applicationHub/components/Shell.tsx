import * as React from 'react';
import AdminStudio from './AdminStudio';
import MastersPanel from './MastersPanel';
import UsersPanel from './UsersPanel';
import { NewRequest } from './NewRequest';
import { RequestList, ListColumn } from './RequestList';
import { RequestDetail } from './RequestDetail';
import { Delegation } from './Delegation';
import { HubApi, Me } from '../services/hubApi';

export interface ShellProps { api: HubApi; }

const field = (k: string) => (r: any): string => String(r[k] ?? r[k.charAt(0).toLowerCase() + k.slice(1)] ?? '');
const day = (k: string) => (r: any): string => String(field(k)(r)).slice(0, 16);

const MINE: ListColumn[] = [
  { label: '#', get: field('Id') }, { label: 'Application', get: field('Application') },
  { label: 'Status', get: field('Status') }, { label: 'Created', get: day('CreatedAt') }
];
const INBOX: ListColumn[] = [
  { label: '#', get: field('id') }, { label: 'Application', get: field('application') },
  { label: 'Requested by', get: field('requester') }, { label: 'Waiting at', get: (r) => (r.stages || []).join(', ') }
];
const APPROVED: ListColumn[] = [
  { label: '#', get: field('Id') }, { label: 'Application', get: field('Application') },
  { label: 'Status', get: field('Status') }, { label: 'Last action', get: day('LastActedAt') }
];

const Shell: React.FC<ShellProps> = ({ api }) => {
  const [me, setMe] = React.useState<Me | null>(null);
  const [tab, setTab] = React.useState<string>('new');
  const [openId, setOpenId] = React.useState<number | null>(null);

  React.useEffect(() => { api.me().then(setMe).catch(() => undefined); }, [api]);

  const tabs: [string, string][] = [
    ['new', 'New request'], ['mine', 'My requests'], ['inbox', 'My approvals'], ['approved', 'Approved by me'], ['delegation', 'Delegation']
  ];
  if (me?.role === 'Admin') tabs.push(['studio', 'Admin studio'], ['masters', 'Master data'], ['users', 'Users']);

  const go = (t: string): void => { setOpenId(null); setTab(t); };

  let body: JSX.Element;
  if (openId !== null) body = <RequestDetail api={api} id={openId} onBack={() => setOpenId(null)} />;
  else if (tab === 'new') body = <NewRequest api={api} onCreated={(id) => setOpenId(id)} />;
  else if (tab === 'mine') body = <RequestList key="mine" title="My requests" load={() => api.myRequests()} cols={MINE} onOpen={setOpenId} />;
  else if (tab === 'inbox') body = <RequestList key="inbox" title="My approvals" load={() => api.inbox()} cols={INBOX} onOpen={setOpenId} empty="Nothing is waiting for you." />;
  else if (tab === 'approved') body = <RequestList key="approved" title="Approved by me" load={() => api.approved()} cols={APPROVED} onOpen={setOpenId} />;
  else if (tab === 'delegation') body = <Delegation api={api} />;
  else if (tab === 'studio') body = <AdminStudio api={api} />;
  else if (tab === 'masters') body = <MastersPanel api={api} />;
  else body = <UsersPanel api={api} />;

  return (
    <div>
      <div className="tabs">
        {tabs.map(([k, l]) => (
          <button key={k} className={tab === k && openId === null ? '' : 'sec'} onClick={() => go(k)}>{l}</button>
        ))}
      </div>
      {body}
    </div>
  );
};

export default Shell;
