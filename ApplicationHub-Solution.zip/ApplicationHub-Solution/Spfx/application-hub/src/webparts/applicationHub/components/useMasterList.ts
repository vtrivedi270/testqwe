import * as React from 'react';
import { HubApi } from '../services/hubApi';

/** Reads a field whether the API sent it capitalised (column name) or camelCase. */
export const cellOf = (r: any, k: string): any => r[k] ?? r[k.charAt(0).toLowerCase() + k.slice(1)];
export const rowId = (r: any): any => cellOf(r, 'Id');
export const rowName = (rows: any[], id: any): string => {
  const r = rows.find((x) => String(rowId(x)) === String(id));
  return r ? String(cellOf(r, 'Name')) : '—';
};

// Each master list is loaded once per page and shared by every control that uses it.
const cache: Record<string, Promise<any[]>> = {};

export function loadMasterList(api: HubApi, key: string): Promise<any[]> {
  if (!cache[key]) {
    cache[key] = api.listMaster(key).catch(() => { delete cache[key]; return []; });
  }
  return cache[key];
}

export function useMasterList(api: HubApi, key: string): any[] {
  const [rows, setRows] = React.useState<any[]>([]);
  React.useEffect(() => {
    let alive = true;
    if (key) loadMasterList(api, key).then((r) => { if (alive) setRows(r); });
    return () => { alive = false; };
  }, [api, key]);
  return rows;
}
