import * as React from 'react';
import { HubApi, FormDef, FormField, FieldErrorRow } from '../services/hubApi';
import { cellOf, rowId, rowName, useMasterList } from './useMasterList';
import { fkCol } from '../services/masterDefs';

export interface FormRendererProps {
  api: HubApi;
  form: FormDef;
  values: Record<string, any>;
  editable: boolean;
  errors?: FieldErrorRow[];
  onChange?: (next: Record<string, any>) => void;
}

/** Renders a form definition with its values. Changing a parent clears the controls that depend on it. */
export const FormRenderer: React.FC<FormRendererProps> = ({ api, form, values, editable, errors = [], onChange }) => {
  const fields = form.fields || [];
  const set = (id: string, val: any): void => {
    const next: Record<string, any> = { ...values, [id]: val };
    const clear = (pid: string): void => {
      fields.filter((x) => x.pf === pid).forEach((x) => { delete next[x.id]; clear(x.id); });
    };
    clear(id);
    if (onChange) onChange(next);
  };

  return (
    <div>
      {fields.map((f) => {
        const err = errors.find((e) => e.field === f.label);
        return (
          <div className="pf" key={f.id}>
            <label>{f.label}{f.required ? <span className="req"> *</span> : null}</label>
            <Control api={api} f={f} fields={fields} values={values} value={values[f.id]} editable={editable} set={(v: any) => set(f.id, v)} />
            {err && <div className="err">{err.message}</div>}
          </div>
        );
      })}
    </div>
  );
};

interface ControlProps {
  api: HubApi; f: FormField; fields: FormField[]; values: Record<string, any>;
  value: any; editable: boolean; set: (v: any) => void;
}

const Control: React.FC<ControlProps> = ({ api, f, fields, values, value, editable, set }) => {
  const dis = !editable;
  switch (f.type) {
    case 'text':
    case 'number':
    case 'date':
      return <input type={f.type} disabled={dis} value={value ?? ''} onChange={(e) => set(e.target.value)} />;
    case 'textarea':
      return <textarea rows={3} disabled={dis} value={value ?? ''} onChange={(e) => set(e.target.value)} />;
    case 'checkbox':
      return <input type="checkbox" disabled={dis} checked={!!value} onChange={(e) => set(e.target.checked)} />;
    case 'dropdown':
      return (
        <select disabled={dis} value={value ?? ''} onChange={(e) => set(e.target.value)}>
          <option value="">Select</option>
          {(f.options || '').split(',').map((o) => o.trim()).filter(Boolean).map((o) => <option key={o}>{o}</option>)}
        </select>
      );
    case 'lookup':
      return <MasterPick api={api} src={f.src || ''} value={value} disabled={dis} onChange={set} />;
    case 'dependent':
      return <Dependent api={api} f={f} fields={fields} values={values} value={value} disabled={dis} onChange={set} />;
    case 'childlist':
      return <ChildList api={api} f={f} fields={fields} values={values} value={value || []} editable={editable} onChange={set} />;
    case 'table':
      return <Grid api={api} f={f} value={value || []} editable={editable} onChange={set} />;
    case 'lineitems':
      return <LineItems api={api} value={value || []} editable={editable} onChange={set} />;
    case 'attach':
      return <Attach api={api} f={f} value={value || []} editable={editable} onChange={set} />;
    default:
      return <div className="readonly">—</div>;
  }
};

const MasterPick: React.FC<{ api: HubApi; src: string; value: any; disabled: boolean; onChange: (v: any) => void }> = ({ api, src, value, disabled, onChange }) => {
  const rows = useMasterList(api, src);
  if (disabled) return <div className="readonly">{rowName(rows, value)}</div>;
  return (
    <select value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
      <option value="">Select</option>
      {rows.map((r) => <option key={rowId(r)} value={rowId(r)}>{cellOf(r, 'Name')}</option>)}
    </select>
  );
};

const Dependent: React.FC<{ api: HubApi; f: FormField; fields: FormField[]; values: Record<string, any>; value: any; disabled: boolean; onChange: (v: any) => void }> =
  ({ api, f, fields, values, value, disabled, onChange }) => {
    const rows = useMasterList(api, f.src || '');
    const parent = fields.find((p) => p.id === f.pf);
    if (!parent) return <div className="readonly">Parent control is not configured.</div>;
    const pv = values[parent.id];
    if (!pv) return <div className="readonly">Choose {parent.label} first.</div>;
    const key = fkCol(f.src, parent.src) || '';
    const list = rows.filter((r) => String(cellOf(r, key)) === String(pv));
    if (disabled) return <div className="readonly">{rowName(list, value)}</div>;
    return (
      <select value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
        <option value="">Select</option>
        {list.map((r) => <option key={rowId(r)} value={rowId(r)}>{cellOf(r, 'Name')}</option>)}
      </select>
    );
  };

const ChildList: React.FC<{ api: HubApi; f: FormField; fields: FormField[]; values: Record<string, any>; value: any[]; editable: boolean; onChange: (v: any[]) => void }> =
  ({ api, f, fields, values, value, editable, onChange }) => {
    const rows = useMasterList(api, f.src || '');
    const parent = fields.find((p) => p.id === f.pf);
    if (!parent) return <div className="readonly">Parent control is not configured.</div>;
    const pv = values[parent.id];
    if (!pv) return <div className="readonly">Choose {parent.label} to load records.</div>;
    const key = fkCol(f.src, parent.src) || '';
    const list = rows.filter((r) => String(cellOf(r, key)) === String(pv));
    if (list.length === 0) return <div className="readonly">No records for this selection.</div>;
    return (
      <div>
        {list.map((r) => {
          const id = rowId(r);
          const on = value.map(String).includes(String(id));
          return (
            <label key={id} className="check">
              <input type="checkbox" disabled={!editable} checked={on}
                onChange={(e) => onChange(e.target.checked ? [...value, id] : value.filter((x) => String(x) !== String(id)))} />
              {cellOf(r, 'Name')}
            </label>
          );
        })}
      </div>
    );
  };

const Grid: React.FC<{ api: HubApi; f: FormField; value: any[]; editable: boolean; onChange: (v: any[]) => void }> = ({ api, f, value, editable, onChange }) => {
  const cols = f.columns || [];
  const setCell = (i: number, cid: string, v: any): void => onChange(value.map((r, j) => (j === i ? { ...r, [cid]: v } : r)));
  return (
    <div>
      <div className="table-wrap">
        <table>
          <thead><tr>{cols.map((c) => <th key={c.id}>{c.label}</th>)}{editable && <th />}</tr></thead>
          <tbody>
            {value.length === 0 && <tr><td colSpan={cols.length + (editable ? 1 : 0)} className="empty">No rows</td></tr>}
            {value.map((r, i) => (
              <tr key={i}>
                {cols.map((c) => (
                  <td key={c.id}>
                    {c.type === 'lookup' ? (
                      <MasterPick api={api} src={c.src || ''} value={r[c.id]} disabled={!editable} onChange={(v) => setCell(i, c.id, v)} />
                    ) : editable ? (
                      <input type={c.type === 'number' ? 'number' : c.type === 'date' ? 'date' : 'text'} value={r[c.id] ?? ''} onChange={(e) => setCell(i, c.id, e.target.value)} />
                    ) : <span>{r[c.id] ?? ''}</span>}
                  </td>
                ))}
                {editable && <td><button className="bad" onClick={() => onChange(value.filter((_, j) => j !== i))}>✕</button></td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {editable && <button className="sec" onClick={() => onChange([...value, {}])}>+ Add row</button>}
    </div>
  );
};

const LineItems: React.FC<{ api: HubApi; value: any[]; editable: boolean; onChange: (v: any[]) => void }> = ({ api, value, editable, onChange }) => {
  const items = useMasterList(api, 'items');
  const set = (i: number, patch: Record<string, any>): void => onChange(value.map((r, j) => (j === i ? { ...r, ...patch } : r)));
  const amount = (r: any): number => (Number(r.qty) || 0) * (Number(r.price) || 0);
  const total = value.reduce((a, r) => a + amount(r), 0);
  return (
    <div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Item</th><th>Qty</th><th>Unit price</th><th>Amount</th>{editable && <th />}</tr></thead>
          <tbody>
            {value.length === 0 && <tr><td colSpan={editable ? 5 : 4} className="empty">No items</td></tr>}
            {value.map((r, i) => (
              <tr key={i}>
                <td>
                  {editable ? (
                    <select value={r.item ?? ''} onChange={(e) => {
                      const it = items.find((x) => String(rowId(x)) === e.target.value);
                      set(i, { item: e.target.value, price: it ? cellOf(it, 'Price') : '' });
                    }}>
                      <option value="">Select</option>
                      {items.map((x) => <option key={rowId(x)} value={rowId(x)}>{cellOf(x, 'Name')}</option>)}
                    </select>
                  ) : rowName(items, r.item)}
                </td>
                <td>{editable ? <input type="number" min={1} value={r.qty ?? ''} onChange={(e) => set(i, { qty: e.target.value })} /> : r.qty}</td>
                <td>{editable ? <input type="number" min={0} step="0.01" value={r.price ?? ''} onChange={(e) => set(i, { price: e.target.value })} /> : r.price}</td>
                <td>{amount(r).toFixed(2)}</td>
                {editable && <td><button className="bad" onClick={() => onChange(value.filter((_, j) => j !== i))}>✕</button></td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        {editable ? <button className="sec" onClick={() => onChange([...value, { qty: 1 }])}>+ Add item</button> : <span />}
        <b>Total: {total.toFixed(2)}</b>
      </div>
    </div>
  );
};

const Attach: React.FC<{ api: HubApi; f: FormField; value: any[]; editable: boolean; onChange: (v: any[]) => void }> = ({ api, f, value, editable, onChange }) => {
  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState('');
  const maxFiles = f.maxFiles || 5;
  const maxMB = f.maxMB || 10;

  const pick = async (e: React.ChangeEvent<HTMLInputElement>): Promise<void> => {
    setErr('');
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    if (value.length + files.length > maxFiles) { setErr(`Up to ${maxFiles} files for this field.`); return; }
    if (files.some((x) => x.size > maxMB * 1024 * 1024)) { setErr(`Each file must be ${maxMB} MB or smaller.`); return; }
    setBusy(true);
    try {
      const added: any[] = [];
      for (const file of files) added.push(await api.uploadAttachment(file));
      onChange([...value, ...added]);
    } catch (x) {
      setErr((x as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      {value.map((a, i) => (
        <div className="log" key={a.id}>
          📎 <button className="link" onClick={() => api.downloadAttachment(a.id, a.name).catch((x) => setErr((x as Error).message))}>{a.name}</button>{' '}
          {editable && <button className="bad" onClick={() => onChange(value.filter((_, j) => j !== i))}>Remove</button>}
        </div>
      ))}
      {editable && <input type="file" multiple accept=".pdf,.png,.jpg,.jpeg,.xlsx,.docx" disabled={busy} onChange={pick} />}
      {busy && <div className="log">Uploading…</div>}
      {err && <div className="notice">{err}</div>}
    </div>
  );
};
