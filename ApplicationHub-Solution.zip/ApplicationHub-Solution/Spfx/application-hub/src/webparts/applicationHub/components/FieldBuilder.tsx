import * as React from 'react';
import { FormField, FormColumn } from '../services/hubApi';
import { MASTER_KEYS, MASTER_LABELS, fkCol } from '../services/masterDefs';

export const FIELD_TYPES: [string, string][] = [
  ['text', 'Text'], ['number', 'Number'], ['date', 'Date'], ['textarea', 'Long text'], ['checkbox', 'Checkbox'], ['attach', 'Attachment'],
  ['dropdown', 'Dropdown (static)'], ['lookup', 'Master lookup'], ['dependent', 'Dependent dropdown'], ['childlist', 'Parent-child list'],
  ['table', 'Table (grid)'], ['lineitems', 'Line items (stationery)']
];

const newId = (): string => 'c' + Math.random().toString(36).slice(2, 8);

/** Returns a message for the first problem, or an empty string when the form is valid. */
export function validateFields(fields: FormField[]): string {
  for (const f of fields) {
    if (!f.label || !f.label.trim()) return 'Every field needs a label.';
    if (f.type === 'dropdown' && !(f.options || '').trim()) return `${f.label}: dropdown needs options.`;
    if (['lookup', 'dependent', 'childlist'].includes(f.type) && !f.src) return `${f.label}: choose master data.`;
    if (f.type === 'dependent' || f.type === 'childlist') {
      const p = fields.find((x) => x.id === f.pf);
      if (!p) return `${f.label}: choose a parent control.`;
      if (!fkCol(f.src, p.src)) return `${f.label}: the parent must be a lookup that ${MASTER_LABELS[f.src || ''] || 'the master'} belongs to.`;
    }
    if (f.type === 'table') {
      if (!(f.columns || []).length) return `${f.label}: add at least one column.`;
      for (const c of f.columns || []) {
        if (!c.label.trim()) return `${f.label}: every column needs a label.`;
        if (c.type === 'lookup' && !c.src) return `${f.label}: column ${c.label} needs master data.`;
      }
    }
  }
  return '';
}

export interface FieldBuilderProps {
  fields: FormField[];
  setFields: (f: FormField[]) => void;
}

const FieldBuilder: React.FC<FieldBuilderProps> = ({ fields, setFields }) => {
  const patch = (i: number, p: Partial<FormField>): void => setFields(fields.map((x, j) => (j === i ? { ...x, ...p } : x)));
  const patchCol = (i: number, j: number, p: Partial<FormColumn>): void =>
    patch(i, { columns: (fields[i].columns || []).map((c, k) => (k === j ? { ...c, ...p } : c)) });
  const parentsFor = (f: FormField): FormField[] =>
    fields.filter((p) => p.id !== f.id && p.type === 'lookup' && !!p.src && !!f.src && !!fkCol(f.src, p.src));

  const changeType = (i: number, type: string): void => patch(i, {
    type, src: '', pf: '', options: type === 'dropdown' ? 'Option 1, Option 2' : '',
    columns: type === 'table' ? [{ id: newId(), label: 'Column 1', type: 'text' }] : []
  });

  const masterSelect = (value: string | undefined, onPick: (v: string) => void): JSX.Element => (
    <select value={value || ''} onChange={(e) => onPick(e.target.value)}>
      <option value="">Choose</option>
      {MASTER_KEYS.map((k) => <option key={k} value={k}>{MASTER_LABELS[k]}</option>)}
    </select>
  );

  return (
    <div>
      {fields.map((f, i) => (
        <div className="field" key={f.id}>
          <div className="row">
            <label className="stack" style={{ flex: 1 }}>Label<input value={f.label} onChange={(e) => patch(i, { label: e.target.value })} /></label>
            <label className="stack">Control
              <select value={f.type} onChange={(e) => changeType(i, e.target.value)}>
                {FIELD_TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
            </label>
            <label className="check"><input type="checkbox" checked={!!f.required} onChange={(e) => patch(i, { required: e.target.checked })} /> Required</label>
          </div>

          {f.type === 'dropdown' && (
            <div className="row"><label className="stack" style={{ flex: 1 }}>Options (comma separated)
              <input value={f.options || ''} onChange={(e) => patch(i, { options: e.target.value })} /></label></div>
          )}

          {f.type === 'lookup' && <div className="row"><label className="stack">Master data {masterSelect(f.src, (v) => patch(i, { src: v }))}</label></div>}

          {(f.type === 'dependent' || f.type === 'childlist') && (
            <div className="row">
              <label className="stack">Master data {masterSelect(f.src, (v) => patch(i, { src: v, pf: '' }))}</label>
              {f.src && (
                <label className="stack">Depends on
                  <select value={f.pf || ''} onChange={(e) => patch(i, { pf: e.target.value })}>
                    <option value="">Choose parent</option>
                    {parentsFor(f).map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
                  </select>
                </label>
              )}
              {f.src && parentsFor(f).length === 0 && <div className="log">Add a lookup above this field for the parent master first.</div>}
            </div>
          )}

          {f.type === 'table' && (
            <div>
              <div className="log">Columns</div>
              {(f.columns || []).map((c, j) => (
                <div className="row" key={c.id}>
                  <label className="stack" style={{ flex: 1 }}>Column<input value={c.label} onChange={(e) => patchCol(i, j, { label: e.target.value })} /></label>
                  <label className="stack">Type
                    <select value={c.type} onChange={(e) => patchCol(i, j, { type: e.target.value as FormColumn['type'], src: e.target.value === 'lookup' ? (c.src || 'items') : undefined })}>
                      {['text', 'number', 'date', 'lookup'].map((t) => <option key={t}>{t}</option>)}
                    </select>
                  </label>
                  {c.type === 'lookup' && <label className="stack">Master data {masterSelect(c.src, (v) => patchCol(i, j, { src: v }))}</label>}
                  <button className="bad" onClick={() => patch(i, { columns: (f.columns || []).filter((_, k) => k !== j) })}>✕</button>
                </div>
              ))}
              <button className="sec" onClick={() => patch(i, { columns: [...(f.columns || []), { id: newId(), label: 'Column', type: 'text' }] })}>+ Column</button>
            </div>
          )}

          {f.type === 'lineitems' && <div className="log">Columns are fixed: item (from stationery master), quantity, unit price. Amount and total are calculated.</div>}

          {f.type === 'attach' && (
            <div className="row">
              <label className="stack">Max files<input type="number" min={1} max={20} value={f.maxFiles || 5} onChange={(e) => patch(i, { maxFiles: +e.target.value })} /></label>
              <label className="stack">Max size (MB)<input type="number" min={1} max={10} value={f.maxMB || 10} onChange={(e) => patch(i, { maxMB: +e.target.value })} /></label>
              <div className="log">PDF, PNG, JPG, XLSX or DOCX.</div>
            </div>
          )}

          <button className="bad" onClick={() => setFields(fields.filter((_, j) => j !== i))}>Remove field</button>
        </div>
      ))}
    </div>
  );
};

export default FieldBuilder;
