import * as React from 'react';
import { HubApi, UserRow } from '../services/hubApi';

export const Delegation: React.FC<{ api: HubApi }> = ({ api }) => {
  const [rows, setRows] = React.useState<any[]>([]);
  const [dir, setDir] = React.useState<UserRow[]>([]);
  const [to, setTo] = React.useState('');
  const [start, setStart] = React.useState(new Date().toISOString().slice(0, 10));
  const [end, setEnd] = React.useState('');
  const [msg, setMsg] = React.useState('');

  const load = React.useCallback(async (): Promise<void> => {
    try { setRows(await api.myDelegations()); }
    catch (e) { setMsg((e as Error).message); }
  }, [api]);

  React.useEffect(() => {
    load();
    api.users().then(setDir).catch(() => undefined);
  }, [load, api]);

  const save = async (): Promise<void> => {
    setMsg('');
    try {
      await api.addDelegation({ toUserId: Number(to), startsOn: start, endsOn: end || null });
      setMsg('Delegation saved.'); setTo(''); setEnd('');
      await load();
    } catch (e) { setMsg((e as Error).message); }
  };

  const remove = async (id: number): Promise<void> => {
    if (!window.confirm('Remove this delegation?')) return;
    try { await api.removeDelegation(id); await load(); }
    catch (e) { setMsg((e as Error).message); }
  };

  return (
    <div>
      <h2>Delegation</h2>
      <p className="log">While you are away, the person you choose can act on all of your approvals for the dates you set.</p>
      <div className="card row">
        <label className="stack">Delegate to
          <select value={to} onChange={(e) => setTo(e.target.value)}>
            <option value="">Choose a person</option>
            {dir.map((u) => <option key={u.Id} value={u.Id}>{u.Name} · {u.Role}</option>)}
          </select>
        </label>
        <label className="stack">From<input type="date" value={start} onChange={(e) => setStart(e.target.value)} /></label>
        <label className="stack">Until (optional)<input type="date" value={end} onChange={(e) => setEnd(e.target.value)} /></label>
        <button disabled={!to || !start} onClick={save}>Save delegation</button>
      </div>
      {msg && <div className="notice">{msg}</div>}
      <div className="card table-wrap">
        <table>
          <thead><tr><th>Delegate</th><th>From</th><th>Until</th><th /></tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={4} className="empty">No delegations yet.</td></tr>}
            {rows.map((r) => (
              <tr key={r.Id}>
                <td>{r.ToName}</td>
                <td>{String(r.StartsOn).slice(0, 10)}</td>
                <td>{r.EndsOn ? String(r.EndsOn).slice(0, 10) : 'Open-ended'}</td>
                <td><button className="bad" onClick={() => remove(r.Id)}>Remove</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
