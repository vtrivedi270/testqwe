import * as React from 'react';
import { HubApi, UserAdmin } from '../services/hubApi';

const ROLES = ['Requestor', 'Reporting Manager', 'Department Head', 'Division Head', 'HR', 'Admin'];

export interface UsersPanelProps { api: HubApi; }

const UsersPanel: React.FC<UsersPanelProps> = ({ api }) => {
  const [rows, setRows] = React.useState<UserAdmin[]>([]);
  const [msg, setMsg] = React.useState('');
  const [form, setForm] = React.useState({ email: '', displayName: '', role: 'Requestor', password: '' });
  const [pw, setPw] = React.useState<Record<number, string>>({});

  const load = React.useCallback(async () => {
    try { setRows(await api.listUsers()); }
    catch (e) { setMsg((e as Error).message); }
  }, [api]);

  React.useEffect(() => { load(); }, [load]);

  const run = async (fn: () => Promise<void>, ok: string): Promise<void> => {
    setMsg('');
    try { await fn(); setMsg(ok); await load(); }
    catch (e) { setMsg((e as Error).message); }
  };

  return (
    <div>
      <h2>Users and roles</h2>
      {msg && <div className="notice">{msg}</div>}

      <div className="card">
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Active</th><th>Reset password</th></tr></thead>
          <tbody>
            {rows.map((u) => (
              <tr key={u.Id}>
                <td>{u.DisplayName}</td>
                <td>{u.Email}</td>
                <td>
                  <select value={u.Role} onChange={(e) => run(() => api.updateUser(u.Id, { role: e.target.value }), 'Role updated. The user is signed out.')}>
                    {ROLES.map((r) => <option key={r}>{r}</option>)}
                  </select>
                </td>
                <td>
                  <input type="checkbox" checked={!!u.IsActive}
                    onChange={(e) => run(() => api.updateUser(u.Id, { isActive: e.target.checked }), 'User updated.')} />
                </td>
                <td>
                  <input type="password" placeholder="New password (12+)" value={pw[u.Id] || ''}
                    onChange={(e) => setPw({ ...pw, [u.Id]: e.target.value })} />
                  <button className="sec" disabled={(pw[u.Id] || '').length < 12}
                    onClick={() => run(async () => { await api.resetPassword(u.Id, pw[u.Id]); setPw({ ...pw, [u.Id]: '' }); }, 'Password reset. The user is signed out everywhere.')}>
                    Reset
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h3>Add user</h3>
        <div className="row">
          <label className="stack" style={{ flex: 1 }}>Name<input value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} /></label>
          <label className="stack" style={{ flex: 1 }}>Email<input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></label>
          <label className="stack">Role
            <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
              {ROLES.map((r) => <option key={r}>{r}</option>)}
            </select>
          </label>
          <label className="stack" style={{ flex: 1 }}>Temporary password (12+)<input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></label>
        </div>
        <button onClick={() => run(async () => {
          await api.createUser(form);
          setForm({ email: '', displayName: '', role: 'Requestor', password: '' });
        }, 'User created.')}>Create user</button>
      </div>
    </div>
  );
};

export default UsersPanel;
