import * as React from 'react';
import { HubApi, FormDef, FieldErrorRow, ApiError } from '../services/hubApi';
import { FormRenderer } from './FormRenderer';

export interface NewRequestProps { api: HubApi; onCreated: (id: number) => void; }

export const NewRequest: React.FC<NewRequestProps> = ({ api, onCreated }) => {
  const [apps, setApps] = React.useState<any[]>([]);
  const [appId, setAppId] = React.useState<number | null>(null);
  const [form, setForm] = React.useState<FormDef | null>(null);
  const [values, setValues] = React.useState<Record<string, any>>({});
  const [errors, setErrors] = React.useState<FieldErrorRow[]>([]);
  const [msg, setMsg] = React.useState('');
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    api.publishedApps().then(setApps).catch((e) => setMsg((e as Error).message));
  }, [api]);

  const choose = async (id: number): Promise<void> => {
    setAppId(id); setValues({}); setErrors([]); setMsg('');
    try { setForm((await api.appForm(id)).form); }
    catch (e) { setMsg((e as Error).message); }
  };

  const save = async (submit: boolean): Promise<void> => {
    if (appId === null || form === null) return;
    setBusy(true); setErrors([]); setMsg('');
    try {
      const attachmentIds = form.fields.filter((f) => f.type === 'attach').flatMap((f) => (values[f.id] || []).map((x: any) => x.id));
      const r = await api.createRequest({ applicationId: appId, payloadJson: JSON.stringify(values), submit, attachmentIds });
      onCreated(r.id);
    } catch (e) {
      const err = e as ApiError;
      setErrors(err.fieldErrors || []);
      setMsg(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <h2>New request</h2>
      <div className="card">
        <label className="stack">Application
          <select value={appId ?? ''} onChange={(e) => choose(Number(e.target.value))}>
            <option value="">Choose an application</option>
            {apps.map((a) => <option key={a.Id ?? a.id} value={a.Id ?? a.id}>{a.Name ?? a.name}</option>)}
          </select>
        </label>
      </div>
      {form && (
        <div className="card">
          <FormRenderer api={api} form={form} values={values} editable errors={errors} onChange={setValues} />
          <div className="row">
            <button className="sec" disabled={busy} onClick={() => save(false)}>Save draft</button>
            <button disabled={busy} onClick={() => save(true)}>Submit for approval</button>
          </div>
        </div>
      )}
      {msg && <div className="notice">{msg}</div>}
    </div>
  );
};
