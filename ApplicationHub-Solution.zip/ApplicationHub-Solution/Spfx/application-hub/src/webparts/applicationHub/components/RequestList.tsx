import * as React from 'react';

export interface ListColumn { label: string; get: (r: any) => string; }

export interface RequestListProps {
  title: string;
  load: () => Promise<any[]>;
  cols: ListColumn[];
  onOpen: (id: number) => void;
  empty?: string;
}

const pick = (r: any, k: string): any => r[k] ?? r[k.charAt(0).toLowerCase() + k.slice(1)];

export const RequestList: React.FC<RequestListProps> = ({ title, load, cols, onOpen, empty }) => {
  const [rows, setRows] = React.useState<any[] | null>(null);
  const [err, setErr] = React.useState('');

  React.useEffect(() => {
    load().then(setRows).catch((e) => setErr((e as Error).message));
    // load is provided once per tab, so it is read on mount only
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div>
      <h2>{title}</h2>
      {err && <div className="notice">{err}</div>}
      {!rows && !err && <div className="card">Loading…</div>}
      {rows && rows.length === 0 && <div className="card">{empty || 'Nothing here yet.'}</div>}
      {rows && rows.length > 0 && (
        <div className="card table-wrap">
          <table>
            <thead><tr>{cols.map((c) => <th key={c.label}>{c.label}</th>)}</tr></thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} className="clickable" onClick={() => onOpen(Number(pick(r, 'Id')))}>
                  {cols.map((c) => <td key={c.label}>{c.get(r)}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
