import * as React from 'react';
import { HubApi, MasterRow } from '../services/hubApi';

type Col = { k: string; label: string; fk?: string; num?: boolean };
const MASTERS: Record<string, { label: string; cols: Col[] }> = {
  countries: { label: 'Countries', cols: [{ k: 'Name', label: 'Name' }] },
  states: { label: 'States', cols: [{ k: 'Name', label: 'Name' }, { k: 'CountryId', label: 'Country', fk: 'countries' }] },
  cities: { label: 'Cities', cols: [{ k: 'Name', label: 'Name' }, { k: 'StateId', label: 'State', fk: 'states' }] },
  divisions: { label: 'Divisions', cols: [{ k: 'Name', label: 'Name' }] },
  departments: { label: 'Departments', cols: [{ k: 'Name', label: 'Name' }, { k: 'DivisionId', label: 'Division', fk: 'divisions' }] },
  employees: { label: 'Employees', cols: [{ k: 'Name', label: 'Name' }, { k: 'Email', label: 'Email' }, { k: 'DepartmentId', label: 'Department', fk: 'departments' }] },
  assets: { label: 'Assets', cols: [{ k: 'Name', label: 'Name' }, { k: 'EmployeeId', label: 'Employee', fk: 'employees' }] },
  vendors: { label: 'Vendors', cols: [{ k: 'Name', label: 'Name' }, { k: 'Contact', label: 'Contact' }] },
  items: { label: 'Stationery items', cols: [{ k: 'Name', label: 'Name' }, { k: 'Price', label: 'Price', num: true }, { k: 'Stock', label: 'Stock', num: true }] }
};

const cell = (r: MasterRow, k: string): any => r[k] ?? r[k.charAt(0).toLowerCase() + k.slice(1)];

export interface MastersPanelProps { api: HubApi; }

const MastersPanel: React.FC<MastersPanelProps> = ({ api }) => {
  const [key, setKey] = React.useState('countries');
  const [rows, setRows] = React.useState<MasterRow[]>([]);
  const [lookups, setLookups] = React.useState<Record<string, MasterRow[]>>({});
  const [showInactive, setShowInactive] = React.useState(false);
  const [form, setForm] = React.useState<Record<string, string>>({});
  const [editId, setEditId] = React.useState<number | null>(null);
  const [msg, setMsg] = React.useState('');
  const def = MASTERS[key];

  const load = React.useCallback(async () => {
    try { setRows(await api.listMaster(key, showInactive)); }
    catch (e) { setMsg((e as Error).message); }
  }, [api, key, showInactive]);

  React.useEffect(() => { setForm({}); setEditId(null); setMsg(''); load(); }, [load]);

  React.useEffect(() => {
    def.cols.filter((c) => c.fk && !lookups[c.fk]).forEach((c) => {
      api.listMaster(c.fk as string).then((d) => setLookups((l) => ({ ...l, [c.fk as string]: d }))).catch(() => undefined);
    });
  }, [key]);

  const fkName = (c: Col, r: MasterRow): string => {
    const p = (lookups[c.fk as string] || []).find((x) => String(cell(x, 'Id')) === String(cell(r, c.k)));
    return p ? cell(p, 'Name') : '—';
  };

  const payload = (): Record<string, unknown> => {
    const b: Record<string, unknown> = {};
    def.cols.forEach((c) => {
      const v = form[c.k];
      if (v === undefined || v === '') return;
      b[c.k] = c.num || c.fk ? Number(v) : v;
    });
    return b;
  };

  const save = async () => {
    setMsg('');
    try {
      if (editId) await api.updateMaster(key, editId, payload());
      else await api.createMaster(key, payload());
      setMsg(editId ? 'Record updated.' : 'Record added.');
      setForm({}); setEditId(null);
      await load();
    } catch (e) { setMsg((e as Error).message); }
  };

  const startEdit = (r: MasterRow) => {
    const f: Record<string, string> = {};
    def.cols.forEach((c) => { f[c.k] = String(cell(r, c.k) ?? ''); });
    setForm(f); setEditId(cell(r, 'Id'));
  };

  const deactivate = async (id: number) => {
    if (!window.confirm('Deactivate this record? Existing requests keep their link to it.')) return;
    try { await api.deactivateMaster(key, id); await load(); }
    catch (e) { setMsg((e as Error).message); }
  };

  return (
    <div>
      <h2>Master data</h2>
      <div className="tabs">
        {Object.keys(MASTERS).map((k) => (
          <button key={k} className={k === key ? '' : 'sec'} onClick={() => setKey(k)}>{MASTERS[k].label}</button>
        ))}
      </div>
      {msg && <div className="notice">{msg}</div>}

      <div className="card">
        <label className="check"><input type="checkbox" checked={showInactive} onChange={(e) => setShowInactive(e.target.checked)} /> Show inactive records</label>
        <table>
          <thead><tr><th>#</th>{def.cols.map((c) => <th key={c.k}>{c.label}</th>)}<th /></tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={def.cols.length + 2} className="empty">No records.</td></tr>}
            {rows.map((r) => (
              <tr key={cell(r, 'Id')} className={cell(r, 'IsActive') === false ? 'muted' : ''}>
                <td>{cell(r, 'Id')}</td>
                {def.cols.map((c) => <td key={c.k}>{c.fk ? fkName(c, r) : String(cell(r, c.k) ?? '')}</td>)}
                <td>
                  <button className="sec" onClick={() => startEdit(r)}>Edit</button>
                  {cell(r, 'IsActive') !== false && <button className="bad" onClick={() => deactivate(cell(r, 'Id'))}>Deactivate</button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h3>{editId ? `Edit record #${editId}` : `Add ${def.label.toLowerCase()}`}</h3>
        <div className="row">
          {def.cols.map((c) => (
            <label className="stack" key={c.k} style={{ flex: 1, minWidth: 180 }}>{c.label}
              {c.fk ? (
                <select value={form[c.k] || ''} onChange={(e) => setForm({ ...form, [c.k]: e.target.value })}>
                  <option value="">Choose</option>
                  {(lookups[c.fk] || []).map((p) => <option key={cell(p, 'Id')} value={cell(p, 'Id')}>{cell(p, 'Name')}</option>)}
                </select>
              ) : (
                <input type={c.num ? 'number' : 'text'} min={c.num ? 0 : undefined} value={form[c.k] || ''} onChange={(e) => setForm({ ...form, [c.k]: e.target.value })} />
              )}
            </label>
          ))}
        </div>
        <div className="row">
          <button onClick={save}>{editId ? 'Update' : 'Add'}</button>
          {editId && <button className="sec" onClick={() => { setForm({}); setEditId(null); }}>Cancel</button>}
        </div>
      </div>
    </div>
  );
};

type Col = { k: string; label: string; fk?: string; num?: boolean };
export default MastersPanel;
