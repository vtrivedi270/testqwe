declare interface IApplicationHubWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ApiBaseUrlFieldLabel: string;
  DevTokenFieldLabel: string;
}

declare module 'ApplicationHubWebPartStrings' {
  const strings: IApplicationHubWebPartStrings;
  export = strings;
}
