define([], function () {
  return {
    PropertyPaneDescription: 'Application Hub connection',
    BasicGroupName: 'Connection',
    ApiBaseUrlFieldLabel: 'API base URL (https)',
    DevTokenFieldLabel: 'Development token (remove before production)'
  };
});
