// Mirrors the API master registry: labels and which column points at which parent master.
export const MASTER_LABELS: Record<string, string> = {
  countries: 'Countries', states: 'States', cities: 'Cities', divisions: 'Divisions', departments: 'Departments',
  employees: 'Employees', assets: 'Assets', vendors: 'Vendors', items: 'Stationery items'
};
const FK: Record<string, Record<string, string>> = {
  states: { CountryId: 'countries' }, cities: { StateId: 'states' }, departments: { DivisionId: 'divisions' },
  employees: { DepartmentId: 'departments' }, assets: { EmployeeId: 'employees' }
};
export const MASTER_KEYS = Object.keys(MASTER_LABELS);
export function fkCol(child: string | undefined, parent: string | undefined): string | undefined {
  if (!child || !parent) return undefined;
  const m = FK[child] || {};
  return Object.keys(m).find((k) => m[k] === parent);
}
