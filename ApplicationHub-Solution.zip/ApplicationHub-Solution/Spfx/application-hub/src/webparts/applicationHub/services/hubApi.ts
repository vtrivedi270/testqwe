// Calls the Application Hub API from SharePoint. Every call sends a bearer token.
export interface Stage {
  name: string;
  mode: 'Seq' | 'Par';
  kind: 'Role' | 'Group';
  role: string | null;
  rule: 'Any' | 'All';
  actionType: 'Approve' | 'Process';
  members: number[];
}
export interface FormColumn { id: string; label: string; type: 'text' | 'number' | 'date' | 'lookup'; src?: string; }
export interface FormField {
  id: string; label: string; type: string; required: boolean; options?: string;
  src?: string; pf?: string; columns?: FormColumn[]; maxFiles?: number; maxMB?: number;
}
export interface UserAdmin { Id: number; Email: string; DisplayName: string; Role: string; IsActive: boolean; }
export interface AppRow { Id: number; Name: string; Description?: string; Status: string; StageCount: number; }
export interface UserRow { Id: number; Name: string; Role: string; }

export interface FieldErrorRow { field: string; message: string; }
export interface FormDef { fields: FormField[]; }
export interface Me { id: string; email: string; name: string; role: string; }
export interface DetailStage { id: number; name: string; kind: string; rule: string; members: string[]; }
export interface DetailStep { index: number; stages: DetailStage[]; }
export interface Detail {
  id: number; status: string; cycle: number; currentStep: number; requester: string; application: string;
  form: FormDef; values: Record<string, any>; amendNote?: string | null; steps: DetailStep[];
  actions: { stageId: number; stage: string }[];
  approvals: { StageId: number; Action: string; Comment?: string | null; ActedAt: string; Actor: string; ActedFor?: string | null }[];
  canEdit: boolean; canPullBack: boolean;
}

/** An API error that carries field-level messages from server-side validation. */
export class ApiError extends Error {
  constructor(message: string, public fieldErrors?: FieldErrorRow[]) {
    super(message);
    this.name = 'ApiError';
  }
}

export class HubApi {
  constructor(private baseUrl: string, private getToken: () => Promise<string>) {}

  private async call(path: string, init: RequestInit = {}): Promise<Response> {
    const token = await this.getToken();
    const headers: Record<string, string> = { Authorization: `Bearer ${token}` };
    if (typeof init.body === 'string') headers['Content-Type'] = 'application/json';
    return fetch(this.baseUrl.replace(/\/$/, '') + path, { ...init, headers: { ...headers, ...(init.headers as Record<string, string>) }, credentials: 'omit' });
  }

  private async fail(r: Response, fallback: string): Promise<never> {
    const d = await r.json().catch(() => ({} as { error?: string; title?: string; fieldErrors?: FieldErrorRow[] }));
    throw new ApiError(d.error || d.title || fallback, d.fieldErrors);
  }

  async listApps(): Promise<AppRow[]> {
    const r = await this.call('/api/admin/applications');
    if (!r.ok) return this.fail(r, 'Could not load applications.');
    return r.json();
  }

  async users(): Promise<UserRow[]> {
    const r = await this.call('/api/users/directory');
    if (!r.ok) return this.fail(r, 'Could not load users.');
    return r.json();
  }

  async workflow(id: number): Promise<Stage[]> {
    const r = await this.call(`/api/admin/applications/${id}/workflow`);
    if (!r.ok) return this.fail(r, 'Could not load the workflow.');
    return r.json();
  }

  async createApp(name: string, description: string | null, fields: FormField[]): Promise<number> {
    const formJson = JSON.stringify({ fields });
    const r = await this.call('/api/applications', { method: 'POST', body: JSON.stringify({ name, description, formJson }) });
    if (!r.ok) return this.fail(r, 'The application could not be created.');
    const d = await r.json();
    return d.id as number;
  }

  async saveWorkflow(id: number, stages: Stage[]): Promise<void> {
    const body = stages.map((s) => ({ ...s, role: s.kind === 'Role' ? s.role : null, members: s.kind === 'Group' ? s.members : null }));
    const r = await this.call(`/api/applications/${id}/workflow`, { method: 'PUT', body: JSON.stringify(body) });
    if (!r.ok && r.status !== 204) return this.fail(r, 'The workflow could not be saved.');
  }

  async publish(id: number): Promise<void> {
    const r = await this.call(`/api/applications/${id}/publish`, { method: 'POST' });
    if (!r.ok && r.status !== 204) return this.fail(r, 'Could not publish.');
  }

  async listMaster(key: string, includeInactive = false): Promise<MasterRow[]> {
    const r = await this.call(`/api/masters/${key}${includeInactive ? '?includeInactive=true' : ''}`);
    if (!r.ok) return this.fail(r, 'Could not load records.');
    return r.json();
  }

  async createMaster(key: string, body: Record<string, unknown>): Promise<void> {
    const r = await this.call(`/api/masters/${key}`, { method: 'POST', body: JSON.stringify(body) });
    if (!r.ok && r.status !== 201) return this.fail(r, 'The record could not be added.');
  }

  async updateMaster(key: string, id: number, body: Record<string, unknown>): Promise<void> {
    const r = await this.call(`/api/masters/${key}/${id}`, { method: 'PUT', body: JSON.stringify(body) });
    if (!r.ok && r.status !== 204) return this.fail(r, 'The record could not be saved.');
  }

  async deactivateMaster(key: string, id: number): Promise<void> {
    const r = await this.call(`/api/masters/${key}/${id}`, { method: 'DELETE' });
    if (!r.ok && r.status !== 204) return this.fail(r, 'The record could not be deactivated.');
  }

  async listUsers(): Promise<UserAdmin[]> {
    const r = await this.call('/api/admin/users');
    if (!r.ok) return this.fail(r, 'Could not load users.');
    return r.json();
  }

  async createUser(body: { email: string; displayName: string; role: string; password: string }): Promise<void> {
    const r = await this.call('/api/admin/users', { method: 'POST', body: JSON.stringify(body) });
    if (!r.ok && r.status !== 201) return this.fail(r, 'The user could not be created.');
  }

  async updateUser(id: number, body: { role?: string; isActive?: boolean; displayName?: string }): Promise<void> {
    const r = await this.call(`/api/admin/users/${id}`, { method: 'PUT', body: JSON.stringify(body) });
    if (!r.ok && r.status !== 204) return this.fail(r, 'The change could not be saved.');
  }

  async resetPassword(id: number, password: string): Promise<void> {
    const r = await this.call(`/api/admin/users/${id}/reset-password`, { method: 'POST', body: JSON.stringify({ password }) });
    if (!r.ok && r.status !== 204) return this.fail(r, 'The password could not be reset.');
  }

  async me(): Promise<Me> {
    const r = await this.call('/api/auth/me');
    if (!r.ok) return this.fail(r, 'Not signed in.');
    return r.json();
  }

  async publishedApps(): Promise<any[]> {
    const r = await this.call('/api/applications');
    if (!r.ok) return this.fail(r, 'Could not load applications.');
    return r.json();
  }

  async appForm(id: number): Promise<{ id: number; name: string; form: FormDef }> {
    const r = await this.call(`/api/applications/${id}`);
    if (!r.ok) return this.fail(r, 'This application is not available.');
    const d = await r.json();
    return { id, name: d.Name ?? d.name, form: JSON.parse(d.FormJson ?? d.formJson ?? '{"fields":[]}') as FormDef };
  }

  async createRequest(body: { applicationId: number; payloadJson: string; submit: boolean; attachmentIds?: number[] }): Promise<{ id: number }> {
    const r = await this.call('/api/requests', { method: 'POST', body: JSON.stringify(body) });
    if (!r.ok) return this.fail(r, 'The request could not be saved.');
    return r.json();
  }

  async myRequests(): Promise<any[]> {
    const r = await this.call('/api/requests/mine');
    if (!r.ok) return this.fail(r, 'Could not load your requests.');
    return r.json();
  }

  async inbox(): Promise<any[]> {
    const r = await this.call('/api/requests/inbox');
    if (!r.ok) return this.fail(r, 'Could not load your approvals.');
    return r.json();
  }

  async approved(): Promise<any[]> {
    const r = await this.call('/api/requests/approved');
    if (!r.ok) return this.fail(r, 'Could not load approved requests.');
    return r.json();
  }

  async detail(id: number): Promise<Detail> {
    const r = await this.call(`/api/requests/${id}`);
    if (!r.ok) return this.fail(r, 'This request is not available to you.');
    return r.json();
  }

  async action(id: number, action: string, body?: unknown): Promise<void> {
    const r = await this.call(`/api/requests/${id}/${action}`, { method: 'POST', body: body === undefined ? undefined : JSON.stringify(body) });
    if (!r.ok && r.status !== 204) return this.fail(r, 'That action could not be completed.');
  }

  async myDelegations(): Promise<any[]> {
    const r = await this.call('/api/delegations/mine');
    if (!r.ok) return this.fail(r, 'Could not load delegations.');
    return r.json();
  }

  async addDelegation(body: { toUserId: number; startsOn: string; endsOn: string | null }): Promise<void> {
    const r = await this.call('/api/delegations', { method: 'POST', body: JSON.stringify(body) });
    if (!r.ok) return this.fail(r, 'The delegation could not be saved.');
  }

  async removeDelegation(id: number): Promise<void> {
    const r = await this.call(`/api/delegations/${id}`, { method: 'DELETE' });
    if (!r.ok && r.status !== 204) return this.fail(r, 'The delegation could not be removed.');
  }

  async uploadAttachment(file: File): Promise<{ id: number; name: string; size: number }> {
    const fd = new FormData();
    fd.append('file', file);
    const r = await this.call('/api/attachments', { method: 'POST', body: fd });
    if (!r.ok) return this.fail(r, 'The file could not be uploaded.');
    return r.json();
  }

  async downloadAttachment(id: number, name: string): Promise<void> {
    const r = await this.call(`/api/attachments/${id}`);
    if (!r.ok) return this.fail(r, 'The file could not be downloaded.');
    const url = URL.createObjectURL(await r.blob());
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }
}

export type MasterRow = Record<string, any>;
