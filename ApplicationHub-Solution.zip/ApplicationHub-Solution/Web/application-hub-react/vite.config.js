import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Dev server proxies /api to the .NET API so the refresh cookie stays same-origin.
// The API uses a local development certificate, so certificate checks are relaxed for this proxy only.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    strictPort: true,
    proxy: {
      '/api': { target: 'https://localhost:7100', changeOrigin: true, secure: false }
    }
  }
});
