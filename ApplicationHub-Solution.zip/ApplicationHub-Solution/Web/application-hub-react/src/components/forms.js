import { MASTERS } from '../pages/Masters.jsx';

// Which column of a child master points at a given parent master (for example, Department.DivisionId -> divisions).
export const fkCol = (child, parent) => (child && MASTERS[child] ? MASTERS[child].cols.find((c) => c.fk === parent)?.k : undefined);

// Ids of every file attached on the form, sent to the server so the files are linked to the request.
export const attachmentIds = (form, values) =>
  (form?.fields || []).filter((f) => f.type === 'attach').flatMap((f) => (values[f.id] || []).map((x) => x.id));
