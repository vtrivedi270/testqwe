import { useEffect, useState } from 'react';
import { api } from '../api.js';

// Reads a field whether the API sent it capitalised (column name) or camelCase (anonymous object).
const pick = (row, key) => row[key] ?? row[key.charAt(0).toLowerCase() + key.slice(1)];

export default function ListPage({ title, path, cols, onOpen, empty = 'Nothing here yet.' }) {
  const [rows, setRows] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    api(path).then(async (r) => {
      if (!alive) return;
      if (r.ok) setRows(await r.json());
      else setError('Could not load this list.');
    });
    return () => { alive = false; };
  }, [path]);

  return (
    <div>
      <h2>{title}</h2>
      {error && <div className="notice">{error}</div>}
      {!rows && !error && <div className="card">Loading…</div>}
      {rows && rows.length === 0 && <div className="card">{empty}</div>}
      {rows && rows.length > 0 && (
        <div className="card table-wrap">
          <table>
            <thead><tr>{cols.map((c) => <th key={c.key}>{c.label}</th>)}</tr></thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={pick(r, 'Id') ?? i} className={onOpen ? 'clickable' : ''} onClick={() => onOpen && onOpen(pick(r, 'Id'))}>
                  {cols.map((c) => <td key={c.key}>{c.render ? c.render(pick(r, c.key), r) : pick(r, c.key) ?? ''}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
