import { useEffect, useState } from 'react';
import { api } from '../api.js';

// Each master list is fetched once per page load and shared by every control that uses it.
const cache = {};

export function loadMaster(key) {
  if (!cache[key]) {
    cache[key] = api(`/api/masters/${key}`).then(async (r) => {
      if (!r.ok) { delete cache[key]; return []; }
      return r.json();
    });
  }
  return cache[key];
}

export function useMaster(key) {
  const [rows, setRows] = useState(null);
  useEffect(() => {
    let alive = true;
    if (key) loadMaster(key).then((r) => { if (alive) setRows(r); });
    return () => { alive = false; };
  }, [key]);
  return rows;
}

export const cellOf = (row, k) => row[k] ?? row[k.charAt(0).toLowerCase() + k.slice(1)];
export const nameOf = (rows, id) => {
  const r = (rows || []).find((x) => String(cellOf(x, 'Id')) === String(id));
  return r ? cellOf(r, 'Name') : '—';
};
