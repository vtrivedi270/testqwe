import { useState } from 'react';
import { useMaster, cellOf, nameOf } from './useMaster.js';
import { fkCol } from './forms.js';
import { errorText, uploadFile, downloadAttachment } from '../api.js';

// Renders a form definition with its values. Pass editable + onChange(nextValues) to edit.
export default function FormView({ form, values = {}, editable = false, onChange }) {
  const fields = form?.fields || [];

  // Changing a parent clears everything that depends on it, including grandchildren.
  const clear = (next, id) => fields.filter((x) => x.pf === id).forEach((x) => { delete next[x.id]; clear(next, x.id); });
  const set = (id, val) => {
    const next = { ...values, [id]: val };
    clear(next, id);
    if (onChange) onChange(next);
  };

  return (
    <div>
      {fields.map((f) => (
        <div className="pf" key={f.id}>
          <label>{f.label}{f.required && <span className="req"> *</span>}</label>
          <Control f={f} fields={fields} values={values} value={values[f.id]} editable={editable} set={(v) => set(f.id, v)} />
        </div>
      ))}
    </div>
  );
}

const optionList = (s) => (s || '').split(',').map((x) => x.trim()).filter(Boolean);

function Control({ f, fields, values, value, editable, set }) {
  const dis = !editable;
  switch (f.type) {
    case 'text':
    case 'number':
    case 'date':
      return <input type={f.type} disabled={dis} value={value ?? ''} onChange={(e) => set(e.target.value)} />;
    case 'textarea':
      return <textarea rows={3} disabled={dis} value={value ?? ''} onChange={(e) => set(e.target.value)} />;
    case 'checkbox':
      return <input type="checkbox" disabled={dis} checked={!!value} onChange={(e) => set(e.target.checked)} />;
    case 'dropdown':
      return (
        <select disabled={dis} value={value ?? ''} onChange={(e) => set(e.target.value)}>
          <option value="">Select</option>
          {optionList(f.options).map((o) => <option key={o}>{o}</option>)}
        </select>
      );
    case 'lookup':
      return <MasterSelect src={f.src} value={value} disabled={dis} onChange={set} />;
    case 'dependent':
      return <Dependent f={f} fields={fields} values={values} value={value} disabled={dis} onChange={set} />;
    case 'childlist':
      return <ChildList f={f} fields={fields} values={values} value={value || []} editable={editable} onChange={set} />;
    case 'table':
      return <Grid f={f} value={value || []} editable={editable} onChange={set} />;
    case 'lineitems':
      return <LineItems value={value || []} editable={editable} onChange={set} />;
    case 'attach':
      return <Attach f={f} value={value || []} editable={editable} onChange={set} />;
    default:
      return <div className="readonly">{typeof value === 'string' ? value : '—'}</div>;
  }
}

function MasterSelect({ src, value, disabled, onChange }) {
  const rows = useMaster(src);
  if (disabled) return <div className="readonly">{nameOf(rows, value)}</div>;
  return (
    <select value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
      <option value="">Select</option>
      {(rows || []).map((r) => <option key={cellOf(r, 'Id')} value={cellOf(r, 'Id')}>{cellOf(r, 'Name')}</option>)}
    </select>
  );
}

function Dependent({ f, fields, values, value, disabled, onChange }) {
  const rows = useMaster(f.src);
  const parent = fields.find((p) => p.id === f.pf);
  if (!parent) return <div className="readonly">Parent control is not configured.</div>;
  const pv = values[parent.id];
  if (!pv) return <div className="readonly">Choose {parent.label} first.</div>;
  const key = fkCol(f.src, parent.src);
  const list = (rows || []).filter((r) => String(cellOf(r, key)) === String(pv));
  if (disabled) return <div className="readonly">{nameOf(list, value)}</div>;
  return (
    <select value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
      <option value="">Select</option>
      {list.map((r) => <option key={cellOf(r, 'Id')} value={cellOf(r, 'Id')}>{cellOf(r, 'Name')}</option>)}
    </select>
  );
}

function ChildList({ f, fields, values, value, editable, onChange }) {
  const rows = useMaster(f.src);
  const parent = fields.find((p) => p.id === f.pf);
  if (!parent) return <div className="readonly">Parent control is not configured.</div>;
  const pv = values[parent.id];
  if (!pv) return <div className="readonly">Choose {parent.label} to load records.</div>;
  const key = fkCol(f.src, parent.src);
  const list = (rows || []).filter((r) => String(cellOf(r, key)) === String(pv));
  if (list.length === 0) return <div className="readonly">No records for this selection.</div>;
  return (
    <div>
      {list.map((r) => {
        const id = cellOf(r, 'Id');
        const on = value.map(String).includes(String(id));
        return (
          <label key={id} className="check">
            <input type="checkbox" disabled={!editable} checked={on}
              onChange={(e) => onChange(e.target.checked ? [...value, id] : value.filter((x) => String(x) !== String(id)))} />
            {cellOf(r, 'Name')}
          </label>
        );
      })}
    </div>
  );
}

function Grid({ f, value, editable, onChange }) {
  const cols = f.columns || [];
  const setCell = (i, cid, v) => onChange(value.map((r, j) => (j === i ? { ...r, [cid]: v } : r)));
  return (
    <div>
      <div className="table-wrap">
        <table>
          <thead><tr>{cols.map((c) => <th key={c.id}>{c.label}</th>)}{editable && <th />}</tr></thead>
          <tbody>
            {value.length === 0 && <tr><td colSpan={cols.length + (editable ? 1 : 0)} className="empty">No rows</td></tr>}
            {value.map((r, i) => (
              <tr key={i}>
                {cols.map((c) => <td key={c.id}><Cell col={c} value={r[c.id]} disabled={!editable} onChange={(v) => setCell(i, c.id, v)} /></td>)}
                {editable && <td><button className="bad" onClick={() => onChange(value.filter((_, j) => j !== i))}>✕</button></td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {editable && <button className="sec" onClick={() => onChange([...value, {}])}>+ Add row</button>}
    </div>
  );
}

function Cell({ col, value, disabled, onChange }) {
  if (col.type === 'lookup') return <MasterSelect src={col.src} value={value} disabled={disabled} onChange={onChange} />;
  if (disabled) return <span>{value ?? ''}</span>;
  return <input type={col.type === 'number' ? 'number' : col.type === 'date' ? 'date' : 'text'} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />;
}

function LineItems({ value, editable, onChange }) {
  const items = useMaster('items');
  const set = (i, patch) => onChange(value.map((r, j) => (j === i ? { ...r, ...patch } : r)));
  const amount = (r) => (Number(r.qty) || 0) * (Number(r.price) || 0);
  const total = value.reduce((a, r) => a + amount(r), 0);
  return (
    <div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Item</th><th>Qty</th><th>Unit price</th><th>Amount</th>{editable && <th />}</tr></thead>
          <tbody>
            {value.length === 0 && <tr><td colSpan={editable ? 5 : 4} className="empty">No items</td></tr>}
            {value.map((r, i) => (
              <tr key={i}>
                <td>
                  {editable ? (
                    <select value={r.item ?? ''} onChange={(e) => {
                      const it = (items || []).find((x) => String(cellOf(x, 'Id')) === e.target.value);
                      set(i, { item: e.target.value, price: it ? cellOf(it, 'Price') : '' });
                    }}>
                      <option value="">Select</option>
                      {(items || []).map((x) => <option key={cellOf(x, 'Id')} value={cellOf(x, 'Id')}>{cellOf(x, 'Name')}</option>)}
                    </select>
                  ) : nameOf(items, r.item)}
                </td>
                <td>{editable ? <input type="number" min="1" value={r.qty ?? ''} onChange={(e) => set(i, { qty: e.target.value })} /> : r.qty}</td>
                <td>{editable ? <input type="number" min="0" step="0.01" value={r.price ?? ''} onChange={(e) => set(i, { price: e.target.value })} /> : r.price}</td>
                <td>{amount(r).toFixed(2)}</td>
                {editable && <td><button className="bad" onClick={() => onChange(value.filter((_, j) => j !== i))}>✕</button></td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        {editable ? <button className="sec" onClick={() => onChange([...value, { qty: 1 }])}>+ Add item</button> : <span />}
        <b>Total: {total.toFixed(2)}</b>
      </div>
    </div>
  );
}

function Attach({ f, value, editable, onChange }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const maxFiles = f.maxFiles || 5;
  const maxMB = f.maxMB || 10;

  async function pick(e) {
    setErr('');
    const files = [...e.target.files];
    e.target.value = '';
    if (value.length + files.length > maxFiles) return setErr(`Up to ${maxFiles} files for this field.`);
    const big = files.find((x) => x.size > maxMB * 1024 * 1024);
    if (big) return setErr(`${big.name} is larger than ${maxMB} MB.`);
    setBusy(true);
    try {
      const added = [];
      for (const file of files) {
        const r = await uploadFile(file);
        if (!r.ok) { setErr(await errorText(r, 'Upload failed.')); break; }
        const d = await r.json();
        added.push({ id: d.id, name: d.name, size: d.size });
      }
      if (added.length) onChange([...value, ...added]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      {value.map((a, i) => (
        <div className="log" key={a.id}>
          📎 <button className="link" onClick={() => downloadAttachment(a.id, a.name).catch(() => setErr('Download failed.'))}>{a.name}</button>
          {' '}({Math.max(1, Math.round(a.size / 1024))} KB)
          {editable && <button className="bad" onClick={() => onChange(value.filter((_, j) => j !== i))}>Remove</button>}
        </div>
      ))}
      {editable && <input type="file" multiple accept={f.accept || '.pdf,.png,.jpg,.jpeg,.xlsx,.docx'} disabled={busy} onChange={pick} />}
      {busy && <div className="log">Uploading…</div>}
      {err && <div className="notice">{err}</div>}
    </div>
  );
}
