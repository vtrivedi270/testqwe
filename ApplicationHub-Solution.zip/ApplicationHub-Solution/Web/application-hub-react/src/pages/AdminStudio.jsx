import { useEffect, useState } from 'react';
import { api, errorText } from '../api.js';
import FieldBuilder, { validateFields } from '../components/FieldBuilder.jsx';

const ROLES = ['Requestor', 'Reporting Manager', 'Department Head', 'Division Head', 'HR', 'Admin'];
const FIELD_TYPES = ['text', 'number', 'date', 'textarea', 'checkbox', 'dropdown'];
const newStage = (n) => ({ name: `Stage ${n}`, mode: 'Seq', kind: 'Role', role: 'Reporting Manager', rule: 'Any', actionType: 'Approve', members: [] });
const newField = () => ({ id: 'f' + Math.random().toString(36).slice(2, 8), label: '', type: 'text', required: false, options: '' });

export default function AdminStudio() {
  const [apps, setApps] = useState([]);
  const [users, setUsers] = useState([]);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  // create application
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [fields, setFields] = useState([]);

  // selected application: workflow editor
  const [selId, setSelId] = useState(null);
  const [selName, setSelName] = useState('');
  const [stages, setStages] = useState([]);

  async function loadApps() {
    const r = await api('/api/admin/applications');
    if (r.ok) setApps(await r.json()); else setMsg(await errorText(r, 'Could not load applications.'));
  }

  useEffect(() => {
    loadApps();
    api('/api/users/directory').then(async (r) => { if (r.ok) setUsers(await r.json()); });
  }, []);

  async function createApp() {
    setMsg('');
    if (!name.trim()) return setMsg('Enter an application name.');
    if (fields.some((f) => !f.label.trim())) return setMsg('Every form field needs a label.');
    const fieldProblem = validateFields(fields);
    if (fieldProblem) return setMsg(fieldProblem);
    const formJson = JSON.stringify({ fields: fields.map((f) => ({ ...f, label: f.label.trim() })) });
    setBusy(true);
    const r = await api('/api/applications', { method: 'POST', body: JSON.stringify({ name: name.trim(), description: desc.trim() || null, formJson }) });
    setBusy(false);
    if (!r.ok) return setMsg(await errorText(r, 'The application could not be created.'));
    const d = await r.json();
    setName(''); setDesc(''); setFields([]);
    await loadApps();
    await openApp(d.id, name.trim());
    setMsg('Application created. Now set its workflow, then publish it.');
  }

  async function openApp(id, nameHint) {
    setMsg('');
    setSelId(id);
    setSelName(nameHint || (apps.find((a) => a.Id === id)?.Name ?? ''));
    const r = await api(`/api/admin/applications/${id}/workflow`);
    if (r.ok) setStages(await r.json()); else setMsg(await errorText(r, 'Could not load the workflow.'));
  }

  const setStage = (i, patch) => setStages(stages.map((s, j) => (j === i ? { ...s, ...patch } : s)));

  function validateStages() {
    if (stages.length === 0) return 'Add at least one stage.';
    for (const s of stages) {
      if (!s.name.trim()) return 'Every stage needs a name.';
      if (s.kind === 'Group' && s.members.length === 0) return `Group stage "${s.name}" needs at least one member.`;
    }
    return '';
  }

  async function saveWorkflow() {
    setMsg('');
    const problem = validateStages();
    if (problem) return setMsg(problem);
    const body = stages.map((s) => ({
      name: s.name.trim(), mode: s.mode, kind: s.kind,
      role: s.kind === 'Role' ? s.role : null,
      rule: s.rule, actionType: s.actionType,
      members: s.kind === 'Group' ? s.members : null
    }));
    setBusy(true);
    const r = await api(`/api/applications/${selId}/workflow`, { method: 'PUT', body: JSON.stringify(body) });
    setBusy(false);
    if (r.ok || r.status === 204) { setMsg('Workflow saved.'); loadApps(); }
    else setMsg(await errorText(r, 'The workflow could not be saved.'));
  }

  async function publish(id) {
    setMsg('');
    const r = await api(`/api/admin/applications/${id}/workflow`);
    const saved = r.ok ? await r.json() : [];
    if (saved.length === 0) return setMsg('Save a workflow with at least one stage before publishing.');
    if (!window.confirm('Publish this application? Requesters will be able to submit it.')) return;
    const p = await api(`/api/applications/${id}/publish`, { method: 'POST' });
    if (p.ok || p.status === 204) { setMsg('Application published.'); loadApps(); }
    else setMsg(await errorText(p, 'Could not publish.'));
  }

  return (
    <div>
      <h2>Admin studio</h2>
      {msg && <div className="notice">{msg}</div>}

      <div className="card">
        <h3>Applications</h3>
        <div className="table-wrap">
          <table>
            <thead><tr><th>#</th><th>Name</th><th>Status</th><th>Stages</th><th></th></tr></thead>
            <tbody>
              {apps.length === 0 && <tr><td colSpan={5} className="empty">No applications yet.</td></tr>}
              {apps.map((a) => (
                <tr key={a.Id}>
                  <td>{a.Id}</td><td>{a.Name}</td><td>{a.Status}</td><td>{a.StageCount}</td>
                  <td>
                    <button className="sec" onClick={() => openApp(a.Id, a.Name)}>Workflow</button>
                    {a.Status !== 'Published' && <button className="ok" onClick={() => publish(a.Id)}>Publish</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selId && (
        <div className="card">
          <h3>Workflow: {selName} <span className="log">#{selId}</span></h3>
          {stages.map((s, i) => (
            <div className="field" key={i}>
              <div className="row">
                <label className="stack" style={{ flex: 1 }}>Name<input value={s.name} onChange={(e) => setStage(i, { name: e.target.value })} /></label>
                <label className="stack">Mode
                  <select value={s.mode} onChange={(e) => setStage(i, { mode: e.target.value })}>
                    <option value="Seq">Sequential</option><option value="Par">Parallel with previous</option>
                  </select>
                </label>
                <label className="stack">Approver
                  <select value={s.kind} onChange={(e) => setStage(i, { kind: e.target.value })}>
                    <option value="Role">Single role</option><option value="Group">Group of people</option>
                  </select>
                </label>
                <label className="stack">Action
                  <select value={s.actionType} onChange={(e) => setStage(i, { actionType: e.target.value })}>
                    <option value="Approve">Approve</option><option value="Process">Process &amp; close</option>
                  </select>
                </label>
              </div>
              {s.kind === 'Role' ? (
                <div className="row">
                  <label className="stack">Role
                    <select value={s.role} onChange={(e) => setStage(i, { role: e.target.value })}>
                      {ROLES.map((r) => <option key={r}>{r}</option>)}
                    </select>
                  </label>
                </div>
              ) : (
                <div className="row">
                  <label className="stack">Rule
                    <select value={s.rule} onChange={(e) => setStage(i, { rule: e.target.value })}>
                      <option value="Any">Any one approves</option><option value="All">All must approve</option>
                    </select>
                  </label>
                  <div className="members">
                    {users.map((u) => (
                      <label key={u.Id} className="check">
                        <input type="checkbox" checked={s.members.includes(u.Id)}
                          onChange={(e) => setStage(i, { members: e.target.checked ? [...s.members, u.Id] : s.members.filter((x) => x !== u.Id) })} />
                        {u.Name}
                      </label>
                    ))}
                  </div>
                </div>
              )}
              <div className="row">
                <button className="sec" disabled={i === 0} onClick={() => { const c = [...stages]; [c[i - 1], c[i]] = [c[i], c[i - 1]]; setStages(c); }}>↑</button>
                <button className="sec" disabled={i === stages.length - 1} onClick={() => { const c = [...stages]; [c[i + 1], c[i]] = [c[i], c[i + 1]]; setStages(c); }}>↓</button>
                <button className="bad" onClick={() => setStages(stages.filter((_, j) => j !== i))}>Remove</button>
              </div>
            </div>
          ))}
          <div className="row">
            <button className="sec" onClick={() => setStages([...stages, newStage(stages.length + 1)])}>+ Add stage</button>
            <button disabled={busy} onClick={saveWorkflow}>Save workflow</button>
          </div>
          <p className="log">Locked once the application has requests.</p>
        </div>
      )}

      <div className="card">
        <h3>New application</h3>
        <div className="row">
          <label className="stack" style={{ flex: 1 }}>Name<input value={name} onChange={(e) => setName(e.target.value)} maxLength={200} /></label>
          <label className="stack" style={{ flex: 2 }}>Description<input value={desc} onChange={(e) => setDesc(e.target.value)} maxLength={1000} /></label>
        </div>
        <h4>Form fields</h4>
        <FieldBuilder fields={fields} setFields={setFields} />
        <div className="row">
          <button className="sec" onClick={() => setFields([...fields, newField()])}>+ Add field</button>
          <button disabled={busy} onClick={createApp}>Create application</button>
        </div>
      </div>
    </div>
  );
}
