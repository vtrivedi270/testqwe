import { useEffect, useState } from 'react';
import { api, errorText } from '../api.js';
import FormView from '../components/FormView.jsx';
import { attachmentIds } from '../components/forms.js';

export default function Detail({ id, onBack }) {
  const [d, setD] = useState(null);
  const [dir, setDir] = useState([]);
  const [note, setNote] = useState('');
  const [editValues, setEditValues] = useState({});
  const [stageId, setStageId] = useState('');
  const [toUser, setToUser] = useState('');
  const [msg, setMsg] = useState('');

  async function load() {
    const r = await api(`/api/requests/${id}`);
    if (r.ok) {
      const data = await r.json();
      setD(data);
      setEditValues(data.values || {});
    } else {
      setMsg('This request was not found or is not visible to you.');
    }
  }

  useEffect(() => {
    load();
    api('/api/users/directory').then(async (r) => { if (r.ok) setDir(await r.json()); });
  }, [id]);

  async function act(path, body, done) {
    setMsg('');
    const r = await api(`/api/requests/${id}/${path}`, { method: 'POST', body: body === undefined ? undefined : JSON.stringify(body) });
    if (r.ok || r.status === 204) {
      setMsg(done);
      setNote('');
      load();
    } else {
      setMsg(await errorText(r, 'That action could not be completed.'));
    }
  }

  const needsReason = (label, body) => {
    if (!note.trim()) return setMsg(`Please write a reason before you ${label}.`);
    return act(label === 'reject' ? 'reject' : 'amend', body, label === 'reject' ? 'Rejected.' : 'Sent back for amendment.');
  };

  if (!d) return <div><button className="sec" onClick={onBack}>← Back</button><div className="card">{msg || 'Loading…'}</div></div>;

  return (
    <div>
      <button className="sec" onClick={onBack}>← Back</button>
      <div className="card">
        <h2>{d.application} · #{d.id}</h2>
        <p className="log">Requested by {d.requester} · <b>{d.status}</b> · cycle {d.cycle}</p>
        {d.amendNote && <div className="notice">Amendment requested: {d.amendNote}</div>}
        {d.canEdit ? (
          <>
            <FormView form={d.form} values={editValues} editable onChange={setEditValues} />
            <button onClick={() => act('resubmit', { payloadJson: JSON.stringify(editValues), attachmentIds: attachmentIds(d.form, editValues) }, 'Resubmitted.')}>Resubmit</button>
          </>
        ) : (
          <FormView form={d.form} values={d.values} />
        )}
      </div>

      <div className="card">
        <h3>Approval flow</h3>
        <ol className="flow">
          {d.steps.map((s) => (
            <li key={s.index}>
              {s.stages.map((st) => (
                <span key={st.id} className="chip">
                  {st.name}
                  {st.kind === 'Group' ? ` (${st.rule === 'All' ? 'all' : 'any'} of ${st.members.filter(Boolean).length})` : ''}
                </span>
              ))}
            </li>
          ))}
        </ol>
        <h4>Activity</h4>
        {d.approvals.length === 0 && <div className="log">No actions yet.</div>}
        {d.approvals.map((a, i) => (
          <div key={i} className="log">
            {String(a.ActedAt).slice(0, 16)} · {a.Actor}{a.ActedFor ? ` for ${a.ActedFor}` : ''} · {a.Action}{a.Comment ? ` — ${a.Comment}` : ''}
          </div>
        ))}
      </div>

      {d.actions.length > 0 && (
        <div className="card">
          <h3>Your action</h3>
          <textarea rows={2} maxLength={1000} placeholder="Comment (required to reject or ask to amend)" value={note} onChange={(e) => setNote(e.target.value)} />
          <div className="row">
            <button className="ok" onClick={() => act('approve', { comment: note.trim() || null }, 'Approved.')}>Approve</button>
            <button className="amb" onClick={() => needsReason('amend', { comment: note.trim() })}>Ask to amend</button>
            <button className="bad" onClick={() => needsReason('reject', { comment: note.trim() })}>Reject</button>
          </div>
          <h4>Delegate this step</h4>
          <div className="row">
            <select value={stageId} onChange={(e) => setStageId(e.target.value)}>
              <option value="">Choose step</option>
              {d.actions.map((a) => <option key={a.stageId} value={a.stageId}>{a.stage}</option>)}
            </select>
            <select value={toUser} onChange={(e) => setToUser(e.target.value)}>
              <option value="">Delegate to</option>
              {dir.map((u) => <option key={u.Id} value={u.Id}>{u.Name} · {u.Role}</option>)}
            </select>
            <button className="sec" disabled={!stageId || !toUser} onClick={() => act('delegate', { stageId: +stageId, toUserId: +toUser }, 'Step delegated.')}>Delegate</button>
          </div>
        </div>
      )}

      <div className="card row">
        {d.canPullBack && <button className="sec" onClick={() => act('pullback', undefined, 'Pulled back to draft.')}>Pull back</button>}
        {(d.status === 'In progress' || d.status === 'Amend requested' || d.status === 'Draft') && (
          <button className="bad" onClick={() => window.confirm('Cancel this request? This cannot be undone.') && act('cancel', undefined, 'Request cancelled.')}>Cancel request</button>
        )}
      </div>
      {msg && <div className="notice">{msg}</div>}
    </div>
  );
}
