import { useEffect, useState } from 'react';
import { api, errorText } from '../api.js';

// Column definitions mirror the API registry. fk = the master the column points to.
export const MASTERS = {
  countries: { label: 'Countries', cols: [{ k: 'Name', label: 'Name' }] },
  states: { label: 'States', cols: [{ k: 'Name', label: 'Name' }, { k: 'CountryId', label: 'Country', fk: 'countries' }] },
  cities: { label: 'Cities', cols: [{ k: 'Name', label: 'Name' }, { k: 'StateId', label: 'State', fk: 'states' }] },
  divisions: { label: 'Divisions', cols: [{ k: 'Name', label: 'Name' }] },
  departments: { label: 'Departments', cols: [{ k: 'Name', label: 'Name' }, { k: 'DivisionId', label: 'Division', fk: 'divisions' }] },
  employees: { label: 'Employees', cols: [{ k: 'Name', label: 'Name' }, { k: 'Email', label: 'Email' }, { k: 'DepartmentId', label: 'Department', fk: 'departments' }] },
  assets: { label: 'Assets', cols: [{ k: 'Name', label: 'Name' }, { k: 'EmployeeId', label: 'Employee', fk: 'employees' }] },
  vendors: { label: 'Vendors', cols: [{ k: 'Name', label: 'Name' }, { k: 'Contact', label: 'Contact' }] },
  items: { label: 'Stationery items', cols: [{ k: 'Name', label: 'Name' }, { k: 'Price', label: 'Price', num: true }, { k: 'Stock', label: 'Stock', num: true }] }
};

const cell = (row, k) => row[k] ?? row[k.charAt(0).toLowerCase() + k.slice(1)];

export default function Masters() {
  const [key, setKey] = useState('countries');
  const [rows, setRows] = useState([]);
  const [lookups, setLookups] = useState({});
  const [showInactive, setShowInactive] = useState(false);
  const [form, setForm] = useState({});
  const [editId, setEditId] = useState(null);
  const [msg, setMsg] = useState('');
  const def = MASTERS[key];

  async function load() {
    const r = await api(`/api/masters/${key}${showInactive ? '?includeInactive=true' : ''}`);
    if (r.ok) setRows(await r.json());
    else setMsg(await errorText(r, 'Could not load records.'));
  }

  useEffect(() => { setForm({}); setEditId(null); setMsg(''); load(); }, [key, showInactive]);

  // Load the parent lists that this master's foreign keys point to.
  useEffect(() => {
    def.cols.filter((c) => c.fk && !lookups[c.fk]).forEach((c) => {
      api(`/api/masters/${c.fk}`).then(async (r) => {
        if (r.ok) { const d = await r.json(); setLookups((l) => ({ ...l, [c.fk]: d })); }
      });
    });
  }, [key]);

  const fkName = (c, r) => {
    const p = (lookups[c.fk] || []).find((x) => String(cell(x, 'Id')) === String(cell(r, c.k)));
    return p ? cell(p, 'Name') : '—';
  };

  function payload() {
    const b = {};
    def.cols.forEach((c) => {
      const v = form[c.k];
      if (v === undefined || v === '') return;
      b[c.k] = c.num || c.fk ? Number(v) : v;
    });
    return b;
  }

  async function save() {
    setMsg('');
    const r = await api(editId ? `/api/masters/${key}/${editId}` : `/api/masters/${key}`, {
      method: editId ? 'PUT' : 'POST',
      body: JSON.stringify(payload())
    });
    if (r.ok || r.status === 204 || r.status === 201) {
      setMsg(editId ? 'Record updated.' : 'Record added.');
      setForm({}); setEditId(null); load();
    } else {
      setMsg(await errorText(r, 'The record could not be saved.'));
    }
  }

  function startEdit(r) {
    const f = {};
    def.cols.forEach((c) => { f[c.k] = String(cell(r, c.k) ?? ''); });
    setForm(f); setEditId(cell(r, 'Id'));
  }

  async function deactivate(id) {
    if (!window.confirm('Deactivate this record? Existing requests keep their link to it.')) return;
    const r = await api(`/api/masters/${key}/${id}`, { method: 'DELETE' });
    if (r.ok || r.status === 204) load();
    else setMsg(await errorText(r, 'Could not deactivate the record.'));
  }

  return (
    <div>
      <h2>Master data</h2>
      <div className="tabs">
        {Object.entries(MASTERS).map(([k, m]) => (
          <button key={k} className={k === key ? '' : 'sec'} onClick={() => setKey(k)}>{m.label}</button>
        ))}
      </div>
      {msg && <div className="notice">{msg}</div>}

      <div className="card">
        <label className="check"><input type="checkbox" checked={showInactive} onChange={(e) => setShowInactive(e.target.checked)} /> Show inactive records</label>
        <div className="table-wrap">
          <table>
            <thead><tr><th>#</th>{def.cols.map((c) => <th key={c.k}>{c.label}</th>)}<th /></tr></thead>
            <tbody>
              {rows.length === 0 && <tr><td colSpan={def.cols.length + 2} className="empty">No records.</td></tr>}
              {rows.map((r) => (
                <tr key={cell(r, 'Id')} className={cell(r, 'IsActive') === false ? 'muted' : ''}>
                  <td>{cell(r, 'Id')}</td>
                  {def.cols.map((c) => <td key={c.k}>{c.fk ? fkName(c, r) : String(cell(r, c.k) ?? '')}</td>)}
                  <td>
                    <button className="sec" onClick={() => startEdit(r)}>Edit</button>
                    {cell(r, 'IsActive') !== false && <button className="bad" onClick={() => deactivate(cell(r, 'Id'))}>Deactivate</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card">
        <h3>{editId ? `Edit record #${editId}` : `Add ${def.label.toLowerCase().replace(/s$/, '')}`}</h3>
        <div className="row">
          {def.cols.map((c) => (
            <label className="stack" key={c.k} style={{ flex: 1, minWidth: 180 }}>{c.label}
              {c.fk ? (
                <select value={form[c.k] || ''} onChange={(e) => setForm({ ...form, [c.k]: e.target.value })}>
                  <option value="">Choose</option>
                  {(lookups[c.fk] || []).map((p) => <option key={cell(p, 'Id')} value={cell(p, 'Id')}>{cell(p, 'Name')}</option>)}
                </select>
              ) : (
                <input type={c.num ? 'number' : 'text'} min={c.num ? 0 : undefined} value={form[c.k] || ''} onChange={(e) => setForm({ ...form, [c.k]: e.target.value })} />
              )}
            </label>
          ))}
        </div>
        <div className="row">
          <button onClick={save}>{editId ? 'Update' : 'Add'}</button>
          {editId && <button className="sec" onClick={() => { setForm({}); setEditId(null); }}>Cancel</button>}
        </div>
      </div>
    </div>
  );
}
