import { useEffect, useState } from 'react';
import { api, errorText } from '../api.js';

const ROLES = ['Requestor', 'Reporting Manager', 'Department Head', 'Division Head', 'HR', 'Admin'];

export default function Users() {
  const [rows, setRows] = useState([]);
  const [msg, setMsg] = useState('');
  const [form, setForm] = useState({ email: '', displayName: '', role: 'Requestor', password: '' });
  const [pw, setPw] = useState({});

  async function load() {
    const r = await api('/api/admin/users');
    if (r.ok) setRows(await r.json()); else setMsg(await errorText(r, 'Could not load users.'));
  }
  useEffect(() => { load(); }, []);

  async function create() {
    setMsg('');
    const r = await api('/api/admin/users', { method: 'POST', body: JSON.stringify(form) });
    if (r.ok || r.status === 201) {
      setMsg('User created.');
      setForm({ email: '', displayName: '', role: 'Requestor', password: '' });
      load();
    } else setMsg(await errorText(r, 'The user could not be created.'));
  }

  async function update(id, patch) {
    setMsg('');
    const r = await api(`/api/admin/users/${id}`, { method: 'PUT', body: JSON.stringify(patch) });
    if (r.ok || r.status === 204) load();
    else setMsg(await errorText(r, 'The change could not be saved.'));
  }

  async function resetPassword(id) {
    setMsg('');
    const r = await api(`/api/admin/users/${id}/reset-password`, { method: 'POST', body: JSON.stringify({ password: pw[id] || '' }) });
    if (r.ok || r.status === 204) { setMsg('Password reset. The user has been signed out everywhere.'); setPw({ ...pw, [id]: '' }); }
    else setMsg(await errorText(r, 'The password could not be reset.'));
  }

  return (
    <div>
      <h2>Users and roles</h2>
      {msg && <div className="notice">{msg}</div>}

      <div className="card table-wrap">
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Active</th><th>Reset password</th></tr></thead>
          <tbody>
            {rows.map((u) => (
              <tr key={u.Id}>
                <td>{u.DisplayName}</td>
                <td>{u.Email}</td>
                <td>
                  <select value={u.Role} onChange={(e) => update(u.Id, { role: e.target.value })}>
                    {ROLES.map((r) => <option key={r}>{r}</option>)}
                  </select>
                </td>
                <td><input type="checkbox" checked={!!u.IsActive} onChange={(e) => update(u.Id, { isActive: e.target.checked })} /></td>
                <td>
                  <input type="password" placeholder="New password (12+)" value={pw[u.Id] || ''} onChange={(e) => setPw({ ...pw, [u.Id]: e.target.value })} />
                  <button className="sec" disabled={(pw[u.Id] || '').length < 12} onClick={() => resetPassword(u.Id)}>Reset</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h3>Add user</h3>
        <div className="row">
          <label className="stack" style={{ flex: 1 }}>Name<input value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} /></label>
          <label className="stack" style={{ flex: 1 }}>Email<input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></label>
          <label className="stack">Role
            <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
              {ROLES.map((r) => <option key={r}>{r}</option>)}
            </select>
          </label>
          <label className="stack" style={{ flex: 1 }}>Temporary password (12+)<input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></label>
        </div>
        <button onClick={create}>Create user</button>
      </div>
    </div>
  );
}
