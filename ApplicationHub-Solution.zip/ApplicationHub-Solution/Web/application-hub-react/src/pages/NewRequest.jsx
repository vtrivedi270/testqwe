import { useEffect, useState } from 'react';
import { api, errorText } from '../api.js';
import FormView from '../components/FormView.jsx';
import { attachmentIds } from '../components/forms.js';

export default function NewRequest({ onCreated }) {
  const [apps, setApps] = useState([]);
  const [app, setApp] = useState(null);
  const [form, setForm] = useState(null);
  const [values, setValues] = useState({});
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api('/api/applications').then(async (r) => { if (r.ok) setApps(await r.json()); });
  }, []);

  async function choose(id) {
    setMsg(''); setValues({}); setForm(null); setApp(null);
    if (!id) return;
    const r = await api(`/api/applications/${id}`);
    if (!r.ok) return setMsg('That application is not available.');
    const data = await r.json();
    try { setForm(JSON.parse(data.FormJson || data.formJson || '{}')); setApp(data); }
    catch { setMsg('This application has an invalid form definition.'); }
  }

  async function save(submit) {
    setMsg('');
    const missing = (form?.fields || []).filter((f) => f.required && (values[f.id] === undefined || values[f.id] === '' || values[f.id] === false));
    if (submit && missing.length) return setMsg(`Please complete: ${missing.map((f) => f.label).join(', ')}`);
    setBusy(true);
    const r = await api('/api/requests', {
      method: 'POST',
      body: JSON.stringify({ applicationId: app.Id ?? app.id, payloadJson: JSON.stringify(values), submit, attachmentIds: attachmentIds(form, values) })
    });
    setBusy(false);
    if (r.ok) {
      const d = await r.json();
      onCreated(d.id);
    } else {
      setMsg(await errorText(r, 'The request could not be saved.'));
    }
  }

  return (
    <div>
      <h2>New request</h2>
      <div className="card">
        <label className="stack">Application
          <select onChange={(e) => choose(e.target.value)} defaultValue="">
            <option value="">Choose an application</option>
            {apps.map((a) => <option key={a.Id ?? a.id} value={a.Id ?? a.id}>{a.Name ?? a.name}</option>)}
          </select>
        </label>
      </div>
      {form && (
        <div className="card">
          <FormView form={form} values={values} editable onChange={setValues} />
          <div className="row">
            <button className="sec" disabled={busy} onClick={() => save(false)}>Save draft</button>
            <button disabled={busy} onClick={() => save(true)}>Submit for approval</button>
          </div>
        </div>
      )}
      {msg && <div className="notice">{msg}</div>}
    </div>
  );
}
