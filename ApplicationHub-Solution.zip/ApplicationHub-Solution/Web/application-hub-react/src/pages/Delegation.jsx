import { useEffect, useState } from 'react';
import { api, errorText } from '../api.js';

export default function Delegation() {
  const [rows, setRows] = useState([]);
  const [dir, setDir] = useState([]);
  const [to, setTo] = useState('');
  const [start, setStart] = useState(new Date().toISOString().slice(0, 10));
  const [end, setEnd] = useState('');
  const [msg, setMsg] = useState('');

  async function load() {
    const r = await api('/api/delegations/mine');
    if (r.ok) setRows(await r.json());
  }

  useEffect(() => {
    load();
    api('/api/users/directory').then(async (r) => { if (r.ok) setDir(await r.json()); });
  }, []);

  async function create() {
    setMsg('');
    const r = await api('/api/delegations', {
      method: 'POST',
      body: JSON.stringify({ toUserId: +to, startsOn: start, endsOn: end || null })
    });
    if (r.ok) { setMsg('Delegation saved.'); setTo(''); setEnd(''); load(); }
    else setMsg(await errorText(r, 'The delegation could not be saved.'));
  }

  async function remove(id) {
    if (!window.confirm('Remove this delegation?')) return;
    const r = await api(`/api/delegations/${id}`, { method: 'DELETE' });
    if (r.ok || r.status === 204) load();
  }

  return (
    <div>
      <h2>Delegation</h2>
      <p className="log">While you are away, the person you choose can act on all of your approvals for the dates you set.</p>
      <div className="card row">
        <label className="stack">Delegate to
          <select value={to} onChange={(e) => setTo(e.target.value)}>
            <option value="">Choose a person</option>
            {dir.map((u) => <option key={u.Id} value={u.Id}>{u.Name} · {u.Role}</option>)}
          </select>
        </label>
        <label className="stack">From<input type="date" value={start} onChange={(e) => setStart(e.target.value)} /></label>
        <label className="stack">Until (optional)<input type="date" value={end} onChange={(e) => setEnd(e.target.value)} /></label>
        <button disabled={!to || !start} onClick={create}>Save delegation</button>
      </div>
      {msg && <div className="notice">{msg}</div>}
      <div className="card table-wrap">
        <table>
          <thead><tr><th>Delegate</th><th>From</th><th>Until</th><th></th></tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={4} className="empty">No delegations yet.</td></tr>}
            {rows.map((r) => (
              <tr key={r.Id}>
                <td>{r.ToName}</td>
                <td>{String(r.StartsOn).slice(0, 10)}</td>
                <td>{r.EndsOn ? String(r.EndsOn).slice(0, 10) : 'Open-ended'}</td>
                <td><button className="bad" onClick={() => remove(r.Id)}>Remove</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
