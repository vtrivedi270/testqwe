// The access token lives only in memory. The refresh token is an httpOnly cookie that JavaScript cannot read.
let accessToken = null;
let onLost = () => {};

export const setToken = (t) => { accessToken = t; };
export const onSessionLost = (fn) => { onLost = fn; };

async function send(path, opts) {
  const headers = { ...(opts.headers || {}) };
  if (typeof opts.body === 'string') headers['Content-Type'] = 'application/json';
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  return fetch(path, { credentials: 'same-origin', ...opts, headers });
}

/// Calls the API. On 401 it refreshes the session once and retries; if that fails the user is signed out.
export async function api(path, opts = {}) {
  let r = await send(path, opts);
  if (r.status === 401 && !path.startsWith('/api/auth/')) {
    const rr = await fetch('/api/auth/refresh', { method: 'POST', credentials: 'same-origin' });
    if (rr.ok) {
      const d = await rr.json();
      accessToken = d.accessToken;
      r = await send(path, opts);
    } else {
      accessToken = null;
      onLost();
    }
  }
  return r;
}

export async function errorText(r, fallback = 'Something went wrong.') {
  const d = await r.json().catch(() => ({}));
  return d.error || d.title || fallback;
}

export function uploadFile(file) {
  const fd = new FormData();
  fd.append('file', file);
  return api('/api/attachments', { method: 'POST', body: fd });
}

export async function downloadAttachment(id, name) {
  const r = await api(`/api/attachments/${id}`);
  if (!r.ok) throw new Error('Download failed.');
  const url = URL.createObjectURL(await r.blob());
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
