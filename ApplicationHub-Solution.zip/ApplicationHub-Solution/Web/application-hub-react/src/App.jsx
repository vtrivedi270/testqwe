import { useEffect, useState } from 'react';
import { api, setToken, onSessionLost, errorText } from './api.js';
import ListPage from './components/ListPage.jsx';
import Detail from './pages/Detail.jsx';
import NewRequest from './pages/NewRequest.jsx';
import Delegation from './pages/Delegation.jsx';
import AdminStudio from './pages/AdminStudio.jsx';
import Masters from './pages/Masters.jsx';
import Users from './pages/Users.jsx';

const NAV = [
  { key: 'inbox', label: 'My approvals' },
  { key: 'new', label: 'New request' },
  { key: 'mine', label: 'My requests' },
  { key: 'approved', label: 'Approved by me' },
  { key: 'delegation', label: 'Delegation' },
  { key: 'emails', label: 'Emails' }
];

const LISTS = {
  inbox: {
    title: 'My approvals', path: '/api/requests/inbox', empty: 'Nothing is waiting for you.',
    cols: [
      { key: 'Id', label: '#' },
      { key: 'Application', label: 'Application' },
      { key: 'Requester', label: 'Requested by' },
      { key: 'Stages', label: 'Waiting at', render: (v) => (Array.isArray(v) ? v.join(', ') : '') }
    ]
  },
  mine: {
    title: 'My requests', path: '/api/requests/mine', empty: 'You have not raised any requests yet.',
    cols: [
      { key: 'Id', label: '#' },
      { key: 'Application', label: 'Application' },
      { key: 'Status', label: 'Status' },
      { key: 'CreatedAt', label: 'Created', render: (v) => String(v ?? '').slice(0, 16) }
    ]
  },
  approved: {
    title: 'Approved by me', path: '/api/requests/approved', empty: 'You have not acted on any requests yet.',
    cols: [
      { key: 'Id', label: '#' },
      { key: 'Application', label: 'Application' },
      { key: 'Status', label: 'Status' },
      { key: 'LastActedAt', label: 'Last action', render: (v) => String(v ?? '').slice(0, 16) }
    ]
  },
  emails: {
    title: 'Emails', path: '/api/emails', empty: 'No emails yet.',
    cols: [
      { key: 'CreatedAt', label: 'When', render: (v) => String(v ?? '').slice(0, 16) },
      { key: 'ToAddress', label: 'To' },
      { key: 'Subject', label: 'Subject' },
      { key: 'Status', label: 'Status' }
    ]
  }
};

export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState('inbox');
  const [openId, setOpenId] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    onSessionLost(() => setUser(null));
    restore();
  }, []);

  async function restore() {
    try {
      const r = await fetch('/api/auth/refresh', { method: 'POST', credentials: 'same-origin' });
      if (r.ok) { const d = await r.json(); setToken(d.accessToken); setUser(d.user); }
    } catch { /* no session yet */ }
  }

  async function login(e) {
    e.preventDefault();
    setError(''); setBusy(true);
    const f = new FormData(e.target);
    try {
      const r = await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: f.get('email'), password: f.get('password') }) });
      if (!r.ok) { setError(await errorText(r, 'Sign-in failed.')); return; }
      const d = await r.json();
      setToken(d.accessToken);
      setUser(d.user);
    } catch {
      setError('Cannot reach the server. Check that the API is running.');
    } finally {
      setBusy(false);
    }
  }

  async function logout() {
    await api('/api/auth/logout', { method: 'POST' });
    setToken(null); setUser(null); setOpenId(null); setPage('inbox');
  }

  if (!user) {
    return (
      <form className="card login" onSubmit={login}>
        <h2>Sign in to Application Hub</h2>
        <input name="email" type="email" placeholder="Email" required maxLength={256} autoComplete="username" />
        <input name="password" type="password" placeholder="Password" required maxLength={256} autoComplete="current-password" />
        {error && <div className="notice">{error}</div>}
        <button type="submit" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
      </form>
    );
  }

  const go = (p) => { setOpenId(null); setPage(p); };
  let content;
  if (openId) content = <Detail id={openId} onBack={() => setOpenId(null)} />;
  else if (page === 'new') content = <NewRequest onCreated={(id) => { setPage('mine'); setOpenId(id); }} />;
  else if (page === 'delegation') content = <Delegation />;
  else if (page === 'admin' && user.role === 'Admin') content = <AdminStudio />;
  else if (page === 'masters' && user.role === 'Admin') content = <Masters />;
  else if (page === 'users' && user.role === 'Admin') content = <Users />;
  else content = <ListPage key={page} {...LISTS[page]} onOpen={page === 'emails' ? undefined : setOpenId} />;

  return (
    <div className="shell">
      <aside>
        <div className="who"><b>{user.name}</b><span>{user.role}</span></div>
        {(user.role === 'Admin' ? [...NAV, { key: 'admin', label: 'Admin studio' }, { key: 'masters', label: 'Master data' }, { key: 'users', label: 'Users' }] : NAV).map((n) => (
          <button key={n.key} className={page === n.key && !openId ? 'on' : ''} onClick={() => go(n.key)}>{n.label}</button>
        ))}
        <button className="logout" onClick={logout}>Sign out</button>
      </aside>
      <main>{content}</main>
    </div>
  );
}
