using ApplicationHub.Api.Workflow;
using Xunit;

namespace ApplicationHub.Tests;

public class RulesTests
{
    static StageDef Role(int id, int order, string role, string mode = "Seq") =>
        new(id, order, $"S{id}", role, mode, "Approve", "Role", "Any", new List<int>());

    static StageDef Group(int id, int order, string rule, params int[] members) =>
        new(id, order, $"G{id}", "-", "Seq", "Approve", "Group", rule, members.ToList());

    static UserDef U(int id, string role) => new(id, role, $"User{id}", $"u{id}@test.local");

    static Ctx Make(List<StageDef> stages, List<UserDef> users, int step = 0, string status = "In progress",
        List<(int Stage, int Actor, int? For)>? appr = null,
        List<(int From, int To)>? glob = null,
        List<(int Stage, int From, int To)>? sd = null) => new()
    {
        Req = new ReqDef(1, 1, 99, "Requester", "requester@test.local", status, 1, step, "{}"),
        Stages = stages,
        Steps = Rules.Steps(stages),
        Users = users.ToDictionary(u => u.Id),
        Approvals = appr ?? new(),
        Global = glob ?? new(),
        StepDel = sd ?? new()
    };

    [Fact]
    public void Parallel_stage_joins_the_step_above_it()
    {
        var steps = Rules.Steps(new[] { Role(1, 1, "Reporting Manager"), Role(2, 2, "Department Head", "Par"), Role(3, 3, "HR") });
        Assert.Equal(2, steps.Count);
        Assert.Equal(new[] { 1, 2 }, steps[0].Select(s => s.Id).ToArray());
        Assert.Equal(new[] { 3 }, steps[1].Select(s => s.Id).ToArray());
    }

    [Fact]
    public void Role_stage_accepts_only_that_role()
    {
        var s = Role(1, 1, "Reporting Manager");
        Assert.True(Rules.Accepts(s, U(10, "Reporting Manager")));
        Assert.False(Rules.Accepts(s, U(11, "HR")));
    }

    [Fact]
    public void Any_group_is_satisfied_by_one_approval()
    {
        var g = Group(1, 1, "Any", 10, 11);
        var c = Make(new() { g }, new() { U(10, "HR"), U(11, "HR") }, appr: new() { (1, 10, null) });
        Assert.True(Rules.Satisfied(c, g));
    }

    [Fact]
    public void All_group_needs_every_active_member()
    {
        var g = Group(1, 1, "All", 10, 11);
        var users = new List<UserDef> { U(10, "HR"), U(11, "HR") };
        Assert.False(Rules.Satisfied(Make(new() { g }, users, appr: new() { (1, 10, null) }), g));
        Assert.True(Rules.Satisfied(Make(new() { g }, users, appr: new() { (1, 10, null), (1, 11, null) }), g));
    }

    [Fact]
    public void Inactive_member_does_not_block_an_all_group()
    {
        var g = Group(1, 1, "All", 10, 11);
        var c = Make(new() { g }, new() { U(10, "HR") }, appr: new() { (1, 10, null) });
        Assert.True(Rules.Satisfied(c, g));
    }

    [Fact]
    public void Only_the_current_step_is_actionable()
    {
        var stages = new List<StageDef> { Role(1, 1, "Reporting Manager"), Role(2, 2, "HR") };
        var users = new List<UserDef> { U(10, "Reporting Manager"), U(20, "HR") };
        Assert.Single(Rules.Actionable(Make(stages, users, step: 0), 10));
        Assert.Empty(Rules.Actionable(Make(stages, users, step: 0), 20));
        Assert.Single(Rules.Actionable(Make(stages, users, step: 1), 20));
    }

    [Fact]
    public void Closed_or_rejected_request_has_no_actions()
    {
        var stages = new List<StageDef> { Role(1, 1, "Reporting Manager") };
        var users = new List<UserDef> { U(10, "Reporting Manager") };
        Assert.Empty(Rules.Actionable(Make(stages, users, status: "Rejected"), 10));
        Assert.Empty(Rules.Actionable(Make(stages, users, status: "Closed"), 10));
    }

    [Fact]
    public void Global_delegation_lets_the_delegate_act_for_the_delegator()
    {
        var stages = new List<StageDef> { Role(1, 1, "Reporting Manager") };
        var users = new List<UserDef> { U(10, "Reporting Manager"), U(20, "Department Head") };
        var c = Make(stages, users, glob: new() { (10, 20) });

        // The delegator no longer acts directly...
        Assert.Empty(Rules.Actionable(c, 10));
        // ...but the delegate acts on their behalf.
        var act = Assert.Single(Rules.Actionable(c, 20));
        Assert.Equal(10, act.Principal);
    }

    [Fact]
    public void Step_delegation_moves_only_that_step()
    {
        var stages = new List<StageDef> { Role(1, 1, "Reporting Manager") };
        var users = new List<UserDef> { U(10, "Reporting Manager"), U(21, "Department Head") };
        var c = Make(stages, users, sd: new() { (1, 10, 21) });

        Assert.Empty(Rules.Actionable(c, 10));
        var act = Assert.Single(Rules.Actionable(c, 21));
        Assert.Equal(10, act.Principal);
    }

    [Fact]
    public void Approval_by_a_delegate_counts_for_the_principal()
    {
        var g = Group(1, 1, "All", 10, 11);
        var users = new List<UserDef> { U(10, "HR"), U(11, "HR") };
        // User 11 approved on behalf of user 10; user 11 still has to approve for themselves.
        var c = Make(new() { g }, users, appr: new() { (1, 11, 10) });
        Assert.True(Rules.Satisfied(c, g) == false);
        Assert.Single(Rules.Actionable(c, 11));
    }
}
