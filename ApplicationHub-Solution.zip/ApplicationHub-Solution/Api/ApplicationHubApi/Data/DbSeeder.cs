namespace ApplicationHub.Api.Data;

/// Creates the first admin from configuration (environment variable or user secret). Runs only if the user does not exist.
public static class DbSeeder
{
    public static async Task EnsureAdminAsync(Db db, IConfiguration cfg)
    {
        var email = cfg["Seed:AdminEmail"]?.Trim().ToLowerInvariant();
        var password = cfg["Seed:AdminPassword"];
        if (string.IsNullOrEmpty(email)) return;
        if (string.IsNullOrEmpty(password) || password.Length < 12)
            throw new InvalidOperationException("Seed:AdminPassword must be at least 12 characters when Seed:AdminEmail is set.");

        var exists = await db.QueryAsync("SELECT 1 AS x FROM dbo.Users WHERE Email = @e", ("e", email));
        if (exists.Count > 0) return;

        var hash = BCrypt.Net.BCrypt.HashPassword(password, workFactor: 12);
        await db.ExecAsync(
            "INSERT INTO dbo.Users (Email, DisplayName, PasswordHash, Role) VALUES (@e, @n, @h, N'Admin')",
            ("e", email), ("n", "Administrator"), ("h", hash));
    }
}
