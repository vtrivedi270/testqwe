using System.Globalization;
using System.Text.Json;
using ApplicationHub.Api.Data;
using ApplicationHub.Api.Masters;

namespace ApplicationHub.Api.Forms;

public sealed record FieldError(string Field, string Message);

public sealed record ValidationOutcome(string SanitizedJson, List<int> AttachmentIds, List<FieldError> Errors)
{
    public bool Ok => Errors.Count == 0;
}

/// Checks submitted values against the application's form definition and returns a cleaned copy.
/// Prices come from master data, never from the client. Unknown fields are dropped.
public sealed class FormValidator(Db db)
{
    private const int MaxText = 2000, MaxLong = 4000, MaxRows = 100, MaxQty = 100000;
    private static readonly HashSet<string> KnownTypes =
        ["text", "number", "date", "textarea", "checkbox", "attach", "dropdown", "lookup", "dependent", "childlist", "table", "lineitems"];

    private sealed record Col(string Id, string Label, string Type, string? Src);

    public async Task<ValidationOutcome> ValidateAsync(int appId, string payloadJson, int userId, int? requestId, bool submit)
    {
        var errors = new List<FieldError>();
        var attachments = new List<int>();

        var app = await db.QueryAsync("SELECT FormJson FROM dbo.Applications WHERE Id = @a", ("a", appId));
        if (app.Count == 0) return new ValidationOutcome("{}", attachments, [new FieldError("", "Application not found.")]);

        using var formDoc = JsonDocument.Parse((string)app[0]["FormJson"]!);
        using var payloadDoc = JsonDocument.Parse(payloadJson);
        if (payloadDoc.RootElement.ValueKind != JsonValueKind.Object)
            return new ValidationOutcome("{}", attachments, [new FieldError("", "Form values must be an object.")]);

        var payload = payloadDoc.RootElement;
        var fields = formDoc.RootElement.TryGetProperty("fields", out var fa) && fa.ValueKind == JsonValueKind.Array
            ? fa.EnumerateArray().ToList()
            : new List<JsonElement>();

        var ids = fields.Select(f => Str(f, "id")).ToList();
        if (ids.Distinct().Count() != ids.Count) errors.Add(new FieldError("", "The form definition has duplicate field ids."));
        var fieldsById = fields.ToDictionary(f => Str(f, "id"), f => f);

        // Non-dependent controls first, so parents are known before the controls that depend on them.
        var ordered = fields.OrderBy(f => (Str(f, "type") is "dependent" or "childlist") ? 1 : 0).ToList();
        var output = new Dictionary<string, object?>();

        foreach (var f in ordered)
        {
            var id = Str(f, "id");
            var label = Str(f, "label");
            var type = Str(f, "type");
            if (!KnownTypes.Contains(type))
            {
                errors.Add(new FieldError(label, "This control type is not supported."));
                continue;
            }

            var has = payload.TryGetProperty(id, out var v);
            if (!has || IsEmpty(v))
            {
                if (submit && Bool(f, "required")) errors.Add(new FieldError(label, "This field is required."));
                continue;
            }

            var (value, error) = await CheckAsync(f, v, fieldsById, output, userId, requestId, attachments);
            if (error is not null) errors.Add(new FieldError(label, error));
            else output[id] = value;
        }

        return new ValidationOutcome(JsonSerializer.Serialize(output), attachments.Distinct().ToList(), errors);
    }

    private async Task<(object? Value, string? Error)> CheckAsync(JsonElement f, JsonElement v,
        Dictionary<string, JsonElement> fieldsById, Dictionary<string, object?> output,
        int userId, int? requestId, List<int> attachments)
    {
        switch (Str(f, "type"))
        {
            case "text":
                return Text(v, MaxText);
            case "textarea":
                return Text(v, MaxLong);
            case "number":
                return Number(v);
            case "date":
                return DateValue(v);
            case "checkbox":
            {
                if (v.ValueKind is JsonValueKind.True or JsonValueKind.False) return (v.GetBoolean(), null);
                return (null, "Choose yes or no.");
            }
            case "dropdown":
            {
                var t = Text(v, 200);
                if (t.Error is not null) return t;
                var options = Str(f, "options").Split(',').Select(o => o.Trim());
                if (!options.Contains((string)t.Value!)) return (null, "Choose one of the listed options.");
                return t;
            }
            case "lookup":
            {
                return await LookupCell(Str(f, "src"), v);
            }
            case "dependent":
            {
                var (id, err) = IntValue(v);
                if (err is not null) return (null, err);
                var parent = ParentOf(f, fieldsById, output, out var parentError);
                if (parent is null) return (null, parentError);
                var fk = FkFor(Str(f, "src"), Str(parent.Value.Field, "src"));
                var row = await MasterRow(Str(f, "src"), id);
                if (fk is null || row is null || !Same(row[fk], parent.Value.Value))
                    return (null, "Choose an option that belongs to the selected parent.");
                return (id, null);
            }
            case "childlist":
            {
                var parent = ParentOf(f, fieldsById, output, out var parentError);
                if (parent is null) return (null, parentError);
                var fk = FkFor(Str(f, "src"), Str(parent.Value.Field, "src"));
                if (fk is null || v.ValueKind != JsonValueKind.Array) return (null, "Choose one or more records.");
                var list = new List<int>();
                foreach (var item in v.EnumerateArray())
                {
                    var (id, err) = IntValue(item);
                    if (err is not null) return (null, err);
                    var row = await MasterRow(Str(f, "src"), id);
                    if (row is null || !Same(row[fk], parent.Value.Value))
                        return (null, "One of the selected records does not belong to the selected parent.");
                    list.Add(id);
                }
                return (list, null);
            }
            case "table":
            {
                if (v.ValueKind != JsonValueKind.Array || v.GetArrayLength() > MaxRows)
                    return (null, $"Up to {MaxRows} rows are allowed.");
                var cols = Columns(f);
                var rows = new List<Dictionary<string, object?>>();
                var rowNo = 0;
                foreach (var r in v.EnumerateArray())
                {
                    rowNo++;
                    if (r.ValueKind != JsonValueKind.Object) return (null, $"Row {rowNo} is not valid.");
                    var clean = new Dictionary<string, object?>();
                    foreach (var c in cols)
                    {
                        var cv = r.TryGetProperty(c.Id, out var x) ? x : default;
                        if (cv.ValueKind is JsonValueKind.Undefined or JsonValueKind.Null) { clean[c.Id] = null; continue; }
                        var (val, err) = await CellAsync(c, cv);
                        if (err is not null) return (null, $"Row {rowNo}, {c.Label}: {err}");
                        clean[c.Id] = val;
                    }
                    rows.Add(clean);
                }
                return (rows, null);
            }
            case "lineitems":
            {
                if (v.ValueKind != JsonValueKind.Array || v.GetArrayLength() > MaxRows)
                    return (null, $"Up to {MaxRows} items are allowed.");
                var lines = new List<Dictionary<string, object?>>();
                var n = 0;
                foreach (var r in v.EnumerateArray())
                {
                    n++;
                    if (r.ValueKind != JsonValueKind.Object) return (null, $"Line {n} is not valid.");
                    var (itemId, e1) = IntValue(r.TryGetProperty("item", out var it) ? it : default);
                    if (e1 is not null) return (null, $"Line {n}: choose an item.");
                    var price = await ItemPrice(itemId);
                    if (price is null) return (null, $"Line {n}: the item is not available.");
                    var (qty, e2) = IntValue(r.TryGetProperty("qty", out var q) ? q : default);
                    if (e2 is not null || qty < 1 || qty > MaxQty)
                        return (null, $"Line {n}: quantity must be a whole number from 1 to {MaxQty:N0}.");
                    lines.Add(new()
                    {
                        ["item"] = itemId,
                        ["qty"] = qty,
                        ["price"] = price.Value,
                        ["amount"] = price.Value * qty
                    });
                }
                return (lines, null);
            }
            case "attach":
            {
                var max = Math.Min(Int(f, "maxFiles", 5), 20);
                if (v.ValueKind != JsonValueKind.Array || v.GetArrayLength() > max)
                    return (null, $"Up to {max} files are allowed.");
                var files = new List<Dictionary<string, object?>>();
                foreach (var item in v.EnumerateArray())
                {
                    var idEl = item.ValueKind == JsonValueKind.Object && item.TryGetProperty("id", out var ie) ? ie : item;
                    var (fid, err) = IntValue(idEl);
                    if (err is not null) return (null, "A file reference is not valid.");
                    // Only files this user uploaded, and not already attached to another request.
                    var rows = await db.QueryAsync(
                        "SELECT FileName, SizeBytes FROM dbo.Attachments WHERE Id = @id AND UploadedBy = @u AND (RequestId IS NULL OR RequestId = @r)",
                        ("id", fid), ("u", userId), ("r", (object?)requestId));
                    if (rows.Count == 0) return (null, "A file is missing or does not belong to you.");
                    attachments.Add(fid);
                    files.Add(new() { ["id"] = fid, ["name"] = rows[0]["FileName"], ["size"] = rows[0]["SizeBytes"] });
                }
                return (files, null);
            }
            default:
                return (null, "Unsupported control.");
        }
    }

    private async Task<(object? Value, string? Error)> CellAsync(Col c, JsonElement v)
    {
        switch (c.Type)
        {
            case "number": return Number(v);
            case "date": return DateValue(v);
            case "lookup": return await LookupCell(c.Src ?? "", v);
            default: return Text(v, MaxText);
        }
    }

    private async Task<(object? Value, string? Error)> LookupCell(string src, JsonElement v)
    {
        var (id, err) = IntValue(v);
        if (err is not null) return (null, err);
        var row = await MasterRow(src, id);
        return row is null ? (null, "Choose a valid option.") : (id, null);
    }

    /// The parent control's sanitized value, or an error when the parent is missing or not yet filled in.
    private static (JsonElement Field, object? Value)? ParentOf(JsonElement f, Dictionary<string, JsonElement> fieldsById,
        Dictionary<string, object?> output, out string? error)
    {
        error = null;
        var parentField = fieldsById.GetValueOrDefault(Str(f, "pf"));
        if (parentField.ValueKind != JsonValueKind.Object) { error = "The parent control is not configured."; return null; }
        var pid = Str(parentField, "id");
        if (!output.TryGetValue(pid, out var pv) || pv is null)
        {
            error = $"Choose {Str(parentField, "label")} first.";
            return null;
        }
        return (parentField, pv);
    }

    private static List<Col> Columns(JsonElement f)
    {
        var list = new List<Col>();
        if (f.TryGetProperty("columns", out var cols) && cols.ValueKind == JsonValueKind.Array)
            foreach (var c in cols.EnumerateArray())
                list.Add(new Col(Str(c, "id"), Str(c, "label"), Str(c, "type"), Str(c, "src") is "" ? null : Str(c, "src")));
        return list;
    }

    /// Finds the column on the child master that points at the parent master (for example DivisionId for departments).
    private static string? FkFor(string child, string parent) =>
        MasterRegistry.TryGet(child, out var m) && m is not null
            ? m.ForeignKeys.Where(kv => kv.Value == parent).Select(kv => kv.Key).FirstOrDefault()
            : null;

    private async Task<Dictionary<string, object?>?> MasterRow(string src, int id)
    {
        if (!MasterRegistry.TryGet(src, out var m) || m is null) return null;
        var cols = m.ForeignKeys.Keys.ToList();
        var select = "Id" + (cols.Count > 0 ? ", " + string.Join(", ", cols) : "");
        var rows = await db.QueryAsync($"SELECT {select} FROM {m.Table} WHERE Id = @id AND IsActive = 1", ("id", id));
        return rows.Count == 0 ? null : rows[0];
    }

    private async Task<decimal?> ItemPrice(int id)
    {
        var rows = await db.QueryAsync("SELECT Price FROM dbo.StationeryItems WHERE Id = @id AND IsActive = 1", ("id", id));
        return rows.Count == 0 ? null : Convert.ToDecimal(rows[0]["Price"]);
    }

    private static bool Same(object? a, object? b) => a is not null && b is not null && Convert.ToInt32(a) == Convert.ToInt32(b);

    private static string Str(JsonElement e, string name) =>
        e.TryGetProperty(name, out var p) && p.ValueKind == JsonValueKind.String ? p.GetString() ?? "" : "";

    private static bool Bool(JsonElement e, string name) =>
        e.TryGetProperty(name, out var p) && p.ValueKind == JsonValueKind.True;

    private static int Int(JsonElement e, string name, int fallback) =>
        e.TryGetProperty(name, out var p) && p.ValueKind == JsonValueKind.Number && p.TryGetInt32(out var i) ? i : fallback;

    private static bool IsEmpty(JsonElement v) =>
        v.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined or JsonValueKind.False
        || (v.ValueKind == JsonValueKind.String && string.IsNullOrWhiteSpace(v.GetString()))
        || (v.ValueKind == JsonValueKind.Array && v.GetArrayLength() == 0);

    private static (object? Value, string? Error) Text(JsonElement v, int max)
    {
        if (v.ValueKind != JsonValueKind.String) return (null, "Enter text.");
        var t = v.GetString()!.Trim();
        return t.Length > max ? (null, $"Use {max} characters or fewer.") : (t, null);
    }

    private static (object? Value, string? Error) Number(JsonElement v)
    {
        if (v.ValueKind == JsonValueKind.Number && v.TryGetDecimal(out var d)) return (d, null);
        if (v.ValueKind == JsonValueKind.String && decimal.TryParse(v.GetString(), NumberStyles.Number, CultureInfo.InvariantCulture, out var s))
            return (s, null);
        return (null, "Enter a valid number.");
    }

    private static (object? Value, string? Error) DateValue(JsonElement v)
    {
        if (v.ValueKind == JsonValueKind.String &&
            DateOnly.TryParseExact(v.GetString(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d))
            return (d.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), null);
        return (null, "Use the date format yyyy-mm-dd.");
    }

    private static (int Id, string? Error) IntValue(JsonElement v)
    {
        if (v.ValueKind == JsonValueKind.Number && v.TryGetInt32(out var i) && i > 0) return (i, null);
        if (v.ValueKind == JsonValueKind.String && int.TryParse(v.GetString(), out var j) && j > 0) return (j, null);
        return (0, "Choose a valid option.");
    }
}
