using ApplicationHub.Api.Data;
using Microsoft.AspNetCore.Http;

namespace ApplicationHub.Api.Workflow;

public sealed class WorkflowException(string message, int status = StatusCodes.Status400BadRequest) : Exception(message)
{
    public int Status { get; } = status;
}

/// All state changes run inside one transaction with the request row locked (UPDLOCK), so two approvers cannot race.
public sealed class WorkflowService
{
    public static readonly string[] Roles =
        ["Requestor", "Reporting Manager", "Department Head", "Division Head", "HR", "Admin"];

    public async Task<Ctx> LoadAsync(Tx tx, int reqId, bool lockRow)
    {
        var hint = lockRow ? "WITH (UPDLOCK, ROWLOCK)" : "";
        var rq = await tx.QueryAsync(
            $"SELECT r.Id, r.ApplicationId, r.RequesterId, u.DisplayName, u.Email, r.Status, r.Cycle, r.CurrentStep, r.PayloadJson " +
            $"FROM dbo.Requests r {hint} JOIN dbo.Users u ON u.Id = r.RequesterId WHERE r.Id = @id", ("id", reqId));
        if (rq.Count == 0) throw new WorkflowException("Request not found.", StatusCodes.Status404NotFound);
        var r = rq[0];
        var req = new ReqDef(Convert.ToInt32(r["Id"]), Convert.ToInt32(r["ApplicationId"]), Convert.ToInt32(r["RequesterId"]),
            (string)r["DisplayName"]!, (string)r["Email"]!, (string)r["Status"]!, Convert.ToInt32(r["Cycle"]),
            Convert.ToInt32(r["CurrentStep"]), (string)r["PayloadJson"]!);

        var st = await tx.QueryAsync(
            "SELECT Id, StepOrder, Name, Role, Mode, ActionType, Kind, Rule FROM dbo.WorkflowStages WHERE ApplicationId = @a ORDER BY StepOrder",
            ("a", req.ApplicationId));
        var mem = await tx.QueryAsync(
            "SELECT sm.StageId, sm.UserId FROM dbo.StageMembers sm JOIN dbo.WorkflowStages s ON s.Id = sm.StageId WHERE s.ApplicationId = @a",
            ("a", req.ApplicationId));
        var memberMap = mem.GroupBy(m => Convert.ToInt32(m["StageId"]))
            .ToDictionary(g => g.Key, g => g.Select(m => Convert.ToInt32(m["UserId"])).ToList());
        var stages = st.Select(s =>
        {
            var id = Convert.ToInt32(s["Id"]);
            return new StageDef(id, Convert.ToInt32(s["StepOrder"]), (string)s["Name"]!, (string)s["Role"]!,
                (string)s["Mode"]!, (string)s["ActionType"]!, (string)s["Kind"]!, (string)s["Rule"]!,
                memberMap.TryGetValue(id, out var m) ? m : new List<int>());
        }).ToList();

        var users = (await tx.QueryAsync("SELECT Id, Role, DisplayName, Email FROM dbo.Users WHERE IsActive = 1"))
            .ToDictionary(u => Convert.ToInt32(u["Id"]),
                u => new UserDef(Convert.ToInt32(u["Id"]), (string)u["Role"]!, (string)u["DisplayName"]!, (string)u["Email"]!));

        var appr = (await tx.QueryAsync(
                "SELECT StageId, ActorId, ActedForId FROM dbo.Approvals WHERE RequestId = @r AND Cycle = @c AND Action IN (N'Approve', N'Process')",
                ("r", reqId), ("c", req.Cycle)))
            .Select(a => (Stage: Convert.ToInt32(a["StageId"]), Actor: Convert.ToInt32(a["ActorId"]),
                For: a["ActedForId"] is null ? (int?)null : Convert.ToInt32(a["ActedForId"]))).ToList();

        var glob = (await tx.QueryAsync(
                "SELECT FromUserId, ToUserId FROM dbo.Delegations WHERE StartsOn <= CAST(SYSUTCDATETIME() AS DATE) AND (EndsOn IS NULL OR EndsOn >= CAST(SYSUTCDATETIME() AS DATE))"))
            .Select(d => (From: Convert.ToInt32(d["FromUserId"]), To: Convert.ToInt32(d["ToUserId"]))).ToList();

        var sd = (await tx.QueryAsync(
                "SELECT StageId, FromUserId, ToUserId FROM dbo.StepDelegations WHERE RequestId = @r AND Cycle = @c",
                ("r", reqId), ("c", req.Cycle)))
            .Select(d => (Stage: Convert.ToInt32(d["StageId"]), From: Convert.ToInt32(d["FromUserId"]), To: Convert.ToInt32(d["ToUserId"]))).ToList();

        return new Ctx
        {
            Req = req, Stages = stages, Steps = Rules.Steps(stages), Users = users,
            Approvals = appr, Global = glob, StepDel = sd
        };
    }

    public async Task<int> CreateAsync(Tx tx, int appId, int requesterId, string payload, bool submit, IReadOnlyList<int> attachmentIds)
    {
        var count = await tx.ScalarIntAsync("SELECT COUNT(*) FROM dbo.WorkflowStages WHERE ApplicationId = @a", ("a", appId));
        if (count == 0) throw new WorkflowException("This application has no workflow yet.", StatusCodes.Status409Conflict);

        var id = await tx.ScalarIntAsync(
            "INSERT INTO dbo.Requests (ApplicationId, RequesterId, PayloadJson, Status, Cycle) OUTPUT INSERTED.Id VALUES (@a, @r, @p, @s, 1)",
            ("a", appId), ("r", requesterId), ("p", payload), ("s", submit ? "In progress" : "Draft"));
        await LinkAttachments(tx, id, requesterId, attachmentIds);

        if (submit)
        {
            var c = await LoadAsync(tx, id, false);
            await Notify(tx, id, new[] { c.Req.RequesterEmail }, $"Request {id} submitted");
            await NotifyStep(tx, c, 0, $"Action required: request {id}");
        }
        await Audit(tx, requesterId, "REQUEST_CREATE", $"Request {id}, submit={submit}");
        return id;
    }

    public async Task ApproveAsync(Tx tx, int reqId, int actorId, string? comment)
    {
        var c = await LoadAsync(tx, reqId, true);
        var acts = Rules.Actionable(c, actorId);
        if (acts.Count == 0) throw new WorkflowException("You have no pending action on this request.", StatusCodes.Status403Forbidden);
        var (stage, principal) = acts[0];
        await Record(tx, c, stage.Id, actorId, principal, stage.ActionType == "Process" ? "Process" : "Approve", comment);

        c = await LoadAsync(tx, reqId, false);
        if (Rules.StepDone(c)) await Advance(tx, c);
        else await tx.ExecAsync("UPDATE dbo.Requests SET UpdatedAt = SYSUTCDATETIME() WHERE Id = @r", ("r", reqId));
        await Audit(tx, actorId, "APPROVE", $"Request {reqId}, stage {stage.Name}");
    }

    public async Task RejectAsync(Tx tx, int reqId, int actorId, string reason)
    {
        var c = await LoadAsync(tx, reqId, true);
        var acts = Rules.Actionable(c, actorId);
        if (acts.Count == 0) throw new WorkflowException("You have no pending action on this request.", StatusCodes.Status403Forbidden);
        var (stage, principal) = acts[0];
        await Record(tx, c, stage.Id, actorId, principal, "Reject", reason);
        await tx.ExecAsync("UPDATE dbo.Requests SET Status = N'Rejected', UpdatedAt = SYSUTCDATETIME() WHERE Id = @r", ("r", reqId));
        await Notify(tx, reqId, new[] { c.Req.RequesterEmail }, $"Request {reqId} was rejected");
        await Audit(tx, actorId, "REJECT", $"Request {reqId}");
    }

    public async Task AmendAsync(Tx tx, int reqId, int actorId, string note)
    {
        var c = await LoadAsync(tx, reqId, true);
        var acts = Rules.Actionable(c, actorId);
        if (acts.Count == 0) throw new WorkflowException("You have no pending action on this request.", StatusCodes.Status403Forbidden);
        var (stage, principal) = acts[0];
        await Record(tx, c, stage.Id, actorId, principal, "AskAmend", note);
        await tx.ExecAsync(
            "UPDATE dbo.Requests SET Status = N'Amend requested', AmendNote = @n, UpdatedAt = SYSUTCDATETIME() WHERE Id = @r",
            ("n", note), ("r", reqId));
        await Notify(tx, reqId, new[] { c.Req.RequesterEmail }, $"Amendment requested on request {reqId}");
        await Audit(tx, actorId, "AMEND", $"Request {reqId}");
    }

    public async Task DelegateStepAsync(Tx tx, int reqId, int actorId, int stageId, int toUserId)
    {
        var c = await LoadAsync(tx, reqId, true);
        var stage = c.Stages.FirstOrDefault(s => s.Id == stageId)
            ?? throw new WorkflowException("Stage not found.", StatusCodes.Status404NotFound);
        var onCurrentStep = c.Steps[Math.Min(c.Req.CurrentStep, c.Steps.Count - 1)].Any(s => s.Id == stageId);
        var canAct = c.Req.Status == "In progress" && onCurrentStep && !Rules.Satisfied(c, stage)
                     && Rules.Authorities(c, actorId, stage).Contains(actorId);
        if (!canAct) throw new WorkflowException("You cannot delegate this step.", StatusCodes.Status403Forbidden);
        if (toUserId == actorId || !c.Users.TryGetValue(toUserId, out var to))
            throw new WorkflowException("Choose another active person to delegate to.");

        await tx.ExecAsync(
            "INSERT INTO dbo.StepDelegations (RequestId, StageId, FromUserId, ToUserId, Cycle) VALUES (@r, @s, @f, @t, @c)",
            ("r", reqId), ("s", stageId), ("f", actorId), ("t", toUserId), ("c", c.Req.Cycle));
        await Notify(tx, reqId, new[] { to.Email }, $"Approval delegated to you on request {reqId}");
        await Audit(tx, actorId, "DELEGATE_STEP", $"Request {reqId}, stage {stage.Name} to user {toUserId}");
    }

    public async Task ResubmitAsync(Tx tx, int reqId, int actorId, string payload, IReadOnlyList<int> attachmentIds)
    {
        var c = await LoadAsync(tx, reqId, true);
        if (c.Req.RequesterId != actorId) throw new WorkflowException("Only the requester can resubmit.", StatusCodes.Status403Forbidden);
        if (c.Req.Status is not ("Draft" or "Amend requested"))
            throw new WorkflowException("This request cannot be resubmitted in its current state.", StatusCodes.Status409Conflict);

        await tx.ExecAsync(
            "UPDATE dbo.Requests SET Status = N'In progress', CurrentStep = 0, Cycle = Cycle + 1, PayloadJson = @p, AmendNote = NULL, UpdatedAt = SYSUTCDATETIME() WHERE Id = @r",
            ("p", payload), ("r", reqId));
        await LinkAttachments(tx, reqId, actorId, attachmentIds);
        c = await LoadAsync(tx, reqId, false);
        await NotifyStep(tx, c, 0, $"Action required: request {reqId} resubmitted");
        await Audit(tx, actorId, "RESUBMIT", $"Request {reqId}");
    }

    public async Task PullBackAsync(Tx tx, int reqId, int actorId)
    {
        var c = await LoadAsync(tx, reqId, true);
        if (c.Req.RequesterId != actorId) throw new WorkflowException("Only the requester can pull back a request.", StatusCodes.Status403Forbidden);
        if (c.Req.Status != "In progress")
            throw new WorkflowException("Only a request in progress can be pulled back.", StatusCodes.Status409Conflict);
        if (c.Approvals.Count > 0)
            throw new WorkflowException("A request that has already been acted on cannot be pulled back. Ask an approver to ask for amendment instead.", StatusCodes.Status409Conflict);

        await tx.ExecAsync("UPDATE dbo.Requests SET Status = N'Draft', CurrentStep = 0, UpdatedAt = SYSUTCDATETIME() WHERE Id = @r", ("r", reqId));
        await Audit(tx, actorId, "PULL_BACK", $"Request {reqId}");
    }

    public async Task CancelAsync(Tx tx, int reqId, int actorId, string role)
    {
        var c = await LoadAsync(tx, reqId, true);
        if (c.Req.RequesterId != actorId && role != "Admin")
            throw new WorkflowException("Only the requester or an admin can cancel.", StatusCodes.Status403Forbidden);
        if (c.Req.Status is not ("Draft" or "In progress" or "Amend requested"))
            throw new WorkflowException("This request can no longer be cancelled.", StatusCodes.Status409Conflict);

        await tx.ExecAsync("UPDATE dbo.Requests SET Status = N'Cancelled', UpdatedAt = SYSUTCDATETIME() WHERE Id = @r", ("r", reqId));
        await Notify(tx, reqId, new[] { c.Req.RequesterEmail }, $"Request {reqId} was cancelled");
        if (c.Req.Status == "In progress" && c.Req.CurrentStep < c.Steps.Count)
            await NotifyStep(tx, c, c.Req.CurrentStep, $"Request {reqId} was cancelled");
        await Audit(tx, actorId, "CANCEL", $"Request {reqId}");
    }

    /// Attaches files the requester uploaded earlier. Files already linked to another request are ignored.
    private static async Task LinkAttachments(Tx tx, int reqId, int userId, IReadOnlyList<int> ids)
    {
        foreach (var id in ids.Distinct())
            await tx.ExecAsync("UPDATE dbo.Attachments SET RequestId = @r WHERE Id = @a AND UploadedBy = @u AND RequestId IS NULL",
                ("r", reqId), ("a", id), ("u", userId));
    }

    /// Requester, admin, or anyone who can act on the request may view its files.
    public async Task<bool> CanView(Db db, int reqId, int userId, string role)
    {
        try
        {
            return await db.InTransactionAsync(async tx =>
            {
                var c = await LoadAsync(tx, reqId, false);
                if (c.Req.RequesterId == userId || role == "Admin") return true;
                return c.Users.TryGetValue(userId, out var u) && c.Steps.SelectMany(s => s).Any(s => Rules.Accepts(s, u));
            });
        }
        catch (WorkflowException) { return false; }
    }

    private static Task Record(Tx tx, Ctx c, int stageId, int actorId, int principal, string action, string? comment) =>
        tx.ExecAsync(
            "INSERT INTO dbo.Approvals (RequestId, StageId, ActorId, ActedForId, Action, Comment, Cycle) VALUES (@r, @s, @a, @f, @act, @cm, @c)",
            ("r", c.Req.Id), ("s", stageId), ("a", actorId), ("f", principal == actorId ? (int?)null : principal),
            ("act", action), ("cm", string.IsNullOrWhiteSpace(comment) ? null : comment.Trim()), ("c", c.Req.Cycle));

    private async Task Advance(Tx tx, Ctx c)
    {
        var next = c.Req.CurrentStep + 1;
        if (next >= c.Steps.Count)
        {
            await tx.ExecAsync("UPDATE dbo.Requests SET Status = N'Closed', CurrentStep = @n, UpdatedAt = SYSUTCDATETIME() WHERE Id = @r",
                ("n", next), ("r", c.Req.Id));
            await Notify(tx, c.Req.Id, new[] { c.Req.RequesterEmail }, $"Request {c.Req.Id} is closed");
        }
        else
        {
            await tx.ExecAsync("UPDATE dbo.Requests SET CurrentStep = @n, UpdatedAt = SYSUTCDATETIME() WHERE Id = @r",
                ("n", next), ("r", c.Req.Id));
            await NotifyStep(tx, c, next, $"Action required: request {c.Req.Id}");
        }
    }

    private static Task NotifyStep(Tx tx, Ctx c, int step, string subject) =>
        Notify(tx, c.Req.Id, c.Steps[step].SelectMany(s => Rules.Recipients(c, s)).Select(u => u.Email), subject);

    /// Writes to the outbox inside the same transaction, so a notification exists only if the change was saved.
    private static async Task Notify(Tx tx, int reqId, IEnumerable<string> emails, string subject)
    {
        var text = subject.Length > 300 ? subject[..300] : subject;
        foreach (var e in emails.Distinct(StringComparer.OrdinalIgnoreCase))
            await tx.ExecAsync("INSERT INTO dbo.EmailLog (RequestId, ToAddress, Subject) VALUES (@r, @t, @s)",
                ("r", reqId), ("t", e), ("s", text));
    }

    private static Task Audit(Tx tx, int userId, string action, string detail) =>
        tx.ExecAsync("INSERT INTO dbo.AuditLog (UserId, Action, Detail) VALUES (@u, @a, @d)",
            ("u", userId), ("a", action), ("d", detail.Length > 2000 ? detail[..2000] : detail));
}
