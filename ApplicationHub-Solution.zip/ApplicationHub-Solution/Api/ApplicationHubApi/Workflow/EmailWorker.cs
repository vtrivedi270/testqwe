using ApplicationHub.Api.Data;
using ApplicationHub.Api.Mail;

namespace ApplicationHub.Api.Workflow;

/// Drains the EmailLog outbox every 10 seconds. A row is marked Sent only after the sender succeeds; failures are marked Failed.
public sealed class EmailWorker(IServiceProvider services, ILogger<EmailWorker> log) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stop)
    {
        while (!stop.IsCancellationRequested)
        {
            try
            {
                using var scope = services.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<Db>();
                var sender = scope.ServiceProvider.GetRequiredService<IMailSender>();
                var rows = await db.QueryAsync("SELECT TOP (20) Id, ToAddress, Subject FROM dbo.EmailLog WHERE Status = N'Queued' ORDER BY Id");
                foreach (var row in rows)
                {
                    var status = "Sent";
                    try { await sender.SendAsync((string)row["ToAddress"]!, (string)row["Subject"]!, stop); }
                    catch (Exception ex) when (!stop.IsCancellationRequested)
                    {
                        status = "Failed";
                        log.LogWarning(ex, "Email {Id} failed", row["Id"]);
                    }
                    await db.ExecAsync("UPDATE dbo.EmailLog SET Status = @s WHERE Id = @id", ("s", status), ("id", row["Id"]));
                }
            }
            catch (Exception ex) when (!stop.IsCancellationRequested)
            {
                log.LogError(ex, "Email worker iteration failed");
            }
            try { await Task.Delay(TimeSpan.FromSeconds(10), stop); }
            catch (OperationCanceledException) { }
        }
    }
}
