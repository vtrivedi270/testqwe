namespace ApplicationHub.Api.Workflow;

public sealed record StageDef(int Id, int Order, string Name, string Role, string Mode, string ActionType, string Kind, string Rule, List<int> Members);
public sealed record UserDef(int Id, string Role, string Name, string Email);
public sealed record ReqDef(int Id, int ApplicationId, int RequesterId, string RequesterName, string RequesterEmail,
    string Status, int Cycle, int CurrentStep, string Payload);

/// Everything the rules need, loaded once per operation inside a transaction.
public sealed class Ctx
{
    public required ReqDef Req { get; init; }
    public required List<StageDef> Stages { get; init; }
    public required List<List<StageDef>> Steps { get; init; }
    public required Dictionary<int, UserDef> Users { get; init; }
    /// Approve/Process rows in the current cycle. Principal = ActedFor when someone acted on another person's behalf.
    public required List<(int Stage, int Actor, int? For)> Approvals { get; init; }
    /// Active person-level delegations today (From delegates to To).
    public required List<(int From, int To)> Global { get; init; }
    /// Step-level delegations in the current cycle.
    public required List<(int Stage, int From, int To)> StepDel { get; init; }
}

/// Pure rules: no database access, so they can be unit-tested directly.
public static class Rules
{
    /// A step is one stage, or several stages marked Par that run together with the step above.
    public static List<List<StageDef>> Steps(IEnumerable<StageDef> stages)
    {
        var steps = new List<List<StageDef>>();
        foreach (var s in stages.OrderBy(x => x.Order))
        {
            if (s.Mode == "Par" && steps.Count > 0) steps[^1].Add(s);
            else steps.Add([s]);
        }
        return steps;
    }

    public static bool Accepts(StageDef s, UserDef u) =>
        s.Kind == "Group" ? s.Members.Contains(u.Id) : u.Role == s.Role;

    public static HashSet<int> Approvers(Ctx c, int stageId) =>
        c.Approvals.Where(a => a.Stage == stageId).Select(a => a.For ?? a.Actor).ToHashSet();

    /// Any one approval for a role stage or an Any group; every member for an All group.
    public static bool Satisfied(Ctx c, StageDef s)
    {
        var done = Approvers(c, s.Id);
        if (s.Kind == "Group" && s.Rule == "All")
        {
            var active = s.Members.Where(c.Users.ContainsKey).ToList();
            return active.Count > 0 && active.All(done.Contains);
        }
        return done.Count > 0;
    }

    public static bool DelegatedAway(Ctx c, int userId, int stageId) =>
        c.Global.Any(d => d.From == userId) || c.StepDel.Any(d => d.Stage == stageId && d.From == userId);

    /// Principals this user may act for on a stage. Includes the user (unless they delegated away) and anyone who delegated to them.
    public static List<int> Authorities(Ctx c, int userId, StageDef s)
    {
        var candidates = new HashSet<int> { userId };
        foreach (var d in c.Global) if (d.To == userId) candidates.Add(d.From);
        foreach (var d in c.StepDel) if (d.Stage == s.Id && d.To == userId) candidates.Add(d.From);
        var done = Approvers(c, s.Id);
        return candidates.Where(p =>
            c.Users.TryGetValue(p, out var pu) && Accepts(s, pu) && !done.Contains(p) &&
            (p != userId || !DelegatedAway(c, p, s.Id))).ToList();
    }

    public static List<(StageDef Stage, int Principal)> Actionable(Ctx c, int userId)
    {
        var result = new List<(StageDef Stage, int Principal)>();
        if (c.Req.Status != "In progress" || c.Req.CurrentStep >= c.Steps.Count) return result;
        foreach (var s in c.Steps[c.Req.CurrentStep])
        {
            if (Satisfied(c, s)) continue;
            var ps = Authorities(c, userId, s);
            if (ps.Count > 0) result.Add((s, ps.Contains(userId) ? userId : ps[0]));
        }
        return result;
    }

    public static bool StepDone(Ctx c) => c.Steps[c.Req.CurrentStep].All(s => Satisfied(c, s));

    public static IEnumerable<UserDef> Recipients(Ctx c, StageDef s) => c.Users.Values.Where(u => Accepts(s, u));
}
