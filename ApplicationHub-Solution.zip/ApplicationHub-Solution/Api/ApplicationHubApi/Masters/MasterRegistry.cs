using System.Text.Json;

namespace ApplicationHub.Api.Masters;

/// Describes one master table. Only the tables and columns listed here can be read or written through the API.
/// Column names never come from user input; values always go through parameters.
public sealed record MasterDef(string Table, string[] Columns, Dictionary<string, string> ForeignKeys);

public static class MasterRegistry
{
    public static readonly Dictionary<string, MasterDef> All = new(StringComparer.OrdinalIgnoreCase)
    {
        ["countries"]   = new("dbo.Countries", ["Name"], new()),
        ["states"]      = new("dbo.States", ["Name", "CountryId"], new() { ["CountryId"] = "countries" }),
        ["cities"]      = new("dbo.Cities", ["Name", "StateId"], new() { ["StateId"] = "states" }),
        ["divisions"]   = new("dbo.Divisions", ["Name"], new()),
        ["departments"] = new("dbo.Departments", ["Name", "DivisionId"], new() { ["DivisionId"] = "divisions" }),
        ["employees"]   = new("dbo.Employees", ["Name", "Email", "DepartmentId"], new() { ["DepartmentId"] = "departments" }),
        ["assets"]      = new("dbo.Assets", ["Name", "EmployeeId"], new() { ["EmployeeId"] = "employees" }),
        ["vendors"]     = new("dbo.Vendors", ["Name", "Contact"], new()),
        ["items"]       = new("dbo.StationeryItems", ["Name", "Price", "Stock"], new())
    };

    public static bool TryGet(string key, out MasterDef? def) => All.TryGetValue(key, out def);

    /// Converts a request body into column values. Throws ArgumentException with a readable message for bad input.
    public static Dictionary<string, object?> Values(MasterDef m, Dictionary<string, JsonElement> body, bool requireAll)
    {
        var input = new Dictionary<string, JsonElement>(body, StringComparer.OrdinalIgnoreCase);
        var result = new Dictionary<string, object?>();
        foreach (var col in m.Columns)
        {
            if (!input.TryGetValue(col, out var e))
            {
                if (requireAll && col == m.Columns[0]) throw new ArgumentException($"{col} is required.");
                continue;
            }
            result[col] = Convert(col, e, isRequired: col == m.Columns[0]);
        }
        if (result.Count == 0) throw new ArgumentException("No valid fields were provided.");
        return result;
    }

    private static object? Convert(string col, JsonElement e, bool isRequired)
    {
        if (e.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined)
        {
            if (isRequired) throw new ArgumentException($"{col} is required.");
            return null;
        }

        if (col.EndsWith("Id", StringComparison.Ordinal))
        {
            if (e.ValueKind == JsonValueKind.Number && e.TryGetInt32(out var id) && id > 0) return id;
            throw new ArgumentException($"{col} must be a valid id.");
        }
        if (col == "Price")
        {
            if (e.ValueKind == JsonValueKind.Number && e.TryGetDecimal(out var p) && p >= 0) return p;
            throw new ArgumentException("Price must be zero or more.");
        }
        if (col == "Stock")
        {
            if (e.ValueKind == JsonValueKind.Number && e.TryGetInt32(out var s) && s >= 0) return s;
            throw new ArgumentException("Stock must be zero or more.");
        }

        if (e.ValueKind != JsonValueKind.String) throw new ArgumentException($"{col} must be text.");
        var text = e.GetString()!.Trim();
        var max = col is "Email" or "Contact" ? 256 : 200;
        if (text.Length > max) throw new ArgumentException($"{col} must be {max} characters or fewer.");
        if (isRequired && text.Length == 0) throw new ArgumentException($"{col} is required.");
        return text.Length == 0 ? null : text;
    }
}
