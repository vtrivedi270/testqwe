using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;

namespace ApplicationHub.Api.Mail;

public interface IMailSender
{
    Task SendAsync(string to, string subject, CancellationToken ct);
}

/// Sends through SMTP with STARTTLS. If Smtp:Host is empty, messages are only logged (useful for local development).
/// The SMTP password is read from an environment variable named in Smtp:PasswordEnvVar, never from appsettings.
public sealed class SmtpMailSender(IConfiguration cfg, ILogger<SmtpMailSender> log) : IMailSender
{
    public async Task SendAsync(string to, string subject, CancellationToken ct)
    {
        var host = cfg["Smtp:Host"];
        if (string.IsNullOrWhiteSpace(host))
        {
            log.LogInformation("Mail (log-only mode) to {To}: {Subject}", to, subject);
            return;
        }

        var msg = new MimeMessage();
        msg.From.Add(MailboxAddress.Parse(cfg["Smtp:From"]!));
        msg.To.Add(MailboxAddress.Parse(to));
        msg.Subject = subject;
        msg.Body = new TextPart("plain") { Text = $"{subject}\n\nOpen Application Hub to view the details." };

        using var client = new SmtpClient();
        client.Timeout = 20_000;
        await client.ConnectAsync(host, int.Parse(cfg["Smtp:Port"] ?? "587"), SecureSocketOptions.StartTls, ct);
        var user = cfg["Smtp:User"];
        if (!string.IsNullOrEmpty(user))
            await client.AuthenticateAsync(user, Environment.GetEnvironmentVariable(cfg["Smtp:PasswordEnvVar"] ?? "SMTP_PASSWORD"), ct);
        await client.SendAsync(msg, ct);
        await client.DisconnectAsync(true, ct);
    }
}
