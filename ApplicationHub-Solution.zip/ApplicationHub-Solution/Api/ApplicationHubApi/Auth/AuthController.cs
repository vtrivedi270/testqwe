using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using ApplicationHub.Api.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace ApplicationHub.Api.Auth;

[ApiController]
[Route("api/auth")]
public sealed class AuthController(Db db, TokenService tokens, JwtOptions jwt) : ControllerBase
{
    private const string RefreshCookie = "rt";

    public sealed record LoginDto(
        [Required, EmailAddress, MaxLength(256)] string Email,
        [Required, MaxLength(256)] string Password);

    [AllowAnonymous]
    [EnableRateLimiting("login")]
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginDto dto)
    {
        if (!ModelState.IsValid) return BadRequest(new { error = "Email and password are required." });

        var invalid = new { error = "Invalid email or password." };
        var rows = await db.QueryAsync(
            "SELECT Id, Email, DisplayName, PasswordHash, Role, IsActive, LockedUntil FROM dbo.Users WHERE Email = @e",
            ("e", dto.Email.Trim().ToLowerInvariant()));

        if (rows.Count == 0)
        {
            // Do similar work as a real check so timing does not reveal which emails exist.
            BCrypt.Net.BCrypt.Verify(dto.Password, "$2a$12$CwTycUXWue0Thq9StjUM0uJ8f5Z8Y0nG8KqJ7a7Qe9E5v1oQ0GQe2");
            return Unauthorized(invalid);
        }

        var u = rows[0];
        var id = (int)u["Id"]!;

        if (!(bool)u["IsActive"]!) return Unauthorized(invalid);
        if (u["LockedUntil"] is DateTime until && until > DateTime.UtcNow)
            return StatusCode(StatusCodes.Status423Locked, new { error = "Account is temporarily locked. Try again later." });

        if (!BCrypt.Net.BCrypt.Verify(dto.Password, (string)u["PasswordHash"]!))
        {
            await db.ExecAsync(
                @"UPDATE dbo.Users
                  SET FailedLogins = FailedLogins + 1,
                      LockedUntil = CASE WHEN FailedLogins + 1 >= 5 THEN DATEADD(MINUTE, 15, SYSUTCDATETIME()) ELSE LockedUntil END
                  WHERE Id = @id", ("id", id));
            return Unauthorized(invalid);
        }

        await db.ExecAsync("UPDATE dbo.Users SET FailedLogins = 0, LockedUntil = NULL WHERE Id = @id", ("id", id));
        await db.ExecAsync("INSERT INTO dbo.AuditLog (UserId, Action) VALUES (@id, N'LOGIN')", ("id", id));
        return await IssueAsync(id, (string)u["Email"]!, (string)u["DisplayName"]!, (string)u["Role"]!);
    }

    [AllowAnonymous]
    [HttpPost("refresh")]
    public async Task<IActionResult> Refresh()
    {
        if (!Request.Cookies.TryGetValue(RefreshCookie, out var raw) || string.IsNullOrEmpty(raw))
            return Unauthorized(new { error = "Session expired." });

        var rows = await db.QueryAsync(
            @"SELECT r.Id, u.Id AS UserId, u.Email, u.DisplayName, u.Role, u.IsActive
              FROM dbo.RefreshTokens r JOIN dbo.Users u ON u.Id = r.UserId
              WHERE r.TokenHash = @h AND r.RevokedAt IS NULL AND r.ExpiresAt > SYSUTCDATETIME()",
            ("h", TokenService.Hash(raw)));

        if (rows.Count == 0 || !(bool)rows[0]["IsActive"]!)
        {
            ClearRefreshCookie();
            return Unauthorized(new { error = "Session expired." });
        }

        // Rotation: the used refresh token can never be used again.
        var r = rows[0];
        await db.ExecAsync("UPDATE dbo.RefreshTokens SET RevokedAt = SYSUTCDATETIME() WHERE Id = @id", ("id", r["Id"]));
        return await IssueAsync((int)r["UserId"]!, (string)r["Email"]!, (string)r["DisplayName"]!, (string)r["Role"]!);
    }

    [AllowAnonymous]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        if (Request.Cookies.TryGetValue(RefreshCookie, out var raw) && !string.IsNullOrEmpty(raw))
            await db.ExecAsync("UPDATE dbo.RefreshTokens SET RevokedAt = SYSUTCDATETIME() WHERE TokenHash = @h", ("h", TokenService.Hash(raw)));
        ClearRefreshCookie();
        return NoContent();
    }

    [HttpGet("me")]
    public IActionResult Me() => Ok(new
    {
        id = User.FindFirstValue(ClaimTypes.NameIdentifier),
        email = User.FindFirstValue(ClaimTypes.Email),
        name = User.FindFirstValue("name"),
        role = User.FindFirstValue(ClaimTypes.Role)
    });

    private async Task<IActionResult> IssueAsync(int id, string email, string name, string role)
    {
        var (access, seconds) = tokens.CreateAccessToken(id, email, name, role);
        var refresh = TokenService.NewRefreshToken();
        await db.ExecAsync(
            "INSERT INTO dbo.RefreshTokens (UserId, TokenHash, ExpiresAt) VALUES (@u, @h, DATEADD(DAY, @d, SYSUTCDATETIME()))",
            ("u", id), ("h", TokenService.Hash(refresh)), ("d", jwt.RefreshDays));

        Response.Cookies.Append(RefreshCookie, refresh, new CookieOptions
        {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.Strict,
            Path = "/api/auth",
            Expires = DateTimeOffset.UtcNow.AddDays(jwt.RefreshDays)
        });

        return Ok(new { accessToken = access, expiresIn = seconds, user = new { id, email, name, role } });
    }

    private void ClearRefreshCookie() =>
        Response.Cookies.Delete(RefreshCookie, new CookieOptions { Path = "/api/auth", Secure = true, SameSite = SameSiteMode.Strict });
}
