using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using System.Text.Json;
using ApplicationHub.Api.Data;
using ApplicationHub.Api.Forms;
using ApplicationHub.Api.Workflow;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/requests")]
public sealed class RequestsController(Db db, WorkflowService wf, FormValidator forms) : ControllerBase
{
    public sealed record CreateDto([Range(1, int.MaxValue)] int ApplicationId, [Required] string PayloadJson, bool Submit, List<int>? AttachmentIds = null);
    public sealed record CommentDto([MaxLength(1000)] string? Comment);
    public sealed record ReasonDto([Required, MaxLength(1000)] string Comment);
    public sealed record ResubmitDto([Required] string PayloadJson, List<int>? AttachmentIds = null);
    public sealed record DelegateDto([Range(1, int.MaxValue)] int StageId, [Range(1, int.MaxValue)] int ToUserId);

    private int Me => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
    private string MyRole => User.FindFirstValue(ClaimTypes.Role) ?? "";

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateDto dto)
    {
        if (!ValidJson(dto.PayloadJson)) return BadRequest(new { error = "PayloadJson must be valid JSON under 200 KB." });
        if ((dto.AttachmentIds?.Count ?? 0) > 20) return BadRequest(new { error = "Attach up to 20 files per request." });
        var published = await db.QueryAsync("SELECT Id FROM dbo.Applications WHERE Id = @a AND Status = N'Published'", ("a", dto.ApplicationId));
        if (published.Count == 0) return NotFound(new { error = "Application not found." });
        var me = Me;
        var check = await forms.ValidateAsync(dto.ApplicationId, dto.PayloadJson, me, null, dto.Submit);
        if (!check.Ok) return BadRequest(new { error = "Please correct the highlighted fields.", fieldErrors = check.Errors });
        return await Run(async tx => (object?)new { id = await wf.CreateAsync(tx, dto.ApplicationId, me, check.SanitizedJson, dto.Submit, check.AttachmentIds) });
    }

    [HttpPost("{id:int}/approve")]
    public Task<IActionResult> Approve(int id, [FromBody] CommentDto? dto) =>
        Run(async tx => { await wf.ApproveAsync(tx, id, Me, dto?.Comment); return null; });

    [HttpPost("{id:int}/reject")]
    public Task<IActionResult> Reject(int id, [FromBody] ReasonDto dto) =>
        Run(async tx => { await wf.RejectAsync(tx, id, Me, dto.Comment); return null; });

    [HttpPost("{id:int}/amend")]
    public Task<IActionResult> Amend(int id, [FromBody] ReasonDto dto) =>
        Run(async tx => { await wf.AmendAsync(tx, id, Me, dto.Comment); return null; });

    [HttpPost("{id:int}/delegate")]
    public Task<IActionResult> Delegate(int id, [FromBody] DelegateDto dto) =>
        Run(async tx => { await wf.DelegateStepAsync(tx, id, Me, dto.StageId, dto.ToUserId); return null; });

    [HttpPost("{id:int}/resubmit")]
    public async Task<IActionResult> Resubmit(int id, [FromBody] ResubmitDto dto)
    {
        if (!ValidJson(dto.PayloadJson)) return BadRequest(new { error = "PayloadJson must be valid JSON under 200 KB." });
        var rows = await db.QueryAsync("SELECT ApplicationId, RequesterId FROM dbo.Requests WHERE Id = @id", ("id", id));
        if (rows.Count == 0) return NotFound();
        var me = Me;
        if (Convert.ToInt32(rows[0]["RequesterId"]) != me) return StatusCode(403, new { error = "Only the requester can resubmit." });
        var check = await forms.ValidateAsync(Convert.ToInt32(rows[0]["ApplicationId"]), dto.PayloadJson, me, id, true);
        if (!check.Ok) return BadRequest(new { error = "Please correct the highlighted fields.", fieldErrors = check.Errors });
        return await Run(async tx => { await wf.ResubmitAsync(tx, id, me, check.SanitizedJson, check.AttachmentIds); return null; });
    }

    [HttpPost("{id:int}/pullback")]
    public Task<IActionResult> PullBack(int id) =>
        Run(async tx => { await wf.PullBackAsync(tx, id, Me); return null; });

    [HttpPost("{id:int}/cancel")]
    public Task<IActionResult> Cancel(int id) =>
        Run(async tx => { await wf.CancelAsync(tx, id, Me, MyRole); return null; });

    [HttpGet("mine")]
    public async Task<IActionResult> Mine() => Ok(await db.QueryAsync(
        @"SELECT r.Id, a.Name AS Application, r.Status, r.CurrentStep, r.Cycle, r.CreatedAt
          FROM dbo.Requests r JOIN dbo.Applications a ON a.Id = r.ApplicationId
          WHERE r.RequesterId = @u ORDER BY r.CreatedAt DESC", ("u", Me)));

    [HttpGet("inbox")]
    public async Task<IActionResult> Inbox()
    {
        var me = Me;
        var open = await db.QueryAsync(
            @"SELECT TOP (200) r.Id, a.Name AS Application, u.DisplayName AS Requester, r.CreatedAt
              FROM dbo.Requests r JOIN dbo.Applications a ON a.Id = r.ApplicationId JOIN dbo.Users u ON u.Id = r.RequesterId
              WHERE r.Status = N'In progress' ORDER BY r.CreatedAt DESC");
        var result = new List<object>();
        foreach (var row in open)
        {
            var id = Convert.ToInt32(row["Id"]);
            var ctx = await db.InTransactionAsync(tx => wf.LoadAsync(tx, id, false));
            var acts = Rules.Actionable(ctx, me);
            if (acts.Count > 0)
                result.Add(new { id, application = row["Application"], requester = row["Requester"], createdAt = row["CreatedAt"], stages = acts.Select(a => a.Stage.Name) });
        }
        return Ok(result);
    }

    [HttpGet("approved")]
    public async Task<IActionResult> Approved() => Ok(await db.QueryAsync(
        @"SELECT r.Id, a.Name AS Application, r.Status, MAX(ap.ActedAt) AS LastActedAt
          FROM dbo.Approvals ap JOIN dbo.Requests r ON r.Id = ap.RequestId JOIN dbo.Applications a ON a.Id = r.ApplicationId
          WHERE (ap.ActorId = @me OR ap.ActedForId = @me) AND ap.Action IN (N'Approve', N'Process')
          GROUP BY r.Id, a.Name, r.Status ORDER BY LastActedAt DESC", ("me", Me)));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Detail(int id)
    {
        var me = Me;
        var role = MyRole;
        var result = await db.InTransactionAsync<object?>(async tx =>
        {
            var c = await wf.LoadAsync(tx, id, false);
            var involved = c.Req.RequesterId == me || role == "Admin" ||
                           (c.Users.TryGetValue(me, out var meUser) && c.Steps.SelectMany(s => s).Any(s => Rules.Accepts(s, meUser)));
            if (!involved) return null;

            var approvals = await tx.QueryAsync(
                @"SELECT ap.StageId, ap.Action, ap.Comment, ap.ActedAt, a.DisplayName AS Actor, f.DisplayName AS ActedFor
                  FROM dbo.Approvals ap JOIN dbo.Users a ON a.Id = ap.ActorId LEFT JOIN dbo.Users f ON f.Id = ap.ActedForId
                  WHERE ap.RequestId = @r AND ap.Cycle = @c ORDER BY ap.ActedAt", ("r", id), ("c", c.Req.Cycle));
            var meta = await tx.QueryAsync(
                "SELECT a.Name AS AppName, a.FormJson, r.AmendNote FROM dbo.Requests r JOIN dbo.Applications a ON a.Id = r.ApplicationId WHERE r.Id = @r",
                ("r", id));

            return new
            {
                id = c.Req.Id,
                status = c.Req.Status,
                cycle = c.Req.Cycle,
                currentStep = c.Req.CurrentStep,
                requester = c.Req.RequesterName,
                application = meta[0]["AppName"],
                form = JsonSerializer.Deserialize<JsonElement>((string)meta[0]["FormJson"]!),
                values = JsonSerializer.Deserialize<JsonElement>(c.Req.Payload),
                amendNote = meta[0]["AmendNote"],
                steps = c.Steps.Select((st, i) => new
                {
                    index = i,
                    stages = st.Select(s => new
                    {
                        s.Id, s.Name, s.Kind, s.Rule,
                        members = s.Members.Select(m => c.Users.TryGetValue(m, out var u) ? u.Name : "")
                    })
                }),
                actions = Rules.Actionable(c, me).Select(a => new { stageId = a.Stage.Id, stage = a.Stage.Name }),
                approvals,
                canEdit = c.Req.RequesterId == me && (c.Req.Status == "Draft" || c.Req.Status == "Amend requested"),
                canPullBack = c.Req.RequesterId == me && c.Req.Status == "In progress" && c.Approvals.Count == 0
            };
        });
        return result is null ? NotFound() : Ok(result);
    }

    private async Task<IActionResult> Run(Func<Tx, Task<object?>> work)
    {
        try
        {
            var result = await db.InTransactionAsync(work);
            return result is null ? NoContent() : Ok(result);
        }
        catch (WorkflowException ex)
        {
            return StatusCode(ex.Status, new { error = ex.Message });
        }
    }

    private static bool ValidJson(string s)
    {
        if (s.Length > 200_000) return false;
        try { using var _ = JsonDocument.Parse(s); return true; }
        catch (JsonException) { return false; }
    }
}
