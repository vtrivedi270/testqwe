using System.Security.Claims;
using ApplicationHub.Api.Data;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/emails")]
public sealed class EmailsController(Db db) : ControllerBase
{
    /// Admins see the whole log. Everyone else sees only mail addressed to them.
    [HttpGet]
    public async Task<IActionResult> List()
    {
        var isAdmin = User.IsInRole("Admin");
        var email = User.FindFirstValue(ClaimTypes.Email) ?? "";
        var rows = isAdmin
            ? await db.QueryAsync("SELECT TOP (200) Id, RequestId, ToAddress, Subject, Status, CreatedAt FROM dbo.EmailLog ORDER BY Id DESC")
            : await db.QueryAsync("SELECT TOP (200) Id, RequestId, ToAddress, Subject, Status, CreatedAt FROM dbo.EmailLog WHERE ToAddress = @e ORDER BY Id DESC", ("e", email));
        return Ok(rows);
    }
}
