using ApplicationHub.Api.Data;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/users")]
public sealed class UsersController(Db db) : ControllerBase
{
    /// Names and roles only, for pickers (delegation, workflow groups). Emails are not exposed.
    [HttpGet("directory")]
    public async Task<IActionResult> Directory() => Ok(await db.QueryAsync(
        "SELECT Id, DisplayName AS Name, Role FROM dbo.Users WHERE IsActive = 1 ORDER BY DisplayName"));
}
