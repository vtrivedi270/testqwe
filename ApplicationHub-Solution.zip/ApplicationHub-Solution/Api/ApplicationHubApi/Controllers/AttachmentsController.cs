using System.Security.Claims;
using System.Security.Cryptography;
using ApplicationHub.Api.Data;
using ApplicationHub.Api.Workflow;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

/// Uploads are stored in the database with type, size and content checks. Only people involved in a request can download its files.
[ApiController]
[Route("api/attachments")]
public sealed class AttachmentsController(Db db, WorkflowService wf) : ControllerBase
{
    private const long MaxBytes = 10L * 1024 * 1024;
    private static readonly string[] Allowed = [".pdf", ".png", ".jpg", ".jpeg", ".xlsx", ".docx"];

    private int Me => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
    private string MyRole => User.FindFirstValue(ClaimTypes.Role) ?? "";

    [HttpPost]
    [RequestSizeLimit(11L * 1024 * 1024)]
    public async Task<IActionResult> Upload([FromForm] IFormFile? file)
    {
        if (file is null || file.Length == 0) return BadRequest(new { error = "No file received." });
        if (file.Length > MaxBytes) return BadRequest(new { error = "Each file must be 10 MB or smaller." });

        var name = Path.GetFileName(file.FileName);
        var ext = Path.GetExtension(name).ToLowerInvariant();
        if (string.IsNullOrWhiteSpace(name) || name.Length > 255 || !Allowed.Contains(ext))
            return BadRequest(new { error = "This file type is not allowed." });

        byte[] data;
        await using (var ms = new MemoryStream())
        {
            await file.CopyToAsync(ms);
            data = ms.ToArray();
        }
        if (!SignatureOk(ext, data)) return BadRequest(new { error = "The file content does not match its extension." });

        var sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
        var id = await db.ScalarIntAsync(
            "INSERT INTO dbo.Attachments (FileName, ContentType, SizeBytes, Sha256, Content, UploadedBy) OUTPUT INSERTED.Id VALUES (@n, @t, @s, @h, @c, @u)",
            ("n", name), ("t", ContentTypeFor(ext)), ("s", data.Length), ("h", sha), ("c", data), ("u", Me));
        return Ok(new { id, name, size = data.Length });
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Download(int id)
    {
        var rows = await db.QueryAsync("SELECT RequestId, UploadedBy, FileName, ContentType, Content FROM dbo.Attachments WHERE Id = @id", ("id", id));
        if (rows.Count == 0) return NotFound();
        var r = rows[0];

        var uploader = Convert.ToInt32(r["UploadedBy"]);
        var reqId = r["RequestId"] is null ? (int?)null : Convert.ToInt32(r["RequestId"]);
        var allowed = uploader == Me || MyRole == "Admin" || (reqId is int rid && await wf.CanView(db, rid, Me, MyRole));
        if (!allowed) return NotFound(); // same answer whether or not the file exists

        Response.Headers["Content-Disposition"] = $"attachment; filename*=UTF-8''{Uri.EscapeDataString((string)r["FileName"]!)}";
        return File((byte[])r["Content"]!, (string)r["ContentType"]!);
    }

    private static bool SignatureOk(string ext, byte[] d) => ext switch
    {
        ".pdf" => d.Length > 4 && d[0] == 0x25 && d[1] == 0x50 && d[2] == 0x44 && d[3] == 0x46,
        ".png" => d.Length > 4 && d[0] == 0x89 && d[1] == 0x50 && d[2] == 0x4E && d[3] == 0x47,
        ".jpg" or ".jpeg" => d.Length > 3 && d[0] == 0xFF && d[1] == 0xD8 && d[2] == 0xFF,
        _ => d.Length > 4 && d[0] == 0x50 && d[1] == 0x4B && d[2] == 0x03 && d[3] == 0x04 // xlsx and docx are zip files
    };

    private static string ContentTypeFor(string ext) => ext switch
    {
        ".pdf" => "application/pdf",
        ".png" => "image/png",
        ".jpg" or ".jpeg" => "image/jpeg",
        ".xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        _ => "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    };
}
