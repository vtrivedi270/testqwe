using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using ApplicationHub.Api.Data;
using ApplicationHub.Api.Workflow;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/admin/users")]
[Authorize(Roles = "Admin")]
public sealed class AdminUsersController(Db db) : ControllerBase
{
    public sealed record CreateUserDto(
        [Required, EmailAddress, MaxLength(256)] string Email,
        [Required, MaxLength(200)] string DisplayName,
        [Required] string Role,
        [Required, MinLength(12), MaxLength(256)] string Password);

    public sealed record UpdateUserDto([MaxLength(200)] string? DisplayName, string? Role, bool? IsActive);

    public sealed record PasswordDto([Required, MinLength(12), MaxLength(256)] string Password);

    private int Me => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet]
    public async Task<IActionResult> List() => Ok(await db.QueryAsync(
        "SELECT Id, Email, DisplayName, Role, IsActive, LockedUntil, CreatedAt FROM dbo.Users ORDER BY DisplayName"));

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateUserDto dto)
    {
        if (!WorkflowService.Roles.Contains(dto.Role)) return BadRequest(new { error = "Unknown role." });
        var email = dto.Email.Trim().ToLowerInvariant();
        if (await db.QueryAsync("SELECT 1 AS x FROM dbo.Users WHERE Email = @e", ("e", email)) is { Count: > 0 })
            return Conflict(new { error = "A user with this email already exists." });

        var id = await db.ScalarIntAsync(
            "INSERT INTO dbo.Users (Email, DisplayName, PasswordHash, Role) OUTPUT INSERTED.Id VALUES (@e, @n, @h, @r)",
            ("e", email), ("n", dto.DisplayName.Trim()), ("h", Hash(dto.Password)), ("r", dto.Role));
        await Audit("USER_CREATE", $"User {id} created with role {dto.Role}");
        return CreatedAtAction(nameof(List), new { id }, new { id });
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateUserDto dto)
    {
        if (dto.Role is not null && !WorkflowService.Roles.Contains(dto.Role)) return BadRequest(new { error = "Unknown role." });
        if (id == Me && (dto.IsActive == false || (dto.Role is not null && dto.Role != "Admin")))
            return BadRequest(new { error = "You cannot deactivate yourself or remove your own Admin role." });

        var n = await db.ExecAsync(
            "UPDATE dbo.Users SET DisplayName = COALESCE(@n, DisplayName), Role = COALESCE(@r, Role), IsActive = COALESCE(@a, IsActive) WHERE Id = @id",
            ("n", dto.DisplayName?.Trim()), ("r", dto.Role), ("a", dto.IsActive), ("id", id));
        if (n == 0) return NotFound();

        // A role change or deactivation ends existing sessions so the new rights apply immediately.
        if (dto.IsActive == false || dto.Role is not null) await RevokeSessions(id);
        await Audit("USER_UPDATE", $"User {id}");
        return NoContent();
    }

    [HttpPost("{id:int}/reset-password")]
    public async Task<IActionResult> ResetPassword(int id, [FromBody] PasswordDto dto)
    {
        var n = await db.ExecAsync(
            "UPDATE dbo.Users SET PasswordHash = @h, FailedLogins = 0, LockedUntil = NULL WHERE Id = @id",
            ("h", Hash(dto.Password)), ("id", id));
        if (n == 0) return NotFound();
        await RevokeSessions(id);
        await Audit("PASSWORD_RESET", $"User {id}");
        return NoContent();
    }

    private Task RevokeSessions(int userId) =>
        db.ExecAsync("UPDATE dbo.RefreshTokens SET RevokedAt = SYSUTCDATETIME() WHERE UserId = @u AND RevokedAt IS NULL", ("u", userId));

    private Task Audit(string action, string detail) =>
        db.ExecAsync("INSERT INTO dbo.AuditLog (UserId, Action, Detail) VALUES (@u, @a, @d)", ("u", Me), ("a", action), ("d", detail));

    private static string Hash(string password) => BCrypt.Net.BCrypt.HashPassword(password, workFactor: 12);
}
