using ApplicationHub.Api.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/admin/applications")]
[Authorize(Roles = "Admin")]
public sealed class AdminController(Db db) : ControllerBase
{
    /// All applications, including drafts, for the admin studio.
    [HttpGet]
    public async Task<IActionResult> List() => Ok(await db.QueryAsync(
        @"SELECT a.Id, a.Name, a.Description, a.Status, a.CreatedAt,
                 (SELECT COUNT(*) FROM dbo.WorkflowStages s WHERE s.ApplicationId = a.Id) AS StageCount
          FROM dbo.Applications a ORDER BY a.Id DESC"));

    /// The saved workflow in the same shape the save endpoint accepts, so the editor can load and resave it.
    [HttpGet("{id:int}/workflow")]
    public async Task<IActionResult> Workflow(int id)
    {
        var app = await db.QueryAsync("SELECT Id FROM dbo.Applications WHERE Id = @id", ("id", id));
        if (app.Count == 0) return NotFound();

        var stages = await db.QueryAsync(
            "SELECT Id, StepOrder, Name, Role, Mode, ActionType, Kind, Rule FROM dbo.WorkflowStages WHERE ApplicationId = @id ORDER BY StepOrder",
            ("id", id));
        var members = await db.QueryAsync(
            "SELECT sm.StageId, sm.UserId FROM dbo.StageMembers sm JOIN dbo.WorkflowStages s ON s.Id = sm.StageId WHERE s.ApplicationId = @id",
            ("id", id));

        return Ok(stages.Select(s =>
        {
            var sid = Convert.ToInt32(s["Id"]);
            var isRole = (string)s["Kind"]! == "Role";
            return new
            {
                name = s["Name"],
                mode = s["Mode"],
                kind = s["Kind"],
                role = isRole ? s["Role"] : null,
                rule = s["Rule"],
                actionType = s["ActionType"],
                members = members.Where(m => Convert.ToInt32(m["StageId"]) == sid).Select(m => Convert.ToInt32(m["UserId"])).ToList()
            };
        }));
    }
}
