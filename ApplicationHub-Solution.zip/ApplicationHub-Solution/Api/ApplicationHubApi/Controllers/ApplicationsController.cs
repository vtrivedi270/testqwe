using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using System.Text.Json;
using ApplicationHub.Api.Data;
using ApplicationHub.Api.Workflow;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/applications")]
public sealed class ApplicationsController(Db db) : ControllerBase
{
    public sealed record AppDto([Required, MaxLength(200)] string Name, [MaxLength(1000)] string? Description, [Required] string FormJson);
    public sealed record StageDto(
        [Required, MaxLength(200)] string Name,
        [Required] string Mode,          // Seq | Par
        [Required] string Kind,          // Role | Group
        string? Role,                    // when Kind = Role
        [Required] string Rule,          // Any | All (groups)
        [Required] string ActionType,    // Approve | Process
        List<int>? Members);             // when Kind = Group

    [HttpGet]
    public async Task<IActionResult> List() =>
        Ok(await db.QueryAsync("SELECT Id, Name, Description FROM dbo.Applications WHERE Status = N'Published' ORDER BY Name"));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var rows = await db.QueryAsync("SELECT Id, Name, Description, FormJson FROM dbo.Applications WHERE Id = @id AND Status = N'Published'", ("id", id));
        return rows.Count == 0 ? NotFound() : Ok(rows[0]);
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Create([FromBody] AppDto dto)
    {
        if (dto.FormJson.Length > 100_000 || !IsJson(dto.FormJson)) return BadRequest(new { error = "FormJson must be valid JSON under 100 KB." });
        var uid = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var id = await db.ScalarIntAsync(
            "INSERT INTO dbo.Applications (Name, Description, FormJson, CreatedBy) OUTPUT INSERTED.Id VALUES (@n, @d, @f, @u)",
            ("n", dto.Name), ("d", dto.Description), ("f", dto.FormJson), ("u", uid));
        await db.ExecAsync("INSERT INTO dbo.AuditLog (UserId, Action, Detail) VALUES (@u, N'APP_CREATE', @d)", ("u", uid), ("d", dto.Name));
        return CreatedAtAction(nameof(Get), new { id }, new { id });
    }

    [HttpPost("{id:int}/publish")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Publish(int id)
    {
        var n = await db.ExecAsync("UPDATE dbo.Applications SET Status = N'Published' WHERE Id = @id", ("id", id));
        return n == 0 ? NotFound() : NoContent();
    }

    /// Replaces the approval workflow. Locked once the application has requests, so running requests keep their rules.
    [HttpPut("{id:int}/workflow")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> SaveWorkflow(int id, [FromBody] List<StageDto> stages)
    {
        if (stages.Count == 0 || stages.Count > 20) return BadRequest(new { error = "A workflow needs 1 to 20 stages." });
        foreach (var s in stages)
        {
            if (s.Mode is not ("Seq" or "Par") || s.Kind is not ("Role" or "Group") ||
                s.Rule is not ("Any" or "All") || s.ActionType is not ("Approve" or "Process"))
                return BadRequest(new { error = "Invalid stage setting." });
            if (s.Kind == "Role" && (s.Role is null || !WorkflowService.Roles.Contains(s.Role)))
                return BadRequest(new { error = $"Stage '{s.Name}' needs a valid role." });
            if (s.Kind == "Group" && (s.Members is null || s.Members.Count == 0))
                return BadRequest(new { error = $"Group stage '{s.Name}' needs at least one member." });
        }

        try
        {
            await db.InTransactionAsync<int>(async tx =>
            {
                var app = await tx.QueryAsync("SELECT Id FROM dbo.Applications WHERE Id = @id", ("id", id));
                if (app.Count == 0) throw new WorkflowException("Application not found.", StatusCodes.Status404NotFound);
                if (await tx.ScalarIntAsync("SELECT COUNT(*) FROM dbo.Requests WHERE ApplicationId = @id", ("id", id)) > 0)
                    throw new WorkflowException("This application already has requests, so its workflow is locked. Create a new application version instead.", StatusCodes.Status409Conflict);

                await tx.ExecAsync("DELETE FROM dbo.StageMembers WHERE StageId IN (SELECT Id FROM dbo.WorkflowStages WHERE ApplicationId = @id)", ("id", id));
                await tx.ExecAsync("DELETE FROM dbo.WorkflowStages WHERE ApplicationId = @id", ("id", id));

                var order = 0;
                foreach (var s in stages)
                {
                    order++;
                    var sid = await tx.ScalarIntAsync(
                        "INSERT INTO dbo.WorkflowStages (ApplicationId, StepOrder, Name, Role, Mode, ActionType, Kind, Rule) OUTPUT INSERTED.Id VALUES (@a, @o, @n, @r, @m, @t, @k, @ru)",
                        ("a", id), ("o", order), ("n", s.Name), ("r", s.Kind == "Role" ? s.Role : "-"),
                        ("m", s.Mode), ("t", s.ActionType), ("k", s.Kind), ("ru", s.Rule));
                    if (s.Kind == "Group")
                        foreach (var m in s.Members!.Distinct())
                            await tx.ExecAsync("INSERT INTO dbo.StageMembers (StageId, UserId) SELECT @s, Id FROM dbo.Users WHERE Id = @u AND IsActive = 1",
                                ("s", sid), ("u", m));
                }
                return 0;
            });
        }
        catch (WorkflowException ex)
        {
            return StatusCode(ex.Status, new { error = ex.Message });
        }
        return NoContent();
    }

    private static bool IsJson(string json)
    {
        try { using var _ = JsonDocument.Parse(json); return true; }
        catch (JsonException) { return false; }
    }
}
