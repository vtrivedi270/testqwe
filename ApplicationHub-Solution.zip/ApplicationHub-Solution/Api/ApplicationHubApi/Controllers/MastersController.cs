using System.Text.Json;
using ApplicationHub.Api.Data;
using ApplicationHub.Api.Masters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/masters")]
public sealed class MastersController(Db db) : ControllerBase
{
    /// Any signed-in user can read active master records (needed for lookups). Admins can include inactive ones.
    [HttpGet("{key}")]
    public async Task<IActionResult> List(string key, bool includeInactive = false)
    {
        if (!MasterRegistry.TryGet(key, out var m) || m is null) return NotFound();
        var where = includeInactive && User.IsInRole("Admin") ? "" : " WHERE IsActive = 1";
        var sql = $"SELECT Id, {string.Join(", ", m.Columns)}, IsActive FROM {m.Table}{where} ORDER BY Id";
        return Ok(await db.QueryAsync(sql));
    }

    [HttpPost("{key}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Create(string key, [FromBody] Dictionary<string, JsonElement> body)
    {
        if (!MasterRegistry.TryGet(key, out var m) || m is null) return NotFound();
        try
        {
            var values = MasterRegistry.Values(m, body, requireAll: true);
            var cols = string.Join(", ", values.Keys);
            var pars = string.Join(", ", values.Keys.Select(k => "@" + k));
            var id = await db.ScalarIntAsync($"INSERT INTO {m.Table} ({cols}) OUTPUT INSERTED.Id VALUES ({pars})",
                values.Select(kv => (kv.Key, kv.Value)).ToArray());
            return CreatedAtAction(nameof(List), new { key }, new { id });
        }
        catch (ArgumentException ex) { return BadRequest(new { error = ex.Message }); }
        catch (SqlException ex) when (ex.Number == 547)
        {
            return BadRequest(new { error = "A linked record does not exist or is inactive." });
        }
    }

    [HttpPut("{key}/{id:int}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Update(string key, int id, [FromBody] Dictionary<string, JsonElement> body)
    {
        if (!MasterRegistry.TryGet(key, out var m) || m is null) return NotFound();
        try
        {
            var values = MasterRegistry.Values(m, body, requireAll: false);
            var set = string.Join(", ", values.Keys.Select(k => $"{k} = @{k}"));
            var ps = values.Select(kv => (kv.Key, kv.Value)).ToList();
            ps.Add(("id", id));
            var n = await db.ExecAsync($"UPDATE {m.Table} SET {set} WHERE Id = @id", ps.ToArray());
            return n == 0 ? NotFound() : NoContent();
        }
        catch (ArgumentException ex) { return BadRequest(new { error = ex.Message }); }
        catch (SqlException ex) when (ex.Number == 547)
        {
            return BadRequest(new { error = "A linked record does not exist or is inactive." });
        }
    }

    /// Records are deactivated, not deleted, so existing requests and references keep working.
    [HttpDelete("{key}/{id:int}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Deactivate(string key, int id)
    {
        if (!MasterRegistry.TryGet(key, out var m) || m is null) return NotFound();
        var n = await db.ExecAsync($"UPDATE {m.Table} SET IsActive = 0 WHERE Id = @id", ("id", id));
        return n == 0 ? NotFound() : NoContent();
    }
}
