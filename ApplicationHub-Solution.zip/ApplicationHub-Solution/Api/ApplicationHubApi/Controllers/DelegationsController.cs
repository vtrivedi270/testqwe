using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using ApplicationHub.Api.Data;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/delegations")]
public sealed class DelegationsController(Db db) : ControllerBase
{
    public sealed record DelegationDto([Range(1, int.MaxValue)] int ToUserId, [Required] DateOnly StartsOn, DateOnly? EndsOn);

    private int Me => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet("mine")]
    public async Task<IActionResult> Mine() => Ok(await db.QueryAsync(
        @"SELECT d.Id, d.ToUserId, u.DisplayName AS ToName, d.StartsOn, d.EndsOn
          FROM dbo.Delegations d JOIN dbo.Users u ON u.Id = d.ToUserId
          WHERE d.FromUserId = @me ORDER BY d.StartsOn DESC", ("me", Me)));

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] DelegationDto dto)
    {
        var me = Me;
        if (dto.ToUserId == me) return BadRequest(new { error = "You cannot delegate to yourself." });
        if (dto.EndsOn is { } end && end < dto.StartsOn) return BadRequest(new { error = "End date must be on or after the start date." });
        if (dto.EndsOn is null && dto.StartsOn.AddDays(365) < DateOnly.FromDateTime(DateTime.UtcNow))
            return BadRequest(new { error = "Open-ended delegations must start within the last year." });

        var target = await db.QueryAsync("SELECT Id FROM dbo.Users WHERE Id = @t AND IsActive = 1", ("t", dto.ToUserId));
        if (target.Count == 0) return BadRequest(new { error = "The selected person is not an active user." });

        var id = await db.ScalarIntAsync(
            "INSERT INTO dbo.Delegations (FromUserId, ToUserId, StartsOn, EndsOn) OUTPUT INSERTED.Id VALUES (@f, @t, @s, @e)",
            ("f", me), ("t", dto.ToUserId), ("s", dto.StartsOn.ToString("yyyy-MM-dd")),
            ("e", dto.EndsOn?.ToString("yyyy-MM-dd")));
        return Ok(new { id });
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var n = await db.ExecAsync("DELETE FROM dbo.Delegations WHERE Id = @id AND FromUserId = @me", ("id", id), ("me", Me));
        return n == 0 ? NotFound() : NoContent();
    }
}
