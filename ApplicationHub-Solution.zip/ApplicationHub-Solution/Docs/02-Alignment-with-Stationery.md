# Alignment with StationerySolution

Goal: Application Hub uses the same toolchain, versions, folder layout and configuration conventions as the working StationerySolution.

## Aligned now

| Area | StationerySolution | Application Hub |
|---|---|---|
| Node.js | `>=18.17.1 <19.0.0` | same |
| SPFx | 1.18.2 (exact pins) | same versions, copied from the working `package.json` |
| React / TypeScript | React 17.0.1, TypeScript 4.7.4 | same |
| Toolchain files | gulpfile, tsconfig, config/*.json, .gitignore | copied from the stationery project |
| API target | .NET 8 | same |
| JWT / JwtBearer | 8.0.8 | same |
| Swashbuckle | 6.6.2 | same |
| Connection string key | `ConnectionStrings:Default` | same |
| CORS | `Cors:Origins` array, policy `spfx`, exposes `Content-Disposition` | same |
| Port | `https://localhost:7100` | same (API launch profile and React proxy) |
| Settings sections | Smtp, Jwt, Cors, App, Auth | Smtp, Jwt, Cors, App, Swagger, Seed (no secrets committed) |
| Solution folders | Api, Spfx, Database, Docs, Preview | Api, Spfx, Database, Docs, Web (React client, not in the stationery project) |

## Still different (decisions needed)

1. **Sign-in model.** Stationery looks people up in the `EmployeeMaster` table and issues the JWT with roles derived from the hierarchy (`POST /api/auth/dev-login`, `POST /api/auth/login` with an Entra token). Application Hub uses a separate `Users` table with email and password. Recommendation: move to the stationery model, so one person signs in once across both apps.
2. **Data access.** Stationery uses EF Core with `AppDbContext`. Application Hub uses parameterized raw SQL through `Db.cs`. Recommendation: keep raw SQL for the workflow engine (it is tested against the rules) and reuse the stationery `AppDbContext` only if both apps share one database.
3. **Shared database or separate.** If Application Hub lives in the same SQL Server as StationeryDB, reuse `Employees`, `Departments` and `Divisions`. Otherwise keep the separate `ApplicationHubDB` and sync employees.
4. **Folder layout inside Api.** Stationery uses flat folders (Controllers, Services, Models, Dtos, Data, Middleware). Application Hub also has feature folders (Workflow, Forms, Masters, Mail). Recommendation: move these into `Services` and `Dtos` in a later cleanup.
5. **Exception handling.** Stationery uses `ExceptionMiddleware` (friendly messages for duplicate keys, linked records, and an `ExceptionLog` table). Application Hub returns a generic JSON error from the exception handler. Recommendation: adopt the stationery middleware.
6. **E-mail.** Stationery stores every mail in `EmailLog` with a retry worker and HTML templates. Application Hub has an outbox and a worker, but no templates or retry history. Recommendation: adopt the stationery `EmailLog` table and templates.
7. **Web part UI.** Stationery uses its own stylesheet generated from `Preview/stationery-preview.html` and no Fluent UI. Application Hub uses plain classes. Recommendation: reuse the stationery `styles/shStyles.ts` for a consistent look.
8. **Web part properties.** Stationery: `apiBaseUrl`, `apiResource`, `screenPercent`. Application Hub still uses `devToken` for local testing. This is replaced by the stationery dev-login once decision 1 is made.
9. **TypeScript library list.** Application Hub adds `es2016.array.include` and `es2019.array` to `lib` (for `includes` and `flatMap`). Stationery does not need them.

## Not compiled yet
Neither the API nor the SPFx project has been built in this environment. Run `npm install`, then `gulp build`, and `dotnet build`, and send the first error.
