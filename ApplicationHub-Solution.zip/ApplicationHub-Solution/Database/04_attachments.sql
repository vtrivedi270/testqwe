USE ApplicationHub;
GO
CREATE TABLE dbo.Attachments (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    RequestId   INT NULL CONSTRAINT FK_Att_Req REFERENCES dbo.Requests(Id),
    FileName    NVARCHAR(260) NOT NULL,
    ContentType NVARCHAR(100) NOT NULL,
    SizeBytes   INT NOT NULL CONSTRAINT CK_Att_Size CHECK (SizeBytes > 0 AND SizeBytes <= 10485760),
    Sha256      CHAR(64) NOT NULL,
    Content     VARBINARY(MAX) NOT NULL,
    UploadedBy  INT NOT NULL CONSTRAINT FK_Att_User REFERENCES dbo.Users(Id),
    UploadedAt  DATETIME2 NOT NULL CONSTRAINT DF_Att_At DEFAULT SYSUTCDATETIME()
);
CREATE INDEX IX_Att_Request ON dbo.Attachments(RequestId);
GO
