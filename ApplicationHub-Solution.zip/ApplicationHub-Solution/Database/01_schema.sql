IF DB_ID(N'ApplicationHub') IS NULL CREATE DATABASE ApplicationHub;
GO
USE ApplicationHub;
GO
SET ANSI_NULLS ON; SET QUOTED_IDENTIFIER ON;
GO
CREATE TABLE dbo.Users (
    Id            INT IDENTITY(1,1) PRIMARY KEY,
    Email         NVARCHAR(256) NOT NULL,
    DisplayName   NVARCHAR(200) NOT NULL,
    PasswordHash  NVARCHAR(100) NOT NULL,
    Role          NVARCHAR(50)  NOT NULL CHECK (Role IN (N'Admin', N'Requestor', N'Reporting Manager', N'Department Head', N'Division Head', N'HR')),
    IsActive      BIT NOT NULL CONSTRAINT DF_Users_Active DEFAULT 1,
    FailedLogins  INT NOT NULL CONSTRAINT DF_Users_Failed DEFAULT 0,
    LockedUntil   DATETIME2 NULL,
    CreatedAt     DATETIME2 NOT NULL CONSTRAINT DF_Users_Created DEFAULT SYSUTCDATETIME(),
    CONSTRAINT UQ_Users_Email UNIQUE (Email)
);
CREATE TABLE dbo.RefreshTokens (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    UserId      INT NOT NULL CONSTRAINT FK_RT_User REFERENCES dbo.Users(Id),
    TokenHash   CHAR(64) NOT NULL,
    ExpiresAt   DATETIME2 NOT NULL,
    RevokedAt   DATETIME2 NULL,
    CreatedAt   DATETIME2 NOT NULL CONSTRAINT DF_RT_Created DEFAULT SYSUTCDATETIME(),
    CONSTRAINT UQ_RT_Hash UNIQUE (TokenHash)
);
CREATE TABLE dbo.Applications (
    Id           INT IDENTITY(1,1) PRIMARY KEY,
    Name         NVARCHAR(200) NOT NULL,
    Description  NVARCHAR(1000) NULL,
    FormJson     NVARCHAR(MAX) NOT NULL CONSTRAINT DF_App_Form DEFAULT N'{}',
    Status       NVARCHAR(20) NOT NULL CONSTRAINT DF_App_Status DEFAULT N'Draft' CHECK (Status IN (N'Draft', N'Published')),
    CreatedBy    INT NOT NULL CONSTRAINT FK_App_User REFERENCES dbo.Users(Id),
    CreatedAt    DATETIME2 NOT NULL CONSTRAINT DF_App_Created DEFAULT SYSUTCDATETIME()
);
CREATE TABLE dbo.WorkflowStages (
    Id            INT IDENTITY(1,1) PRIMARY KEY,
    ApplicationId INT NOT NULL CONSTRAINT FK_Stage_App REFERENCES dbo.Applications(Id),
    StepOrder     INT NOT NULL,
    Name          NVARCHAR(200) NOT NULL,
    Role          NVARCHAR(50) NOT NULL,
    Mode          NVARCHAR(10) NOT NULL CONSTRAINT DF_Stage_Mode DEFAULT N'Seq' CHECK (Mode IN (N'Seq', N'Par')),
    ActionType    NVARCHAR(10) NOT NULL CONSTRAINT DF_Stage_Action DEFAULT N'Approve' CHECK (ActionType IN (N'Approve', N'Process')),
    CONSTRAINT UQ_Stage_Order UNIQUE (ApplicationId, StepOrder)
);
CREATE TABLE dbo.Requests (
    Id            INT IDENTITY(1,1) PRIMARY KEY,
    ApplicationId INT NOT NULL CONSTRAINT FK_Req_App REFERENCES dbo.Applications(Id),
    RequesterId   INT NOT NULL CONSTRAINT FK_Req_User REFERENCES dbo.Users(Id),
    Status        NVARCHAR(20) NOT NULL CONSTRAINT DF_Req_Status DEFAULT N'In progress'
                  CHECK (Status IN (N'Draft', N'In progress', N'Amend requested', N'Closed', N'Rejected', N'Cancelled')),
    CurrentStep   INT NOT NULL CONSTRAINT DF_Req_Step DEFAULT 0,
    PayloadJson   NVARCHAR(MAX) NOT NULL,
    CreatedAt     DATETIME2 NOT NULL CONSTRAINT DF_Req_Created DEFAULT SYSUTCDATETIME(),
    UpdatedAt     DATETIME2 NOT NULL CONSTRAINT DF_Req_Updated DEFAULT SYSUTCDATETIME()
);
CREATE INDEX IX_Requests_Requester ON dbo.Requests(RequesterId, CreatedAt DESC);
CREATE INDEX IX_Requests_App ON dbo.Requests(ApplicationId, Status);
CREATE TABLE dbo.Approvals (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    RequestId   INT NOT NULL CONSTRAINT FK_Appr_Req REFERENCES dbo.Requests(Id),
    StageId     INT NOT NULL CONSTRAINT FK_Appr_Stage REFERENCES dbo.WorkflowStages(Id),
    ActorId     INT NOT NULL CONSTRAINT FK_Appr_Actor REFERENCES dbo.Users(Id),
    ActedForId  INT NULL CONSTRAINT FK_Appr_For REFERENCES dbo.Users(Id),
    Action      NVARCHAR(20) NOT NULL CHECK (Action IN (N'Approve', N'Reject', N'AskAmend', N'Delegate', N'Process')),
    Comment     NVARCHAR(1000) NULL,
    ActedAt     DATETIME2 NOT NULL CONSTRAINT DF_Appr_At DEFAULT SYSUTCDATETIME()
);
CREATE TABLE dbo.Delegations (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    FromUserId  INT NOT NULL CONSTRAINT FK_Del_From REFERENCES dbo.Users(Id),
    ToUserId    INT NOT NULL CONSTRAINT FK_Del_To REFERENCES dbo.Users(Id),
    StartsOn    DATE NOT NULL,
    EndsOn      DATE NULL,
    CONSTRAINT CK_Del_Self CHECK (FromUserId <> ToUserId)
);
CREATE TABLE dbo.EmailLog (
    Id          BIGINT IDENTITY(1,1) PRIMARY KEY,
    RequestId   INT NULL,
    ToAddress   NVARCHAR(256) NOT NULL,
    Subject     NVARCHAR(300) NOT NULL,
    Status      NVARCHAR(20) NOT NULL CONSTRAINT DF_Mail_Status DEFAULT N'Queued' CHECK (Status IN (N'Queued', N'Sent', N'Failed')),
    CreatedAt   DATETIME2 NOT NULL CONSTRAINT DF_Mail_Created DEFAULT SYSUTCDATETIME()
);
CREATE TABLE dbo.AuditLog (
    Id      BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId  INT NULL,
    Action  NVARCHAR(100) NOT NULL,
    Detail  NVARCHAR(2000) NULL,
    At      DATETIME2 NOT NULL CONSTRAINT DF_Audit_At DEFAULT SYSUTCDATETIME()
);
GO
