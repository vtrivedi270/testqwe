USE ApplicationHub;
GO
-- Master data used by lookups, dependent dropdowns and parent-child lists.
CREATE TABLE dbo.Countries (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL,
    IsActive BIT NOT NULL CONSTRAINT DF_Countries_Active DEFAULT 1
);
CREATE TABLE dbo.States (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL,
    CountryId INT NOT NULL CONSTRAINT FK_States_Country REFERENCES dbo.Countries(Id),
    IsActive BIT NOT NULL CONSTRAINT DF_States_Active DEFAULT 1
);
CREATE TABLE dbo.Cities (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL,
    StateId INT NOT NULL CONSTRAINT FK_Cities_State REFERENCES dbo.States(Id),
    IsActive BIT NOT NULL CONSTRAINT DF_Cities_Active DEFAULT 1
);
CREATE TABLE dbo.Divisions (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL,
    IsActive BIT NOT NULL CONSTRAINT DF_Divisions_Active DEFAULT 1
);
CREATE TABLE dbo.Departments (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL,
    DivisionId INT NOT NULL CONSTRAINT FK_Departments_Division REFERENCES dbo.Divisions(Id),
    IsActive BIT NOT NULL CONSTRAINT DF_Departments_Active DEFAULT 1
);
CREATE TABLE dbo.Employees (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL,
    Email NVARCHAR(256) NULL,
    DepartmentId INT NULL CONSTRAINT FK_Employees_Department REFERENCES dbo.Departments(Id),
    IsActive BIT NOT NULL CONSTRAINT DF_Employees_Active DEFAULT 1
);
CREATE TABLE dbo.Assets (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL,
    EmployeeId INT NOT NULL CONSTRAINT FK_Assets_Employee REFERENCES dbo.Employees(Id),
    IsActive BIT NOT NULL CONSTRAINT DF_Assets_Active DEFAULT 1
);
CREATE TABLE dbo.Vendors (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL,
    Contact NVARCHAR(256) NULL,
    IsActive BIT NOT NULL CONSTRAINT DF_Vendors_Active DEFAULT 1
);
CREATE TABLE dbo.StationeryItems (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL,
    Price DECIMAL(18,2) NOT NULL CONSTRAINT DF_Items_Price DEFAULT 0 CONSTRAINT CK_Items_Price CHECK (Price >= 0),
    Stock INT NOT NULL CONSTRAINT DF_Items_Stock DEFAULT 0 CONSTRAINT CK_Items_Stock CHECK (Stock >= 0),
    IsActive BIT NOT NULL CONSTRAINT DF_Items_Active DEFAULT 1
);
GO
-- Starter data so the lookups work the first time.
INSERT INTO dbo.Countries (Name) VALUES (N'India'), (N'USA');
INSERT INTO dbo.States (Name, CountryId) VALUES (N'Gujarat', 1), (N'Maharashtra', 1), (N'California', 2);
INSERT INTO dbo.Cities (Name, StateId) VALUES (N'Rajkot', 1), (N'Ahmedabad', 1), (N'Mumbai', 2), (N'Los Angeles', 3);
INSERT INTO dbo.Divisions (Name) VALUES (N'Corporate'), (N'Technology');
INSERT INTO dbo.Departments (Name, DivisionId) VALUES (N'Finance', 1), (N'Human Resources', 1), (N'IT', 2), (N'Development', 2);
INSERT INTO dbo.Vendors (Name, Contact) VALUES (N'Office Hub Pvt Ltd', N'sales@officehub.example'), (N'Paper Point', N'orders@paperpoint.example');
INSERT INTO dbo.StationeryItems (Name, Price, Stock) VALUES (N'A4 Paper (ream)', 350, 40), (N'Blue Pen (box)', 120, 15), (N'Stapler', 250, 4);
GO
