USE ApplicationHub;
GO
-- Phase 2: workflow engine (groups, any/all rules, cycles for amend/resubmit, step delegation)
ALTER TABLE dbo.WorkflowStages ADD
    Kind NVARCHAR(10) NOT NULL CONSTRAINT DF_Stage_Kind DEFAULT N'Role' CONSTRAINT CK_Stage_Kind CHECK (Kind IN (N'Role', N'Group')),
    Rule NVARCHAR(5)  NOT NULL CONSTRAINT DF_Stage_Rule DEFAULT N'Any'  CONSTRAINT CK_Stage_Rule CHECK (Rule IN (N'Any', N'All'));
GO
CREATE TABLE dbo.StageMembers (
    StageId INT NOT NULL CONSTRAINT FK_SM_Stage REFERENCES dbo.WorkflowStages(Id),
    UserId  INT NOT NULL CONSTRAINT FK_SM_User  REFERENCES dbo.Users(Id),
    CONSTRAINT PK_StageMembers PRIMARY KEY (StageId, UserId)
);
GO
ALTER TABLE dbo.Requests ADD
    Cycle     INT NOT NULL CONSTRAINT DF_Req_Cycle DEFAULT 1,
    AmendNote NVARCHAR(1000) NULL;
GO
ALTER TABLE dbo.Approvals ADD Cycle INT NOT NULL CONSTRAINT DF_Appr_Cycle DEFAULT 1;
GO
CREATE TABLE dbo.StepDelegations (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    RequestId   INT NOT NULL CONSTRAINT FK_SD_Req REFERENCES dbo.Requests(Id),
    StageId     INT NOT NULL CONSTRAINT FK_SD_Stage REFERENCES dbo.WorkflowStages(Id),
    FromUserId  INT NOT NULL CONSTRAINT FK_SD_From REFERENCES dbo.Users(Id),
    ToUserId    INT NOT NULL CONSTRAINT FK_SD_To REFERENCES dbo.Users(Id),
    Cycle       INT NOT NULL,
    CreatedAt   DATETIME2 NOT NULL CONSTRAINT DF_SD_Created DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_SD_Self CHECK (FromUserId <> ToUserId)
);
GO
CREATE INDEX IX_Approvals_Request ON dbo.Approvals(RequestId, Cycle);
CREATE INDEX IX_EmailLog_Status ON dbo.EmailLog(Status, Id);
GO
